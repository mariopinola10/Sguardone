package it.gerry.iptvlite.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Programme
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Repository
import it.gerry.iptvlite.vpn.VpnManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Schermata principale in stile Sky: solo i canali preferiti.
 * Avvio: consenso VPN -> tunnel Mullvad verificato -> lista M3U -> guida preferiti -> EPG in background.
 * La gestione di tutti i canali e dei preferiti è in BrowseActivity (dalle impostazioni).
 */
class MainActivity : ComponentActivity() {

    private val app by lazy { application as App }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var vpnStatus: TextView
    private lateinit var info: TextView
    private lateinit var retryButton: Button
    private lateinit var channelList: RecyclerView
    private lateinit var emptyPanel: View
    private lateinit var heroLogo: ImageView
    private lateinit var heroChannel: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroTime: TextView
    private lateinit var heroProgress: ProgressBar
    private lateinit var heroDesc: TextView
    private lateinit var heroNext: TextView
    private lateinit var heroUpcoming: TextView

    private lateinit var adapter: ChannelGuideAdapter

    private var started = false
    private lateinit var listMessage: TextView
    private lateinit var tabAdapter: TabAdapter
    private lateinit var tabsList: RecyclerView
    private var currentTab = Repository.FAVORITES
    private var listTab = Repository.FAVORITES
    private var ticks = 0
    private lateinit var highlight: TextView
    private lateinit var picks: HomePicks
    private lateinit var heroBox: View
    private var heroChannelShown: Channel? = null
    private var heroProgrammeShown: Programme? = null
    private var ready = false
    private var focused: Channel? = null
    private var loadJob: Job? = null
    private var epgJob: Job? = null

    /** Ogni 30 s: orologio, barre di avanzamento e riquadro del programma. */
    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            if (ready) {
                adapter.refreshRows()
                focused?.let { showHero(it) }
                if (ticks++ % 4 == 0) {   // ogni 2 minuti
                    updateHighlight()
                    picks.refresh()
                }
            }
            handler.postDelayed(this, 30_000L)
        }
    }

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) connectAndLoad()
            else showError("Permesso VPN negato: senza VPN l'app non si collega a nulla.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        vpnStatus = findViewById(R.id.vpnStatus)
        info = findViewById(R.id.info)
        retryButton = findViewById(R.id.retryButton)
        channelList = findViewById(R.id.channelList)
        emptyPanel = findViewById(R.id.emptyPanel)
        heroLogo = findViewById(R.id.heroLogo)
        heroChannel = findViewById(R.id.heroChannel)
        heroTitle = findViewById(R.id.heroTitle)
        heroTime = findViewById(R.id.heroTime)
        heroProgress = findViewById(R.id.heroProgress)
        heroDesc = findViewById(R.id.heroDesc)
        heroNext = findViewById(R.id.heroNext)
        heroUpcoming = findViewById(R.id.heroUpcoming)
        heroBox = findViewById(R.id.hero)
        heroBox.setOnClickListener { showProgrammeDetail() }
        picks = HomePicks(this, app)

        retryButton.setOnClickListener { startFlow() }
        findViewById<TextView>(R.id.appVersion).text = "v${app.versionName}"
        listMessage = findViewById(R.id.listMessage)
        findViewById<Button>(R.id.chooseButton).setOnClickListener { openBrowse() }
        findViewById<View>(R.id.searchButton).setOnClickListener { SearchActivity.start(this) }
        findViewById<View>(R.id.channelsButton).setOnClickListener { openBrowse() }
        findViewById<View>(R.id.settingsButton).setOnClickListener { openSettings() }
        findViewById<View>(R.id.exitButton).setOnClickListener { exitApp() }
        findViewById<Button>(R.id.updateButton).setOnClickListener { UpdateUi.checkAndInstall(this) }
        highlight = findViewById(R.id.highlight)
        // Indietro dalla guida: chiede se uscire e chiudere la VPN.
        onBackPressedDispatcher.addCallback(this) { confirmExit() }

        adapter = ChannelGuideAdapter(
            app = app,
            onFocus = { ch, _ ->
                focused = ch
                showHero(ch)
            },
            onClick = { ch, _ -> PlayerActivity.start(this, listTab, ch) },
            onLongClick = { ch, _ -> ChannelActions.show(this, app, ch) { reloadFavorites(focusList = false) } },
        )

        tabAdapter = TabAdapter(
            // Col telecomando basta spostarsi sulla scheda; OK/tocco apre e porta sulla lista.
            // Passare sopra una scheda non cambia l'elenco: si apre solo con OK/tocco, poi si va sui canali.
            onFocus = { _ -> },
            onClick = { tab -> selectTab(tab, focusList = true) },
        )
        tabsList = findViewById(R.id.tabsList)
        tabsList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tabsList.adapter = tabAdapter
        tabsList.itemAnimator = null
        currentTab = app.prefs.guideTab.ifEmpty { Repository.FAVORITES }

        channelList.layoutManager = LinearLayoutManager(this)
        channelList.adapter = adapter
        channelList.itemAnimator = null
        adaptToDevice()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                app.vpn.state.collect { renderVpn(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!app.prefs.isConfigured) {
            openSettings()
            return
        }
        if (app.configDirty) {
            app.configDirty = false
            started = false
            ready = false
            adapter.items = emptyList()
        }
        if (!started) {
            started = true
            startFlow()
        } else if (ready) {
            if (!app.vpn.isUp && app.vpn.state.value !is VpnManager.State.Connecting) {
                startFlow()       // VPN chiusa per inattività: si ricollega
            } else {
                reloadFavorites() // di ritorno dalla gestione canali o dal player
            }
        }
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        // Uscita dall'app: chiude il tunnel.
        if (isFinishing) app.appScope.launch { app.shutdown() }
    }

    // ---------- Uscita ----------

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle("Uscire da Sguardone?")
            .setMessage("La VPN e tutte le connessioni verranno chiuse.")
            .setPositiveButton("Esci") { _, _ -> exitApp() }
            .setNegativeButton("Annulla", null)
            .show()
    }

    /** Chiude VPN e connessioni, poi l'app (anche dalle app recenti). */
    private fun exitApp() {
        setInfo("Chiusura della VPN…")
        app.appScope.launch {
            app.shutdown()
            runOnUiThread { finishAndRemoveTask() }
        }
    }

    // ---------- Navigazione col telecomando ----------

    /** Torna sul canale selezionato nella lista (o sul primo). */
    private fun focusChannelList() {
        val pos = adapter.items.indexOfFirst { it.id == focused?.id }.coerceAtLeast(0)
        if (adapter.items.isEmpty()) return
        channelList.scrollToPosition(pos)
        channelList.post {
            (channelList.findViewHolderForAdapterPosition(pos)?.itemView ?: channelList.getChildAt(0))?.requestFocus()
        }
    }

    /** Primo elemento di "Da non perdere". false se è vuoto. */
    private fun focusFirstPick(): Boolean {
        val list = findViewById<RecyclerView>(R.id.picksList)
        if ((list.adapter?.itemCount ?: 0) == 0) return false
        list.scrollToPosition(0)
        list.post { list.getChildAt(0)?.requestFocus() }
        return true
    }

    private fun isInside(view: View, parent: View): Boolean {
        var v: View? = view
        while (v != null) {
            if (v === parent) return true
            v = v.parent as? View
        }
        return false
    }

    /**
     * Percorsi semplici col telecomando:
     * schede ↓ canali · canali → programma (OK = trama completa) ↓ Da non perdere · ← torna al canale.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && ready) {
            val f = currentFocus
            val picksList = findViewById<RecyclerView>(R.id.picksList)
            val rightCol = findViewById<View>(R.id.rightCol)
            if (f != null) when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (isInside(f, tabsList) && adapter.items.isNotEmpty()) {
                        focusChannelList(); return true
                    }
                    if (f === heroBox && focusFirstPick()) return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (isInside(f, channelList) && rightCol.visibility == View.VISIBLE) {
                        if (heroBox.visibility == View.VISIBLE) { heroBox.requestFocus(); return true }
                        if (focusFirstPick()) return true
                    }
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (f === heroBox || isInside(f, picksList)) {
                        focusChannelList(); return true
                    }
                }
                KeyEvent.KEYCODE_DPAD_UP -> {
                    if (isInside(f, picksList) && heroBox.visibility == View.VISIBLE &&
                        f.parent === picksList && picksList.getChildAdapterPosition(f) == 0
                    ) {
                        heroBox.requestFocus(); return true
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** OK sul riquadro del programma: trama completa, orari e voto; "Guarda" apre il canale. */
    private fun showProgrammeDetail() {
        val ch = heroChannelShown ?: return
        val p = heroProgrammeShown
        lifecycleScope.launch {
            val r = p?.let { withContext(Dispatchers.IO) { app.repo.cachedRating(it) } }
            val upcoming = withContext(Dispatchers.IO) { app.repo.programmes(ch.epgKey, 6) }
                .filter { p == null || it.start > p.start }.take(4)
            val text = buildString {
                append(ch.displayName)
                if (p != null) {
                    append("\n").append(Format.range(p))
                    p.category?.let { append("  ·  ").append(it) }
                    p.year?.let { append("  ·  ").append(it) }
                    if (r != null) append("\n").append(Format.rating(r)).append("  (").append(r.votes).append(" voti)")
                    append("\n\n").append(p.description?.takeIf { it.isNotBlank() } ?: "Nessuna trama nella guida.")
                }
                if (upcoming.isNotEmpty()) {
                    append("\n\nA seguire:\n")
                    append(upcoming.joinToString("\n") { "${Format.time(it.start)}   ${it.title}" })
                }
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle(p?.title ?: ch.displayName)
                .setMessage(text)
                .setPositiveButton("▶ Guarda") { _, _ -> PlayerActivity.start(this@MainActivity, listTab, ch) }
                .setNegativeButton("Chiudi", null)
                .show()
        }
    }

    /**
     * Tasto Menu (≡): sul canale apre preferiti/numero, altrove le impostazioni.
     * Tasti numerici: vanno al canale con quel numero, come in TV.
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            val ch = focused
            if (channelList.hasFocus() && ch != null) {
                ChannelActions.show(this, app, ch) { reloadFavorites(focusList = false) }
            } else {
                openSettings()
            }
            return true
        }
        if (keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 && ready) {
            digits += (keyCode - KeyEvent.KEYCODE_0).toString()
            setInfo("Canale  $digits…")
            handler.removeCallbacks(digitJump)
            handler.postDelayed(digitJump, 1_500L)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private var digits = ""
    private val digitJump = Runnable {
        val n = digits.toIntOrNull()
        digits = ""
        setInfo("")
        val pos = adapter.items.indexOfFirst { it.number == n }
        if (pos < 0) {
            setInfo("Canale $n non presente in questa scheda")
            return@Runnable
        }
        channelList.scrollToPosition(pos)
        channelList.post { channelList.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
    }

    // ---------- Avvio ----------

    private fun startFlow() {
        retryButton.visibility = View.GONE
        val intent = app.vpn.permissionIntent()
        if (intent != null) vpnPermission.launch(intent) else connectAndLoad()
    }

    private fun connectAndLoad() {
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            try {
                setInfo("Connessione a Mullvad…")
                app.vpn.connect()
                withContext(Dispatchers.IO) { app.repo.refreshPlaylist(false, ::postInfo) }
                ready = true
                reloadFavorites()
                setInfo("")
                refreshEpgInBackground()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                showError(e.message ?: e.toString())
            }
        }
    }

    private fun refreshEpgInBackground() {
        epgJob?.cancel()
        epgJob = lifecycleScope.launch {
            try {
                val updated = withContext(Dispatchers.IO) { app.repo.refreshEpg(false, ::postInfo) }
                if (updated) {
                    reloadFavorites()   // l'abbinamento EPG dei canali può essere cambiato
                    picks.refresh(force = true)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setInfo("Guida EPG non disponibile: ${e.message}")
            }
        }
    }

    // ---------- Guida preferiti ----------

    private class GuideData(
        val tabs: List<String>,
        val tab: String,
        val list: List<Channel>,
        val nothingChosen: Boolean,
        val hidden: Int,
    )

    /** Ricarica schede e canali della scheda aperta (preferiti o cartella), con il filtro HTTPS. */
    private fun reloadFavorites(focusList: Boolean = true) {
        lifecycleScope.launch {
            val data = withContext(Dispatchers.IO) {
                val groups = app.repo.favoriteGroups()
                val hasFavChannels = app.repo.favoriteNames().isNotEmpty() &&
                    app.repo.channels(Repository.FAVORITES).isNotEmpty()
                // Schede automatiche per paese (es. 🇮🇹 Italia, 🇨🇱 Cile), subito dopo i Preferiti.
                val countryTabs = app.repo.availableCountries().map { app.repo.countryGroup(it) }
                val favTab = if (hasFavChannels || (groups.isEmpty() && countryTabs.isEmpty())) listOf(Repository.FAVORITES) else emptyList()
                val tabs = favTab + countryTabs + groups
                val tab = if (currentTab in tabs) currentTab else tabs.first()
                val visible = app.repo.visibleChannels(tab)
                val hidden = if (app.prefs.showHttpsOnly) {
                    val shown = visible.map { app.repo.qualityKey(it.name) }.toSet()
                    app.repo.channels(tab).filter { !it.url.startsWith("https://", ignoreCase = true) }
                        .map { app.repo.qualityKey(it.name) }.distinct().count { it !in shown }
                } else 0
                GuideData(tabs, tab, visible, !hasFavChannels && groups.isEmpty(), hidden)
            }
            currentTab = data.tab
            app.prefs.guideTab = data.tab
            // Le schede si ricreano solo se cambiano: così il focus del telecomando resta sulla scheda.
            if (tabAdapter.items != data.tabs) tabAdapter.items = data.tabs
            tabAdapter.selected = data.tab
            tabsList.visibility = if (data.tabs.size > 1) View.VISIBLE else View.INVISIBLE

            val keepId = focused?.id
            val list = data.list
            adapter.items = list
            listTab = data.tab   // la scheda a cui appartengono davvero i canali mostrati

            listMessage.visibility = View.GONE
            if (data.nothingChosen) {
                channelList.visibility = View.GONE
                emptyPanel.visibility = View.VISIBLE
                clearHero()
                findViewById<Button>(R.id.chooseButton).requestFocus()
                return@launch
            }
            channelList.visibility = View.VISIBLE
            emptyPanel.visibility = View.GONE

            if (list.isEmpty()) {
                clearHero()
                // Messaggio fisso al centro: non viene sovrascritto dagli aggiornamenti della guida.
                listMessage.text = if (data.hidden > 0) {
                    "${data.hidden} canali di questa scheda sono nascosti perché non HTTPS.\n" +
                        "Per vederli togli «Solo canali HTTPS» in Impostazioni (⚙)."
                } else {
                    "Nessun canale in questa scheda."
                }
                listMessage.visibility = View.VISIBLE
                if (focusList) tabsList.post { tabsList.getChildAt(0)?.requestFocus() }
                return@launch
            }

            val pos = list.indexOfFirst { it.id == keepId }.coerceAtLeast(0)
            if (focusList) channelList.scrollToPosition(pos)
            if (focusList) {
                channelList.post {
                    channelList.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus()
                        ?: channelList.requestFocus()
                }
            }
            focused = list[pos]
            showHero(list[pos])
            updateHighlight()
            picks.refresh()
            UpdateUi.checkSilently(this@MainActivity) { name ->
                findViewById<Button>(R.id.updateButton).apply {
                    text = "⬆ Aggiorna a $name"
                    visibility = View.VISIBLE
                }
            }
        }
    }

    private fun selectTab(tab: String, focusList: Boolean) {
        if (tab == currentTab) {
            if (focusList) focusChannelList()
            return
        }
        currentTab = tab
        focused = null
        reloadFavorites(focusList)
    }

    /**
     * "In evidenza": il prossimo evento (o quello in onda) che corrisponde alle ricerche salvate,
     * es. "★ Napoli · Oggi 20:45  Napoli - Inter  ·  DAZN 1". OK/tocco: guarda o apre la ricerca.
     */
    private fun updateHighlight() {
        val terms = app.prefs.savedSearches
        if (terms.isEmpty()) {
            highlight.visibility = View.GONE
            return
        }
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) { runCatching { app.repo.nextHighlight(terms) }.getOrNull() }
            if (found == null) {
                highlight.visibility = View.GONE
                return@launch
            }
            val (term, hit) = found
            val onAir = hit.programme.start <= System.currentTimeMillis()
            val whenText = if (onAir) "● IN ONDA" else Format.day(hit.programme.start)
            highlight.text = "★ $term   ·   $whenText   ${hit.programme.title}   ·   ${hit.channel.name}"
            highlight.setTextColor(getColorStateList(R.color.on_focus_text))
            highlight.setOnClickListener {
                if (hit.programme.start <= System.currentTimeMillis()) PlayerActivity.startByName(this@MainActivity, hit.channel.name)
                else SearchActivity.start(this@MainActivity, term)
            }
            highlight.visibility = View.VISIBLE
        }
    }

    private fun showHero(ch: Channel) {
        lifecycleScope.launch {
            val (now, next) = withContext(Dispatchers.IO) { app.repo.nowNext(ch.epgKey) }
            val upcoming = withContext(Dispatchers.IO) { app.repo.programmes(ch.epgKey, 6) }
                .filter { next == null || it.start > next.start }
                .take(3)
            if (focused != ch) return@launch
            // Riquadro solo quando c'è la guida del canale: niente rettangolo vuoto.
            if (now == null && next == null) {
                clearHero()
                return@launch
            }
            heroBox.visibility = View.VISIBLE
            heroChannelShown = ch
            heroProgrammeShown = now ?: next
            heroChannel.text = if (ch.number > 0) "${ch.number}   ${ch.displayName}" else ch.displayName
            app.logos.load(ch.logo, heroLogo)
            if (now != null) {
                heroTitle.text = now.title
                heroTime.text = listOfNotNull(Format.range(now), now.category).joinToString("   ·   ")
                heroProgress.progress = Format.progress(now)
                heroProgress.visibility = View.VISIBLE
                heroDesc.text = now.description.orEmpty()
                showRating(ch, now)
            } else {
                heroTitle.text = "Ora: nessun programma in guida"
                heroTime.text = ""
                heroProgress.visibility = View.INVISIBLE
                heroDesc.text = ""
            }
            heroNext.text = Format.next(next)
            heroUpcoming.text = upcoming.joinToString("\n") { "${Format.time(it.start)}   ${it.title}" }
        }
    }

    /** Voto TMDB accanto al titolo (film e serie): subito se in cache, altrimenti dall'API dopo un attimo. */
    private fun showRating(ch: Channel, p: Programme) {
        if (!app.prefs.ratingsActive || !app.repo.looksLikeFilm(p, ch)) return
        lifecycleScope.launch {
            val cached = withContext(Dispatchers.IO) { app.repo.cachedRating(p) }
            val r = cached ?: run {
                if (!app.vpn.isUp || withContext(Dispatchers.IO) { app.repo.ratingKnown(p) }) return@launch
                kotlinx.coroutines.delay(800)   // solo se il canale resta selezionato
                if (focused != ch) return@launch
                withContext(Dispatchers.IO) { app.repo.rating(p) }
            } ?: return@launch
            if (focused == ch && heroTitle.text.toString() == p.title) {
                heroTitle.text = "${p.title}   ${Format.rating(r)}"
            }
        }
    }

    private fun clearHero() {
        heroBox.visibility = View.GONE
        heroChannelShown = null
        heroProgrammeShown = null
        heroChannel.text = ""
        heroTitle.text = ""
        heroTime.text = ""
        heroDesc.text = ""
        heroNext.text = ""
        heroUpcoming.text = ""
        heroProgress.visibility = View.INVISIBLE
        heroLogo.setImageDrawable(null)
    }

    /**
     * TV: riquadro del programma sempre visibile, comandi da telecomando.
     * Tablet in orizzontale: come la TV. Telefono (e tablet in verticale): niente riquadro,
     * le righe mostrano già tutto e si tocca il canale per guardarlo.
     */
    private fun adaptToDevice() {
        val tv = Device.isTv(this)
        val landscape = Device.isLandscape(this)
        val showHero = tv || (Device.isTablet(this) && landscape)
        findViewById<View>(R.id.rightCol).visibility = if (showHero) View.VISIBLE else View.GONE
        picks.wide = showHero
        adapter.showNext = !showHero
        if (!landscape) date.visibility = View.GONE
        findViewById<TextView>(R.id.hint).text = if (tv) {
            "OK guarda  ·  ▶ a destra: trama e Da non perdere  ·  ▲ schede (OK per aprirle)  ·  ≡ Menu: preferiti e numero"
        } else {
            "Tocca un canale per guardarlo  ·  tieni premuto per preferiti e numero  ·  🔍 cerca  ·  ☰ canali"
        }
    }

    private fun updateClock() {
        val now = System.currentTimeMillis()
        clock.text = Format.time(now)
        date.text = Format.date(now)
    }

    // ---------- Stato ----------

    private fun renderVpn(state: VpnManager.State) {
        when (state) {
            VpnManager.State.Down -> setVpn("● VPN disattivata", COLOR_ERROR)
            VpnManager.State.Connecting -> setVpn("● VPN in connessione…", COLOR_WAIT)
            is VpnManager.State.Up -> setVpn("● Mullvad · ${state.relay}", COLOR_OK)
            is VpnManager.State.Error -> {
                setVpn("● VPN errore", COLOR_ERROR)
                if (started) showError(state.message)
            }
        }
    }

    private fun setVpn(text: String, color: Int) {
        vpnStatus.text = text
        vpnStatus.setTextColor(color)
    }

    private fun setInfo(text: String) {
        info.text = text
        info.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun postInfo(text: String) {
        runOnUiThread { setInfo(text) }
    }

    private fun showError(message: String) {
        setInfo(message)
        retryButton.visibility = View.VISIBLE
        retryButton.requestFocus()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun openBrowse() {
        startActivity(Intent(this, BrowseActivity::class.java))
    }

    private companion object {
        val COLOR_OK = Color.parseColor("#4CAF50")
        val COLOR_WAIT = Color.parseColor("#FFC107")
        val COLOR_ERROR = Color.parseColor("#F44336")
    }
}
