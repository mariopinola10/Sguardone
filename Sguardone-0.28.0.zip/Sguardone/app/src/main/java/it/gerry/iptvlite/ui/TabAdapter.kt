package it.gerry.iptvlite.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Repository

/** Schede della guida: "★ Preferiti" e le cartelle preferite. La scheda aperta resta evidenziata. */
class TabAdapter(
    private val onFocus: (String) -> Unit,
    private val onClick: (String) -> Unit,
) : RecyclerView.Adapter<TabAdapter.Holder>() {

    class Holder(val text: TextView) : RecyclerView.ViewHolder(text)

    var items: List<String> = emptyList()
        @SuppressLint("NotifyDataSetChanged")
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var selected: String = ""
        set(value) {
            field = value
            notifyItemRangeChanged(0, itemCount)
        }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false) as TextView)

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val tab = items[position]
        holder.text.text = when {
            tab == Repository.FAVORITES -> tab
            Repository.isCountry(tab) -> Repository.countryTabLabel(tab)   // 🇮🇹 Italia, 🇨🇱 Cile
            else -> "▤ $tab"
        }
        holder.text.isActivated = tab == selected
        holder.text.setOnFocusChangeListener { _, hasFocus -> if (hasFocus) onFocus(tab) }
        holder.text.setOnClickListener { onClick(tab) }
    }
}
