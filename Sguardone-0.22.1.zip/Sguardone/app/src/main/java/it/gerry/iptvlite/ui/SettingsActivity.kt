package it.gerry.iptvlite.ui

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import it.gerry.iptvlite.App
import it.gerry.iptvlite.Prefs
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.ChannelNames
import it.gerry.iptvlite.config.ConfigServer
import it.gerry.iptvlite.data.Tmdb
import it.gerry.iptvlite.data.XtreamAccount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.Locale
import kotlin.random.Random

/**
 * Configurazione: account Mullvad, paese server, lista M3U (link o file), EPG.
 * Si può compilare col telecomando oppure dal telefono tramite il mini server web locale.
 */
class SettingsActivity : ComponentActivity() {

    private val app by lazy { application as App }
    private val pin = String.format(Locale.ROOT, "%04d", Random.nextInt(10_000))
    private var server: ConfigServer? = null

    private lateinit var m3uField: EditText
    private lateinit var epgField: EditText
    private lateinit var accountField: EditText
    private lateinit var countryField: EditText
    private lateinit var localInfo: TextView
    private lateinit var phoneInfo: TextView
    private lateinit var allowHttp: CheckBox
    private lateinit var includeLocal: CheckBox

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            val error = withContext(Dispatchers.IO) {
                try {
                    val tmp = File(filesDir, "upload.tmp")
                    contentResolver.openInputStream(uri)?.use { input ->
                        tmp.outputStream().use { input.copyTo(it) }
                    } ?: throw IOException("File non leggibile")
                    storeM3uFile(tmp)
                } catch (e: Exception) {
                    e.message ?: "Errore nella lettura del file"
                }
            }
            if (error != null) {
                toast(error)
            } else {
                includeLocal.isChecked = true
                updateLocalInfo()
                toast("File caricato e aggiunto alle liste. Premi Salva.")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<TextView>(R.id.settingsTitle).text = "Impostazioni  ·  Sguardone ${app.versionName}"

        m3uField = findViewById(R.id.m3uUrl)
        epgField = findViewById(R.id.epgUrl)
        accountField = findViewById(R.id.mullvadAccount)
        countryField = findViewById(R.id.country)
        localInfo = findViewById(R.id.localInfo)
        phoneInfo = findViewById(R.id.phoneInfo)
        allowHttp = findViewById(R.id.allowHttpStreams)
        includeLocal = findViewById(R.id.includeLocalFile)
        fillFields()
        TvText.apply(m3uField, "Link M3U (uno per riga)")
        TvText.apply(epgField, "Link EPG (separati da virgola)")
        TvText.apply(accountField, "Account Mullvad (16 cifre)")
        TvText.apply(countryField, "Paese server (it, ch, de…)")
        TvText.apply(findViewById(R.id.xtreamServer), "Server Xtream (https://…)")
        TvText.apply(findViewById(R.id.xtreamUser), "Utente Xtream")
        TvText.apply(findViewById(R.id.xtreamPass), "Password Xtream")
        TvText.apply(findViewById(R.id.tmdbKey), "Chiave API TMDB")

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val tmdb = findViewById<EditText>(R.id.tmdbKey).text.toString().trim()
            if (tmdb.isNotEmpty() && !Tmdb.isValidKey(tmdb)) {
                return@setOnClickListener toast("Chiave TMDB non valida: 32 caratteri (API Key) oppure il token di lettura eyJ…")
            }
            val links = Prefs.splitSources(m3uField.text.toString())
            val withFile = includeLocal.isChecked && app.localM3uFile.exists()
            val result = applyConfig(
                m3u = (links + if (withFile) listOf(Prefs.LOCAL_M3U) else emptyList()).joinToString("\n"),
                epg = epgField.text.toString().trim(),
                account = accountField.text.toString(),
                country = countryField.text.toString(),
            )
            if (result.error != null) {
                toast(result.error)
            } else {
                app.prefs.httpsOnlyStreams = !allowHttp.isChecked
                app.prefs.softwareDecoders = findViewById<CheckBox>(R.id.softwareDecoders).isChecked
                app.prefs.autoChannelOrder = findViewById<CheckBox>(R.id.autoChannelOrder).isChecked
                app.prefs.mergeQualities = findViewById<CheckBox>(R.id.mergeQualities).isChecked
                app.prefs.ratingsEnabled = findViewById<CheckBox>(R.id.ratingsEnabled).isChecked
                app.prefs.tmdbKey = tmdb
                applyAndClose(result.reconnect)
            }
        }

        // Filtro della guida: vale subito, senza premere Salva.
        findViewById<CheckBox>(R.id.showHttpsOnly).setOnCheckedChangeListener { _, checked ->
            app.prefs.showHttpsOnly = checked
        }

        findViewById<Button>(R.id.qualityButton).setOnClickListener {
            val labels = arrayOf("SD / LQ (più leggera)", "HD", "Full HD", "4K")
            AlertDialog.Builder(this)
                .setTitle("Qualità predefinita")
                .setSingleChoiceItems(labels, app.prefs.preferredQuality - 1) { d, which ->
                    app.prefs.preferredQuality = which + 1
                    updateQualityButton()
                    d.dismiss()
                }
                .setNegativeButton("Annulla", null)
                .show()
        }

        findViewById<Button>(R.id.updateCheckButton).apply {
            text = "⬆ Verifica aggiornamenti  (installata ${app.versionName})"
            setOnClickListener { UpdateUi.checkAndInstall(this@SettingsActivity) }
        }

        findViewById<Button>(R.id.minRatingButton).setOnClickListener {
            val values = doubleArrayOf(6.0, 6.5, 7.0, 7.5, 8.0)
            val labels = values.map { String.format(Locale.ITALY, "%.1f", it) }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Voto minimo per «Da non perdere»")
                .setSingleChoiceItems(labels, values.indexOfFirst { kotlin.math.abs(it - app.prefs.minRating) < 0.01 }) { d, which ->
                    app.prefs.minRating = values[which]
                    updateMinRatingButton()
                    d.dismiss()
                }
                .setNegativeButton("Annulla", null)
                .show()
        }

        findViewById<Button>(R.id.testTmdbButton).setOnClickListener { b ->
            val key = findViewById<EditText>(R.id.tmdbKey).text.toString().trim()
            if (!Tmdb.isValidKey(key)) return@setOnClickListener toast("Inserisci la chiave API TMDB (32 caratteri) o il token di lettura (eyJ…)")
            if (!app.vpn.isUp) return@setOnClickListener toast("Prima connetti la VPN (torna alla guida)")
            (b as Button).text = "Prova TMDB: cerco «Il gladiatore»…"
            lifecycleScope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching { Tmdb(app.http) { key }.lookup("Il gladiatore", 2000, series = false) }
                }
                b.text = "Prova TMDB"
                if (result.isSuccess) app.prefs.tmdbKey = key
                AlertDialog.Builder(this@SettingsActivity)
                    .setTitle("TMDB")
                    .setMessage(
                        result.fold(
                            onSuccess = { r ->
                                if (r != null) "Funziona ✓  (chiave salvata)\nIl gladiatore: ${Format.rating(r)}  ·  ${r.votes} voti"
                                else "La chiave funziona ma «Il gladiatore» non è stato trovato."
                            },
                            onFailure = { e -> "TMDB non raggiungibile: ${e.message}" },
                        )
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
        }

        findViewById<Button>(R.id.addXtreamButton).setOnClickListener {
            val error = addXtream(
                server = findViewById<EditText>(R.id.xtreamServer).text.toString(),
                user = findViewById<EditText>(R.id.xtreamUser).text.toString(),
                pass = findViewById<EditText>(R.id.xtreamPass).text.toString(),
                hls = findViewById<CheckBox>(R.id.xtreamHls).isChecked,
            )
            if (error != null) {
                toast(error)
            } else {
                findViewById<EditText>(R.id.xtreamServer).setText("")
                findViewById<EditText>(R.id.xtreamUser).setText("")
                findViewById<EditText>(R.id.xtreamPass).setText("")
                renderXtream()
                toast("Account Xtream aggiunto: i canali si caricano tornando alla guida")
            }
        }

        findViewById<Button>(R.id.pickFileButton).setOnClickListener {
            try {
                pickFile.launch(arrayOf("*/*"))
            } catch (e: ActivityNotFoundException) {
                toast("Questo dispositivo non ha un selettore file: carica il file dal telefono (indirizzo in alto).")
            }
        }

        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            if (!app.prefs.isConfigured) return@setOnClickListener toast("Prima salva la configurazione")
            app.prefs.lastM3u = 0L
            app.prefs.lastEpg = 0L
            applyAndClose(reconnect = false)
        }

        findViewById<Button>(R.id.manageChannelsButton).setOnClickListener {
            if (!app.repo.hasChannels()) return@setOnClickListener toast("Prima configura e carica la lista dei canali")
            startActivity(Intent(this, BrowseActivity::class.java))
            finish()
        }

        findViewById<Button>(R.id.changeServerButton).setOnClickListener {
            if (!app.prefs.isConfigured) return@setOnClickListener toast("Prima salva la configurazione")
            app.prefs.avoidRelay = app.prefs.relayHost
            app.prefs.relayHost = ""
            toast("Alla riconnessione verrà scelto un altro server Mullvad")
            applyAndClose(reconnect = true)
        }

        findViewById<Button>(R.id.regenKeyButton).setOnClickListener {
            if (!app.prefs.isConfigured) return@setOnClickListener toast("Prima salva la configurazione")
            app.vpn.resetKey()
            toast("Nuova chiave alla prossima connessione. Rimuovi il vecchio dispositivo dal tuo account Mullvad (max 5).")
            applyAndClose(reconnect = true)
        }

        onBackPressedDispatcher.addCallback(this) {
            if (app.prefs.isConfigured) finish() else finishAffinity()
        }
    }

    override fun onStart() {
        super.onStart()
        startServer()
    }

    override fun onStop() {
        super.onStop()
        server?.stop()
        server = null
    }

    // ---------- Configurazione dal telefono ----------

    private fun startServer() {
        val ip = ConfigServer.localIp()
        if (ip == null) {
            phoneInfo.text = "Configurazione dal telefono non disponibile: Fire Stick non connesso alla rete locale."
            return
        }
        val s = ConfigServer(
            pin = pin,
            uploadDir = filesDir,
            onUpload = { tmp -> storeM3uFile(tmp) },
            onConfig = { form -> onPhoneConfig(form) },
            onCurrent = { currentJson() },
        )
        try {
            val port = s.start()
            server = s
            phoneInfo.text = "Dal telefono (stessa Wi-Fi) apri  http://$ip:$port    PIN  $pin"
        } catch (e: IOException) {
            phoneInfo.text = "Configurazione dal telefono non disponibile: ${e.message}"
        }
    }

    /** Dati attuali per precompilare la pagina del telefono. Mai password né account completo. */
    private fun currentJson(): String {
        val p = app.prefs
        val acc = p.mullvadAccount
        val f = app.localM3uFile
        val sb = StringBuilder("{")
        sb.append("\"m3u\":[").append(p.m3uLinks().joinToString(",") { ConfigServer.json(it) }).append("],")
        sb.append("\"epg\":").append(ConfigServer.json(p.epgUrl)).append(',')
        sb.append("\"country\":").append(ConfigServer.json(p.country)).append(',')
        sb.append("\"account\":").append(ConfigServer.json(if (acc.length == 16) "•••• ${acc.takeLast(4)}" else "")).append(',')
        sb.append("\"localFile\":").append(ConfigServer.json(if (f.exists()) "${f.length() / 1024} KB" else "")).append(',')
        sb.append("\"localUsed\":").append(p.isLocalM3u).append(',')
        sb.append("\"quality\":").append(p.preferredQuality).append(',')
        sb.append("\"tmdb\":").append(ConfigServer.json(if (p.tmdbKey.length > 4) "•••• ${p.tmdbKey.takeLast(4)}" else "")).append(',')
        sb.append("\"xtream\":[").append(p.xtreamAccounts.joinToString(",") { ConfigServer.json("${it.label} (${it.ext})") }).append("]")
        return sb.append('}').toString()
    }

    /** Chiamato sul thread del server. I campi vuoti mantengono il valore attuale. */
    private fun onPhoneConfig(form: Map<String, String>): String? {
        val p = app.prefs
        val prefilled = form["prefilled"] == "1"
        // Rimozione account Xtream selezionati sulla pagina.
        val remove = form["xremove"].orEmpty().split(',').mapNotNull { it.trim().toIntOrNull() }.toSet()
        if (remove.isNotEmpty()) {
            synchronized(this) {
                p.xtreamAccounts = p.xtreamAccounts.filterIndexed { i, _ -> i !in remove }
                p.lastM3u = 0L
                app.configDirty = true
            }
        }
        // Account Xtream dal telefono (facoltativo): aggiunto prima, così vale anche senza link M3U.
        val xServer = form["xserver"].orEmpty().trim()
        if (xServer.isNotEmpty()) {
            addXtream(xServer, form["xuser"].orEmpty(), form["xpass"].orEmpty(), form["xhls"] != "0")?.let { return it }
        }
        if (prefilled) form["quality"]?.toIntOrNull()?.let { p.preferredQuality = it }
        form["tmdb"]?.trim()?.takeIf { it.isNotEmpty() }?.let { k ->
            if (!Tmdb.isValidKey(k)) return "Chiave TMDB non valida: 32 caratteri (API Key) oppure il token di lettura eyJ…"
            p.tmdbKey = k
        }
        // Pagina precompilata: il contenuto del campo è la lista voluta (anche vuota).
        // Pagina non precompilata: link vuoti = mantieni quelli attuali.
        val typed = Prefs.splitSources(form["m3u"].orEmpty())
        val links = if (prefilled) typed else typed.ifEmpty { p.m3uLinks() }
        val withFile = app.localM3uFile.exists() && when (form["local"]) {
            "1" -> true
            "0" -> false
            else -> p.isLocalM3u
        }
        val m3u = (links + if (withFile) listOf(Prefs.LOCAL_M3U) else emptyList()).joinToString("\n")
        val result = applyConfig(
            m3u = m3u,
            epg = if (prefilled) form["epg"].orEmpty().trim() else form["epg"]?.trim()?.ifEmpty { null } ?: p.epgUrl,
            account = form["account"]?.ifBlank { null } ?: p.mullvadAccount,
            country = form["country"]?.ifBlank { null } ?: p.country,
        )
        if (result.error == null) {
            runOnUiThread {
                fillFields()
                toast("Configurazione ricevuta dal telefono")
                applyAndClose(result.reconnect)
            }
        }
        return result.error
    }

    // ---------- Logica comune ----------

    private class Result(val error: String?, val reconnect: Boolean = false)

    /** Valida e salva. Usata sia dal telecomando sia dal telefono. */
    @Synchronized
    private fun applyConfig(m3u: String, epg: String, account: String, country: String): Result {
        val p = app.prefs
        val newAccount = account.filter { it.isDigit() }
        val newCountry = country.trim().lowercase().ifEmpty { "it" }

        val sources = Prefs.splitSources(m3u)
        if (sources.isEmpty() && p.xtreamAccounts.isEmpty()) {
            return Result("Inserisci almeno un link M3U https://, un file o un account Xtream")
        }
        if (sources.size > Prefs.MAX_M3U) return Result("Massimo ${Prefs.MAX_M3U} liste M3U")
        if (Prefs.LOCAL_M3U in sources && !app.localM3uFile.exists()) return Result("Nessun file M3U caricato")
        sources.filter { it != Prefs.LOCAL_M3U }.firstOrNull { !it.startsWith("https://", ignoreCase = true) }?.let {
            return Result(
                if (it.startsWith("http://", ignoreCase = true)) "Link M3U non HTTPS, non accettato: ${it.take(50)}"
                else "Link M3U non valido: ${it.take(50)}"
            )
        }
        val epgLinks = epg.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (epgLinks.any { !it.startsWith("https://", ignoreCase = true) }) {
            return Result("I link EPG devono essere tutti HTTPS (https://), separati da virgola")
        }
        if (newAccount.length != 16) return Result("Il numero account Mullvad ha 16 cifre")
        if (!newCountry.matches(Regex("[a-z]{2}"))) return Result("Paese: usa un codice di 2 lettere (es. it)")

        val accountChanged = newAccount != p.mullvadAccount
        val reconnect = accountChanged || newCountry != p.country
        if (accountChanged) app.vpn.resetKey()
        if (m3u != p.m3uUrl) p.lastM3u = 0L
        if (epg != p.epgUrl) p.lastEpg = 0L
        if (reconnect) p.relayHost = ""

        p.m3uUrl = m3u
        p.epgUrl = epg
        p.mullvadAccount = newAccount
        p.country = newCountry
        return Result(null, reconnect)
    }

    /** Valida un file M3U appena ricevuto e lo rende la lista locale. Restituisce un errore o null. */
    private fun storeM3uFile(tmp: File): String? {
        val head = ByteArray(64 * 1024)
        val n = tmp.inputStream().use { it.read(head) }
        val gzip = n >= 2 && head[0] == 0x1f.toByte() && head[1] == 0x8b.toByte()
        val text = if (n > 0) String(head, 0, n, Charsets.UTF_8) else ""
        if (!gzip && !text.contains("#EXTINF", ignoreCase = true) && !text.contains("#EXTM3U", ignoreCase = true)) {
            tmp.delete()
            return "Il file non sembra una lista M3U"
        }
        val target = app.localM3uFile
        target.delete()
        if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
        app.prefs.lastM3u = 0L   // forza la reimportazione
        runOnUiThread { updateLocalInfo() }
        return null
    }

    private fun fillFields() {
        val p = app.prefs
        m3uField.setText(p.m3uLinks().joinToString("\n"))
        includeLocal.isChecked = p.isLocalM3u
        epgField.setText(p.epgUrl)
        accountField.setText(p.mullvadAccount)
        countryField.setText(p.country)
        allowHttp.isChecked = !p.httpsOnlyStreams
        findViewById<CheckBox>(R.id.softwareDecoders).isChecked = p.softwareDecoders
        findViewById<CheckBox>(R.id.autoChannelOrder).isChecked = p.autoChannelOrder
        findViewById<CheckBox>(R.id.mergeQualities).isChecked = p.mergeQualities
        findViewById<CheckBox>(R.id.showHttpsOnly).isChecked = p.showHttpsOnly
        findViewById<CheckBox>(R.id.ratingsEnabled).isChecked = p.ratingsEnabled
        findViewById<EditText>(R.id.tmdbKey).setText(p.tmdbKey)
        updateQualityButton()
        updateMinRatingButton()
        findViewById<TextView>(R.id.vpnInfo).text =
            if (p.relayHost.isNotEmpty()) "Ultimo server Mullvad: ${p.relayHost}" else ""
        updateLocalInfo()
        renderXtream()
    }

    // ---------- Xtream ----------

    /** Aggiunge un account Xtream. Restituisce un errore o null. Chiamabile anche dal thread del server. */
    @Synchronized
    private fun addXtream(server: String, user: String, pass: String, hls: Boolean): String? {
        val base = server.trim().trimEnd('/')
        if (!base.startsWith("https://", ignoreCase = true)) {
            return if (base.startsWith("http://", ignoreCase = true)) "Server Xtream non HTTPS: per sicurezza non è accettato"
            else "Inserisci il server Xtream con https://"
        }
        if (user.isBlank() || pass.isBlank()) return "Inserisci utente e password Xtream"
        val current = app.prefs.xtreamAccounts
        if (current.size >= 5) return "Massimo 5 account Xtream"
        app.prefs.xtreamAccounts = current + XtreamAccount(base, user.trim(), pass.trim(), if (hls) "m3u8" else "ts")
        app.prefs.lastM3u = 0L
        app.configDirty = true
        return null
    }

    /** Elenco degli account: un pulsante per account, OK/tocco per rimuoverlo. */
    private fun renderXtream() {
        val box = findViewById<LinearLayout>(R.id.xtreamList)
        box.removeAllViews()
        for (acc in app.prefs.xtreamAccounts) {
            val b = Button(this)
            b.text = "✕  ${acc.label}  (${acc.ext})"
            b.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Rimuovere l'account Xtream?")
                    .setMessage(acc.label)
                    .setPositiveButton("Rimuovi") { _, _ ->
                        app.prefs.xtreamAccounts = app.prefs.xtreamAccounts.filter { it != acc }
                        app.prefs.lastM3u = 0L
                        app.configDirty = true
                        renderXtream()
                    }
                    .setNegativeButton("Annulla", null)
                    .show()
            }
            box.addView(b)
        }
    }

    private fun updateMinRatingButton() {
        findViewById<Button>(R.id.minRatingButton).text =
            "Voto minimo «Da non perdere»: TMDB ★ ${String.format(Locale.ITALY, "%.1f", app.prefs.minRating)}"
    }

    private fun updateQualityButton() {
        findViewById<Button>(R.id.qualityButton).text =
            "Qualità predefinita: ${ChannelNames.qualityLabel(app.prefs.preferredQuality)}  (poi nel player puoi cambiarla)"
    }

    private fun updateLocalInfo() {
        val f = app.localM3uFile
        localInfo.text = if (f.exists()) "File M3U caricato: ${f.length() / 1024} KB" else "Nessun file M3U caricato"
        includeLocal.isEnabled = f.exists()
        if (!f.exists()) includeLocal.isChecked = false
    }

    private fun applyAndClose(reconnect: Boolean) {
        lifecycleScope.launch {
            if (reconnect) app.vpn.disconnect()
            app.configDirty = true
            finish()
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
