plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "it.gerry.iptvlite"
    compileSdk = 35

    defaultConfig {
        applicationId = "it.gerry.iptvlite"
        minSdk = 25          // Fire OS 6 (Android 7.1) e successivi
        targetSdk = 35
        versionCode = 34
        versionName = "0.22.1"
    }

    // Chiave fissa inclusa nel progetto: ogni build (PC o GitHub) ha la stessa firma,
    // così gli aggiornamenti si installano sopra la versione precedente.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    lint {
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true   // richiesto dalla libreria WireGuard
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val media3 = "1.5.1"

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.wireguard.android:tunnel:1.0.20230706")

    // Google Cast (Chromecast / TV con Google TV). Sui dispositivi senza servizi Google (Fire Stick) resta inattivo.
    implementation("com.google.android.gms:play-services-cast-framework:21.5.0")

    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.media3:media3-datasource-okhttp:$media3")

    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.3")
}
