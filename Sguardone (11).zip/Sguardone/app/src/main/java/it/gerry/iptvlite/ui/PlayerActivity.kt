package it.gerry.iptvlite.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.annotation.OptIn
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.C
import androidx.media3.common.Format as MediaFormat
import androidx.media3.common.MediaItem
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.cast.CastManager
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.ChannelNames
import it.gerry.iptvlite.data.Repository
import it.gerry.iptvlite.vpn.VpnManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Player a schermo intero.
 * Telecomando: SU/GIÙ cambia canale, OK info, SINISTRA lista canali rapida, Menu preferito,
 *              Play/Pausa = pausa con buffer, INDIETRO esce.
 * Touch: tocco = info, doppio tocco = pausa con buffer, tocco sul lato sinistro o scorrimento
 *        verso destra = lista canali, scorrimento su/giù = cambio canale.
 */
@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_GROUP = "group"
        private const val EXTRA_INDEX = "index"
        private const val EXTRA_CHANNEL_NAME = "channel_name"
        private const val EXTRA_EXACT = "exact"
        private const val EXTRA_CHANNEL_ID = "channel_id"
        private const val EXTRA_CHANNEL_HINT = "channel_hint"
        private const val MAX_BUFFER_MS = 120_000L

        /**
         * Lettura MPEG-TS tollerante: accetta keyframe non marcati correttamente e ricostruisce
         * i confini dei fotogrammi. Riduce i blocchi verdi all'avvio con stream "sporchi".
         */
        private const val TS_FLAGS =
            DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
        private val AUTO_TARGETS_MS = longArrayOf(0L, 5_000L, 10_000L, 20_000L)

        /**
         * Apre il canale scelto, con lo zapping dentro [group]. Si passa il canale preciso (id e nome),
         * non la sua posizione: la lista può essere cambiata nel frattempo (scheda, filtro, aggiornamenti).
         */
        fun start(context: Context, group: String, channel: Channel) {
            context.startActivity(
                Intent(context, PlayerActivity::class.java)
                    .putExtra(EXTRA_GROUP, group)
                    .putExtra(EXTRA_CHANNEL_ID, channel.id)
                    .putExtra(EXTRA_CHANNEL_HINT, channel.name)
            )
        }

        /** Canale chiesto dal telefono ("Trasmetti a Sguardone"): sostituisce il player già aperto. */
        fun startRemote(context: Context, channelName: String) {
            context.startActivity(
                Intent(context, PlayerActivity::class.java)
                    .putExtra(EXTRA_CHANNEL_NAME, channelName)
                    .putExtra(EXTRA_EXACT, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }

        /** Apre un canale per nome (ricerca, promemoria, in evidenza). Lo zapping resta nei preferiti o nel suo gruppo. */
        fun startByName(context: Context, channelName: String) {
            context.startActivity(
                Intent(context, PlayerActivity::class.java).putExtra(EXTRA_CHANNEL_NAME, channelName)
            )
        }
    }

    private val app by lazy { application as App }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var playerView: PlayerView
    private lateinit var overlay: View
    private lateinit var overlayNumber: TextView
    private lateinit var overlayLogo: ImageView
    private lateinit var overlayName: TextView
    private lateinit var overlayTitle: TextView
    private lateinit var overlayTime: TextView
    private lateinit var overlayProgress: ProgressBar
    private lateinit var overlayNext: TextView
    private lateinit var message: TextView
    private lateinit var channelPanel: View
    private lateinit var panelList: RecyclerView
    private lateinit var panelAdapter: RowAdapter<Channel>
    private val numbers = HashMap<Long, Int>()
    private lateinit var gestures: GestureDetector

    private val backWhenPanelOpen = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = closePanel()
    }

    private var player: ExoPlayer? = null
    private var dataSourceFactory: OkHttpDataSource.Factory? = null
    private val extractors by lazy { DefaultExtractorsFactory().setTsExtractorFlags(TS_FLAGS) }
    private var channels: List<Channel> = emptyList()

    /** Categoria (scheda/cartella) della lista dei canali nel pannello a sinistra. */
    @Volatile private var currentGroup: String = Repository.ALL
    private var index = 0
    private var retries = 0

    private val hideOverlay = Runnable { overlay.visibility = View.GONE }

    private var digitBuffer = ""
    private val digitCommit = Runnable {
        val n = digitBuffer.toIntOrNull()
        digitBuffer = ""
        val i = channels.indexOfFirst { it.number == n }
        if (i >= 0) {
            pendingZap?.let { handler.removeCallbacks(it) }
            play(i)
        } else {
            showOverlay(channels.getOrNull(index) ?: return@Runnable)
            overlayName.text = "Canale $n non presente in questa lista"
        }
    }

    // ---------- Buffer ----------
    // A) automatico: se lo stream si blocca, alla ripresa aspetta una riserva crescente (5, 10, 20 s).
    // C) manuale: Play/Pausa (o doppio tocco) mette in pausa, lo stream continua a scaricare e
    //    la barra mostra i secondi accumulati (max 2 minuti); Play riparte da dove eri.
    private lateinit var bufferBox: View
    private lateinit var bufferText: TextView
    private lateinit var bufferProgress: ProgressBar
    private var wasReady = false
    private var bufferLevel = 0
    private var autoHolding = false
    private var manualPaused = false
    private var lastBuffered = -1L
    private var stalledSince = 0L
    private var readySince = 0L
    private var holdStarted = 0L

    private val bufferTicker = object : Runnable {
        override fun run() {
            updateBuffer()
            if (autoHolding || manualPaused) handler.postDelayed(this, 500L)
        }
    }
    private val retryRunnable = Runnable { if (app.vpn.isUp) player?.prepare() }
    private var pendingZap: Runnable? = null

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_READY -> {
                    retries = 0
                    message.visibility = View.GONE
                    if (!wasReady) readySince = System.currentTimeMillis()
                    wasReady = true
                }
                // Buffer automatico (A) solo se lo stream si blocca dopo almeno 15 s di visione regolare:
                // i micro-blocchi dei primi secondi sono normali nelle dirette e li gestisce il player.
                Player.STATE_BUFFERING -> if (
                    wasReady && !manualPaused && !autoHolding &&
                    System.currentTimeMillis() - readySince > 15_000L
                ) startAutoHold()
                else -> Unit
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val p = player ?: return
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            if (causes(error).any { it.message?.contains("non HTTPS") == true }) {
                showMessage("Lo stream usa connessioni non HTTPS: bloccato.\nPuoi consentirlo nelle impostazioni (sconsigliato).")
                return
            }
            val status = causes(error).filterIsInstance<HttpDataSource.InvalidResponseCodeException>()
                .firstOrNull()?.responseCode
            // Riprovare ha senso solo per errori temporanei (rete o server 5xx), non per 4xx.
            val retryable = status == null || status >= 500
            if (retryable && retries < 3 && app.vpn.isUp) {
                retries++
                showMessage("Riconnessione… ($retries/3)")
                handler.removeCallbacks(retryRunnable)
                handler.postDelayed(retryRunnable, 2000L * retries)
            } else {
                showMessage(if (status != null) httpMessage(status) else "Stream non disponibile (${error.errorCodeName})")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        overlayNumber = findViewById(R.id.overlayNumber)
        overlayLogo = findViewById(R.id.overlayLogo)
        overlayName = findViewById(R.id.overlayName)
        overlayTitle = findViewById(R.id.overlayTitle)
        overlayTime = findViewById(R.id.overlayTime)
        overlayProgress = findViewById(R.id.overlayProgress)
        overlayNext = findViewById(R.id.overlayNext)
        message = findViewById(R.id.message)
        bufferBox = findViewById(R.id.bufferBox)
        bufferText = findViewById(R.id.bufferText)
        bufferProgress = findViewById(R.id.bufferProgress)
        bufferProgress.max = (MAX_BUFFER_MS / 1000).toInt()
        channelPanel = findViewById(R.id.channelPanel)
        panelList = findViewById(R.id.panelList)
        setupPanel()
        setupGestures()
        onBackPressedDispatcher.addCallback(this, backWhenPanelOpen)

        index = intent.getIntExtra(EXTRA_INDEX, 0)
        val group = intent.getStringExtra(EXTRA_GROUP) ?: Repository.ALL
        currentGroup = group

        lifecycleScope.launch {
            val chosenId = intent.getLongExtra(EXTRA_CHANNEL_ID, -1L)
            val hint = intent.getStringExtra(EXTRA_CHANNEL_HINT)
            var byName = intent.getStringExtra(EXTRA_CHANNEL_NAME)
            if (chosenId >= 0) {
                // Canale preciso nella scheda/gruppo richiesto (anche se nascosto dal filtro HTTPS).
                val found = withContext(Dispatchers.IO) {
                    val visible = app.repo.visibleChannels(group)
                    val i = visible.indexOfFirst { it.id == chosenId }
                    val chosen = if (i < 0) app.repo.channelById(chosenId) else null
                    val k = chosen?.let { c -> visible.indexOfFirst { app.repo.qualityKey(it.name) == app.repo.qualityKey(c.name) } } ?: -1
                    if (i >= 0) {
                        visible to i
                    } else if (chosen != null && k >= 0) {
                        // Scelta una qualità diversa da quella predefinita: la metto al posto della voce unita.
                        visible.toMutableList().also { it[k] = chosen.copy(number = visible[k].number, variants = visible[k].variants) } to k
                    } else {
                        val all = app.repo.channels(group)
                        val j = all.indexOfFirst { it.id == chosenId }
                        if (j >= 0) all to j else null
                    }
                }
                if (found != null) {
                    channels = found.first
                    index = found.second
                } else {
                    byName = hint   // il gruppo è cambiato: lo cerco per nome
                }
            }
            if (channels.isNotEmpty()) {
                // già trovato sopra
            } else if (byName != null) {
                val name: String = byName
                val (list, idx) = withContext(Dispatchers.IO) {
                    val grp = if (app.repo.isFavorite(name)) Repository.FAVORITES
                    else app.repo.channelByName(name)?.group ?: Repository.ALL
                    currentGroup = grp
                    // Con "Solo HTTPS" il canale richiesto potrebbe essere nascosto: allora uso la lista completa.
                    val visible = app.repo.visibleChannels(grp)
                    val key = app.repo.qualityKey(name)
                    val k = visible.indexOfFirst { app.repo.qualityKey(it.name) == key }
                    val exact = app.repo.channelByName(name)
                    when {
                        visible.any { it.name == name } -> visible to visible.indexOfFirst { it.name == name }
                        // Stesso canale in un'altra qualità: nella qualità predefinita (dalla ricerca)
                        // o proprio quella richiesta (dal telefono).
                        k >= 0 && !intent.getBooleanExtra(EXTRA_EXACT, false) -> visible to k
                        k >= 0 && exact != null ->
                            visible.toMutableList().also { it[k] = exact.copy(number = visible[k].number, variants = visible[k].variants) } to k
                        else -> {
                            val l = app.repo.channels(grp)
                            l to l.indexOfFirst { it.name == name }.coerceAtLeast(0)
                        }
                    }
                }
                channels = list
                index = idx
            } else {
                channels = withContext(Dispatchers.IO) { app.repo.visibleChannels(group) }
            }
            numbers.clear()
            channels.forEachIndexed { i, ch -> numbers[ch.id] = if (ch.number > 0) ch.number else i + 1 }
            panelAdapter.items = channels
            updateGroupButton()
            if (player != null) play(index)
        }

        // Kill-switch applicativo: se il tunnel non è attivo, la riproduzione si ferma subito.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                app.vpn.state.collect { state ->
                    if (state !is VpnManager.State.Up) {
                        player?.stop()
                        showMessage("VPN non attiva: riproduzione bloccata")
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        initPlayer()
        (app.cast.state.value as? CastManager.State.Casting)?.let {
            showMessage("📺 In trasmissione su ${it.device}: ${it.channel}\n«Trasmetti» nella lista a sinistra per cambiare o interrompere")
        }
        if (app.vpn.isUp) {
            if (channels.isNotEmpty()) play(index)
        } else {
            // VPN chiusa per inattività mentre eri fuori dall'app: si ricollega e riparte.
            showMessage("Riconnessione VPN…")
            lifecycleScope.launch {
                try {
                    app.vpn.connect()
                    if (channels.isNotEmpty()) play(index)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    showMessage("VPN non disponibile: ${e.message}")
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // Con la lista aperta i tasti servono a muoversi nella lista.
        if (isPanelOpen()) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                closePanel()
                return true
            }
            return super.onKeyDown(keyCode, event)
        }
        return handlePlayerKey(keyCode, event)
    }

    private fun handlePlayerKey(keyCode: Int, event: KeyEvent): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_DPAD_LEFT -> { openPanel(); true }
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(-1); true }
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(+1); true }
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_INFO -> {
            channels.getOrNull(index)?.let { showOverlay(it) }
            true
        }
        KeyEvent.KEYCODE_MENU -> { toggleFavorite(); true }
        in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
            // Numero del canale come in TV: si conferma da solo dopo 1,5 s.
            digitBuffer += (keyCode - KeyEvent.KEYCODE_0).toString()
            overlayNumber.text = digitBuffer
            overlay.visibility = View.VISIBLE
            handler.removeCallbacks(hideOverlay)
            handler.removeCallbacks(digitCommit)
            handler.postDelayed(digitCommit, 1_500L)
            true
        }
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_CAPTIONS, KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK -> {
            showTracks()
            true
        }
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePause(); true }
        KeyEvent.KEYCODE_MEDIA_PAUSE -> { if (!manualPaused) togglePause(); true }
        KeyEvent.KEYCODE_MEDIA_PLAY -> { if (manualPaused) togglePause(); true }
        else -> super.onKeyDown(keyCode, event)
    }

    // ---------- Trasmissione DLNA alla TV ----------

    private fun onCastButton() {
        val ch = channels.getOrNull(index) ?: return
        val state = app.cast.state.value
        if (state is CastManager.State.Casting) {
            val options = arrayOf("Trasmetti ${ch.name} su ${state.device}", "Scegli un altro dispositivo", "Interrompi la trasmissione")
            AlertDialog.Builder(this)
                .setTitle("📺 In trasmissione su ${state.device}")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> castChannel(ch, null)
                        1 -> chooseDevice(ch)
                        else -> stopCasting()
                    }
                }
                .setNegativeButton("Chiudi", null)
                .show()
        } else {
            chooseDevice(ch)
        }
    }

    private fun chooseDevice(ch: Channel) {
        showMessage("📺 Cerco TV e dispositivi in casa (Sguardone, Google Cast e DLNA)…")
        lifecycleScope.launch {
            val devices = runCatching { app.cast.discover() }.getOrElse { emptyList() }
            message.visibility = View.GONE
            if (devices.isEmpty()) {
                showMessage(
                    "Nessun dispositivo trovato.\n" +
                        "Controlla che la TV sia accesa e sulla stessa rete Wi-Fi " +
                        "(Sguardone aperto sul Fire Stick, Google Cast integrato, oppure condivisione/DLNA attiva)."
                )
                handler.postDelayed({ if (!app.cast.isCasting) message.visibility = View.GONE }, 6_000L)
                return@launch
            }
            AlertDialog.Builder(this@PlayerActivity)
                .setTitle("Trasmetti ${ch.name} su…")
                .setItems(devices.map { it.name }.toTypedArray()) { _, which -> castChannel(ch, devices[which]) }
                .setNegativeButton("Annulla", null)
                .show()
        }
    }

    private fun castChannel(ch: Channel, target: CastManager.Target?) {
        showMessage("📺 Invio ${ch.name} alla TV…")
        lifecycleScope.launch {
            try {
                app.cast.cast(ch, target)
                player?.stop()   // risparmia banda: lo stream va solo alla TV
                val device = (app.cast.state.value as? CastManager.State.Casting)?.device ?: "TV"
                showMessage(
                    "📺 In trasmissione su $device\n${ch.name}\n" +
                        "SU/GIÙ cambia canale sulla TV  ·  «Trasmetti» nella lista a sinistra per interrompere"
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                showMessage("Trasmissione non riuscita: ${e.message}")
            }
        }
    }

    private fun stopCasting() {
        lifecycleScope.launch {
            app.cast.stop()
            message.visibility = View.GONE
            play(index)   // riprende la visione sul dispositivo
        }
    }

    // ---------- Lingue audio e sottotitoli ----------

    /** Preferenze salvate: audio nella lingua scelta (default italiano), sottotitoli solo se scelti. */
    private fun applyTrackPreferences(p: ExoPlayer) {
        val audio = app.prefs.audioLanguage.ifEmpty { "it" }
        val sub = app.prefs.subtitleLanguage
        val b = p.trackSelectionParameters.buildUpon()
            .clearOverrides()
            .setPreferredAudioLanguage(audio)
        if (sub.isEmpty()) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).setPreferredTextLanguage(sub)
        }
        p.trackSelectionParameters = b.build()
    }

    /** (lingue audio, tracce sottotitoli) disponibili nel canale in visione. */
    private fun trackCounts(): Pair<Int, Int> {
        val groups = player?.currentTracks?.groups ?: return 0 to 0
        val audio = groups.filter { it.type == C.TRACK_TYPE_AUDIO }.sumOf { g -> (0 until g.length).count { g.isTrackSupported(it) } }
        val text = groups.filter { it.type == C.TRACK_TYPE_TEXT }.sumOf { g -> (0 until g.length).count { g.isTrackSupported(it) } }
        return audio to text
    }

    private fun showTracks() {
        val ch = channels.getOrNull(index) ?: return
        lifecycleScope.launch {
            val variants = withContext(Dispatchers.IO) { app.repo.variantsOf(ch) }
            if (channels.getOrNull(index)?.id != ch.id) return@launch
            showTracks(variants)
        }
    }

    /** Sostituisce la voce in visione con un'altra qualità/fonte dello stesso canale e la riproduce. */
    private fun switchVariant(v: Channel) {
        val cur = channels.getOrNull(index) ?: return
        if (v.id == cur.id) return
        val list = channels.toMutableList()
        list[index] = v.copy(number = cur.number, variants = cur.variants)
        numbers[v.id] = numbers[cur.id] ?: (index + 1)
        channels = list
        panelAdapter.items = channels
        play(index)
    }

    private fun showTracks(variants: List<Channel>) {
        val p = player ?: return
        val groups = p.currentTracks.groups
        val actions = ArrayList<Pair<String, () -> Unit>>()
        val current = channels.getOrNull(index)

        if (variants.size > 1) {
            val labels = variants.map { ChannelNames.qualityLabel(ChannelNames.quality(it.name)) }
            val repeated = labels.groupingBy { it }.eachCount()
            variants.forEachIndexed { i, v ->
                val mark = if (v.id == current?.id) "●" else "○"
                val extra = buildList {
                    if (repeated[labels[i]]!! > 1 || labels[i] == "SD") add(v.name)
                    if (!v.url.startsWith("https://", ignoreCase = true)) add("http")
                }.joinToString(" · ")
                actions.add("$mark  Qualità:  ${labels[i]}${if (extra.isNotEmpty()) "   ($extra)" else ""}" to { switchVariant(v) })
            }
        }

        for (g in groups.filter { it.type == C.TRACK_TYPE_AUDIO }) {
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val mark = if (g.isTrackSelected(i)) "●" else "○"
                actions.add("$mark  Audio:  ${describe(g.getTrackFormat(i), audio = true)}" to { selectTrack(g, i, audio = true) })
            }
        }
        val textGroups = groups.filter { it.type == C.TRACK_TYPE_TEXT }
        val textTracks = textGroups.sumOf { g -> (0 until g.length).count { g.isTrackSupported(it) } }
        if (textTracks > 0) {
            val off = textGroups.none { it.isSelected }
            actions.add("${if (off) "●" else "○"}  Sottotitoli:  disattivati" to { disableSubtitles() })
            for (g in textGroups) {
                for (i in 0 until g.length) {
                    if (!g.isTrackSupported(i)) continue
                    val mark = if (g.isTrackSelected(i)) "●" else "○"
                    actions.add("$mark  Sottotitoli:  ${describe(g.getTrackFormat(i), audio = false)}" to { selectTrack(g, i, audio = false) })
                }
            }
        }

        val audioCount = actions.count { it.first.contains("Audio:") }
        if (audioCount <= 1 && textTracks == 0 && variants.size <= 1) {
            showOverlay(channels.getOrNull(index) ?: return)
            overlayName.text = "Questo canale ha una sola qualità, una sola lingua e nessun sottotitolo"
            return
        }
        AlertDialog.Builder(this)
            .setTitle(if (variants.size > 1) "Qualità, audio e sottotitoli" else "Audio e sottotitoli")
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun selectTrack(g: Tracks.Group, i: Int, audio: Boolean) {
        val p = player ?: return
        val type = if (audio) C.TRACK_TYPE_AUDIO else C.TRACK_TYPE_TEXT
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i))
            .build()
        // La lingua scelta diventa la preferita anche per gli altri canali.
        val lang = g.getTrackFormat(i).language.orEmpty()
        if (audio) app.prefs.audioLanguage = lang else app.prefs.subtitleLanguage = lang.ifEmpty { "und" }
    }

    private fun disableSubtitles() {
        val p = player ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .build()
        app.prefs.subtitleLanguage = ""
    }

    /** "Italiano · Dolby Digital 5.1", "Inglese · stereo", "Italiano · DVB". */
    private fun describe(f: MediaFormat, audio: Boolean): String {
        val parts = ArrayList<String>()
        val lang = f.language
        parts.add(
            if (lang.isNullOrBlank() || lang == "und") "Lingua sconosciuta"
            else Locale(lang).getDisplayLanguage(Locale.ITALIAN).replaceFirstChar { it.uppercase() }.ifEmpty { lang }
        )
        f.label?.takeIf { it.isNotBlank() && !parts[0].equals(it, ignoreCase = true) }?.let { parts.add(it) }
        if (audio) {
            when (f.sampleMimeType) {
                MimeTypes.AUDIO_AC3 -> parts.add("Dolby Digital")
                MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC -> parts.add("Dolby Digital+")
                MimeTypes.AUDIO_AAC -> parts.add("AAC")
                MimeTypes.AUDIO_MPEG, MimeTypes.AUDIO_MPEG_L2 -> parts.add("MPEG")
            }
            when (f.channelCount) {
                1 -> parts.add("mono")
                2 -> parts.add("stereo")
                6 -> parts.add("5.1")
                8 -> parts.add("7.1")
            }
        } else {
            when (f.sampleMimeType) {
                MimeTypes.APPLICATION_DVBSUBS -> parts.add("DVB")
                MimeTypes.APPLICATION_CEA608, MimeTypes.APPLICATION_CEA708 -> parts.add("CC")
                MimeTypes.TEXT_VTT -> parts.add("WebVTT")
            }
            if ((f.selectionFlags and C.SELECTION_FLAG_FORCED) != 0) parts.add("forzati")
        }
        return parts.joinToString("  ·  ")
    }

    // ---------- Buffer: logica ----------

    private fun startAutoHold() {
        val p = player ?: return
        bufferLevel = (bufferLevel + 1).coerceAtMost(AUTO_TARGETS_MS.size - 1)
        autoHolding = true
        holdStarted = System.currentTimeMillis()
        stalledSince = 0L
        lastBuffered = -1L
        p.playWhenReady = false
        bufferBox.visibility = View.VISIBLE
        handler.removeCallbacks(bufferTicker)
        handler.post(bufferTicker)
    }

    private fun togglePause() {
        val p = player ?: return
        if (manualPaused || autoHolding) {
            resumeFromBuffer()
        } else {
            manualPaused = true
            p.playWhenReady = false
            bufferBox.visibility = View.VISIBLE
            handler.removeCallbacks(bufferTicker)
            handler.post(bufferTicker)
        }
    }

    private fun resumeFromBuffer() {
        manualPaused = false
        autoHolding = false
        handler.removeCallbacks(bufferTicker)
        bufferBox.visibility = View.GONE
        player?.playWhenReady = true
    }

    private fun resetBuffer() {
        wasReady = false
        bufferLevel = 0
        manualPaused = false
        autoHolding = false
        handler.removeCallbacks(bufferTicker)
        bufferBox.visibility = View.GONE
    }

    private fun updateBuffer() {
        val p = player ?: return
        val ms = p.totalBufferedDuration
        val sec = (ms / 1000).toInt()
        bufferProgress.progress = sec

        // Se il buffer non cresce da 15 s lo segnalo (rete ferma o server che non invia).
        val now = System.currentTimeMillis()
        if (ms > lastBuffered) {
            lastBuffered = ms
            stalledSince = 0L
        } else if (stalledSince == 0L) {
            stalledSince = now
        }
        val stalled = stalledSince != 0L && now - stalledSince > 15_000L

        if (autoHolding) {
            val target = AUTO_TARGETS_MS[bufferLevel]
            // Riparte quando la riserva è pronta, e comunque mai oltre "riserva + 5 s" di attesa.
            if (ms >= target || now - holdStarted > target + 5_000L) {
                resumeFromBuffer()
                return
            }
            bufferText.text = if (stalled) "Lo stream non sta arrivando: buffer fermo a $sec s"
            else "Stream lento: accumulo riserva  $sec / ${target / 1000} s"
        } else if (manualPaused) {
            val full = ms >= MAX_BUFFER_MS - 2_000L || stalled
            bufferText.text = when {
                full -> "⏸  Buffer pronto: $sec s  ·  premi Play"
                else -> "⏸  In pausa  ·  buffer $sec s  ·  Play quando vuoi"
            }
        }
    }

    /**
     * Cambio canale: l'info del canale si aggiorna subito, lo stream parte solo quando
     * smetti di premere (0,7 s). Così non si aprono tante connessioni verso il fornitore.
     */
    private fun zap(delta: Int) {
        if (channels.isEmpty()) return
        index = ((index + delta) % channels.size + channels.size) % channels.size
        showOverlay(channels[index])
        pendingZap?.let { handler.removeCallbacks(it) }
        pendingZap = Runnable { play(index) }.also { handler.postDelayed(it, 700L) }
    }

    // ---------- Lista canali rapida (lato sinistro) ----------

    private fun setupPanel() {
        panelAdapter = RowAdapter(
            title = { ch -> "${numbers[ch.id] ?: ""}   ${if (app.repo.isFavorite(ch.name)) "★ " else ""}${ch.displayName}" },
            subtitle = { ch -> app.repo.nowPlaying(ch.epgKey)?.let { "${Format.time(it.start)}  ${it.title}" } },
            isActive = { ch -> channels.getOrNull(index)?.id == ch.id },
            onClick = { _, pos ->
                closePanel()
                pendingZap?.let { handler.removeCallbacks(it) }
                play(pos)
            },
            onLongClick = { ch, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { app.repo.toggleFavorite(ch.name) }
                    panelAdapter.refreshRows()
                }
            },
        )
        panelList.layoutManager = LinearLayoutManager(this)
        panelList.adapter = panelAdapter
        panelList.itemAnimator = null
        findViewById<View>(R.id.panelClose).setOnClickListener { closePanel() }
        findViewById<View>(R.id.panelGroup).setOnClickListener { chooseGroup() }
        findViewById<View>(R.id.panelCast).setOnClickListener {
            closePanel()
            onCastButton()
        }
        findViewById<View>(R.id.panelTracks).setOnClickListener {
            closePanel()
            showTracks()
        }
        val compat = findViewById<TextView>(R.id.panelCompat)
        fun renderCompat() {
            compat.text = if (app.prefs.softwareDecoders) "Compatibilità: SÌ" else "Compatibilità: NO"
        }
        renderCompat()
        compat.setOnClickListener {
            app.prefs.softwareDecoders = !app.prefs.softwareDecoders
            renderCompat()
            // Ricrea il player con il nuovo ordine dei decoder e riprende il canale.
            releasePlayer()
            initPlayer()
            play(index)
            Toast.makeText(
                this,
                if (app.prefs.softwareDecoders) "Modalità compatibilità attiva: decoder software"
                else "Modalità compatibilità disattivata",
                Toast.LENGTH_SHORT,
            ).show()
        }
    }

    // ---------- Cambio categoria dal pannello ----------

    private fun groupLabel(g: String): String = when (g) {
        Repository.FAVORITES, Repository.ALL -> g
        else -> "▤ $g"
    }

    private fun updateGroupButton() {
        findViewById<TextView>(R.id.panelGroup).text = "📂 ${groupLabel(currentGroup)}   ▾"
    }

    /** Elenco delle categorie: preferiti, cartelle preferite, tutti i canali, poi tutte le cartelle. */
    private fun chooseGroup() {
        lifecycleScope.launch {
            val groups = withContext(Dispatchers.IO) {
                val favGroups = app.repo.favoriteGroups()
                val others = app.repo.groups().map { it.name }
                    .filter { it != Repository.FAVORITES && it != Repository.ALL && it !in favGroups }
                listOf(Repository.FAVORITES) + favGroups + Repository.ALL + others
            }
            val labels = groups.map { g ->
                val mark = if (g == currentGroup) "●  " else ""
                mark + if (app.repo.isFavoriteGroup(g)) "★ ${groupLabel(g)}" else groupLabel(g)
            }
            AlertDialog.Builder(this@PlayerActivity)
                .setTitle("Categoria")
                .setItems(labels.toTypedArray()) { _, which -> switchGroup(groups[which]) }
                .setNegativeButton("Annulla", null)
                .show()
        }
    }

    /** Mostra nel pannello i canali della categoria scelta; il canale in visione continua. */
    private fun switchGroup(g: String) {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { app.repo.visibleChannels(g) }
            if (list.isEmpty()) {
                Toast.makeText(this@PlayerActivity, "Nessun canale in ${groupLabel(g)}", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val cur = channels.getOrNull(index)
            currentGroup = g
            channels = list
            numbers.clear()
            list.forEachIndexed { i, ch -> numbers[ch.id] = if (ch.number > 0) ch.number else i + 1 }
            index = cur?.let { c ->
                val key = app.repo.qualityKey(c.name)
                list.indexOfFirst { it.id == c.id || app.repo.qualityKey(it.name) == key }
            }?.takeIf { it >= 0 } ?: 0
            panelAdapter.items = list
            updateGroupButton()
            panelList.scrollToPosition(index)
            panelList.post {
                (panelList.findViewHolderForAdapterPosition(index)?.itemView ?: panelList.getChildAt(0))?.requestFocus()
            }
        }
    }

    private fun isPanelOpen() = channelPanel.visibility == View.VISIBLE

    private fun openPanel() {
        if (channels.isEmpty()) return
        overlay.visibility = View.GONE
        panelAdapter.refreshRows()
        channelPanel.visibility = View.VISIBLE
        backWhenPanelOpen.isEnabled = true
        panelList.scrollToPosition(index)
        panelList.post {
            panelList.findViewHolderForAdapterPosition(index)?.itemView?.requestFocus()
                ?: panelList.requestFocus()
        }
    }

    private fun closePanel() {
        channelPanel.visibility = View.GONE
        backWhenPanelOpen.isEnabled = false
    }

    // ---------- Touch (telefono/tablet) ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            // Tocco lungo: lingue audio e sottotitoli.
            override fun onLongPress(e: MotionEvent) {
                if (!isPanelOpen()) showTracks()
            }

            // Doppio tocco: pausa per accumulare buffer / riprendi.
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!isPanelOpen()) togglePause()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                when {
                    isPanelOpen() -> closePanel()
                    e.x < playerView.width * 0.25f -> openPanel()
                    overlay.visibility == View.VISIBLE -> overlay.visibility = View.GONE
                    else -> channels.getOrNull(index)?.let { showOverlay(it) }
                }
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                val start = e1 ?: return false
                val dx = e2.x - start.x
                val dy = e2.y - start.y
                if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                    if (dx > 120) openPanel() else if (dx < -120) closePanel()
                } else if (kotlin.math.abs(dy) > 120 && !isPanelOpen()) {
                    zap(if (dy < 0) +1 else -1)
                }
                return true
            }
        })
        playerView.setOnTouchListener { _, ev -> gestures.onTouchEvent(ev) }
    }

    private fun toggleFavorite() {
        val ch = channels.getOrNull(index) ?: return
        lifecycleScope.launch {
            val added = withContext(Dispatchers.IO) { app.repo.toggleFavorite(ch.name) }
            showOverlay(ch)
            overlayName.text = (if (added) "★ Aggiunto ai preferiti: " else "Tolto dai preferiti: ") + ch.name
        }
    }

    private fun causes(error: Throwable): List<Throwable> =
        generateSequence(error) { it.cause }.take(10).toList()

    private fun httpMessage(code: Int): String = when (code) {
        401, 403 ->
            "Accesso negato dal server del canale (HTTP $code).\n" +
                "Cause tipiche: il fornitore blocca gli IP VPN, abbonamento scaduto o troppe connessioni.\n" +
                "Prova \"Cambia server VPN\" nelle impostazioni."
        404, 410 ->
            "Canale non trovato (HTTP $code): il link non è più valido.\nAggiorna la lista dalle impostazioni."
        429, 458, 509 ->
            "Troppe connessioni contemporanee (HTTP $code).\nChiudi lo stream su altri dispositivi e riprova tra poco."
        in 500..599 ->
            "Server del canale non disponibile (HTTP $code). Riprova più tardi."
        else -> "Errore dal server del canale (HTTP $code)."
    }

    private fun initPlayer() {
        val dsf = OkHttpDataSource.Factory(app.http).setUserAgent(Repository.DEFAULT_UA)
        dataSourceFactory = dsf
        // Buffer contenuti: avvio rapido e poca RAM, adatti a Fire Stick.
        // Avvio rapido (1,5 s); in pausa continua a scaricare fino a 2 minuti o 64 MB (memoria Fire Stick).
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, MAX_BUFFER_MS.toInt(), 2_500, 5_000)
            .setTargetBufferBytes(64 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()
        // Decoder: se quello scelto fallisce il player ne prova un altro; in "Modalità compatibilità"
        // i decoder software hanno la precedenza (più tolleranti, ma usano più CPU).
        val software = app.prefs.softwareDecoders
        val codecSelector = MediaCodecSelector { mimeType, secure, tunneling ->
            val infos = MediaCodecUtil.getDecoderInfos(mimeType, secure, tunneling)
            if (software) infos.sortedBy { if (it.softwareOnly) 0 else 1 } else infos
        }
        val renderers = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setMediaCodecSelector(codecSelector)
        player = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsf))
            .setLoadControl(loadControl)
            .build()
            .also { p ->
                p.addListener(listener)
                playerView.player = p
            }
    }

    private fun releasePlayer() {
        handler.removeCallbacksAndMessages(null)
        resetBuffer()
        playerView.player = null
        player?.release()
        player = null
    }

    private fun play(target: Int) {
        val p = player ?: return
        if (channels.isEmpty()) return
        index = ((target % channels.size) + channels.size) % channels.size
        val ch = channels[index]
        showOverlay(ch)

        if (!app.vpn.isUp) {
            p.stop()
            showMessage("VPN non attiva: riproduzione bloccata")
            return
        }

        // In trasmissione: il cambio canale va alla TV, il player locale resta fermo.
        val casting = app.cast.state.value
        if (casting is CastManager.State.Casting) {
            p.stop()
            if (casting.channel != ch.name) castChannel(ch, null)   // stesso canale: già sulla TV
            return
        }

        if (app.prefs.httpsOnlyStreams && !ch.url.startsWith("https://", ignoreCase = true)) {
            p.stop()
            showMessage("Canale non HTTPS: bloccato.\nPuoi consentirlo nelle impostazioni (sconsigliato).")
            return
        }

        retries = 0
        resetBuffer()
        applyTrackPreferences(p)
        handler.removeCallbacks(retryRunnable)
        message.visibility = View.GONE
        dataSourceFactory?.setUserAgent(ch.userAgent ?: Repository.DEFAULT_UA)
        dataSourceFactory?.setDefaultRequestProperties(ch.referer?.let { mapOf("Referer" to it) } ?: emptyMap())

        val hls = ch.url.contains(".m3u8", ignoreCase = true)
        val item = MediaItem.Builder()
            .setUri(ch.url)
            .apply { if (hls) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        if (app.prefs.softwareDecoders) {
            // Modalità compatibilità: lettura TS tollerante, per stream .ts diretti e segmenti HLS.
            val dsf = dataSourceFactory ?: return
            val source = if (hls) {
                HlsMediaSource.Factory(dsf)
                    .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, true))
                    .createMediaSource(item)
            } else {
                ProgressiveMediaSource.Factory(dsf, extractors).createMediaSource(item)
            }
            p.setMediaSource(source)
        } else {
            // Lettura standard: quella che funziona meglio con la maggior parte degli stream.
            p.setMediaItem(item)
        }
        p.prepare()
        p.playWhenReady = true
    }

    /** Barra info in stile Sky: numero, logo, nome, programma in onda con avanzamento, successivo. */
    private fun showOverlay(ch: Channel) {
        val star = if (app.repo.isFavorite(ch.name)) "★ " else ""
        overlayNumber.text = (if (ch.number > 0) ch.number else index + 1).toString()
        overlayName.text = "$star${ch.displayName}"
        overlayTitle.text = ""
        overlayTime.text = ""
        overlayNext.text = ""
        overlayProgress.visibility = View.INVISIBLE
        app.logos.load(ch.logo, overlayLogo)
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlay)
        handler.postDelayed(hideOverlay, 5000L)
        lifecycleScope.launch {
            val (now, next) = withContext(Dispatchers.IO) { app.repo.nowNext(ch.epgKey) }
            val nVariants = withContext(Dispatchers.IO) { app.repo.variantsOf(ch).size }
            if (channels.getOrNull(index) != ch) return@launch
            val (nAudio, nText) = trackCounts()
            if (nAudio > 1 || nText > 0 || nVariants > 1) {
                val info = buildList {
                    if (nVariants > 1) add("${ChannelNames.qualityLabel(ChannelNames.quality(ch.name))} · $nVariants qualità")
                    if (nAudio > 1) add("$nAudio lingue")
                    if (nText > 0) add("sottotitoli")
                }.joinToString(" · ")
                overlayName.text = "${overlayName.text}     ▶ $info"
            }
            if (now != null) {
                overlayTitle.text = now.title
                if (app.prefs.ratingsActive && app.repo.looksLikeFilm(now, ch)) {
                    val r = withContext(Dispatchers.IO) { app.repo.cachedRating(now) ?: if (app.vpn.isUp) app.repo.rating(now) else null }
                    if (r != null && channels.getOrNull(index) == ch) overlayTitle.text = "${now.title}   ${Format.rating(r)}"
                }
                overlayTime.text = Format.range(now)
                overlayProgress.progress = Format.progress(now)
                overlayProgress.visibility = View.VISIBLE
            } else {
                overlayTitle.text = if (ch.epgKey == null) "Nessuna guida" else "Nessun programma in corso"
            }
            overlayNext.text = Format.next(next)
        }
    }

    private fun showMessage(text: String) {
        message.text = text
        message.visibility = View.VISIBLE
    }
}
