package it.gerry.iptvlite.ui

import it.gerry.iptvlite.data.Programme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Formattazione condivisa (solo thread principale). */
object Format {
    private val time = SimpleDateFormat("HH:mm", Locale.ITALY)
    private val date = SimpleDateFormat("EEE d MMM", Locale.ITALY)

    fun time(ms: Long): String = time.format(Date(ms))

    fun date(ms: Long): String = date.format(Date(ms)).replaceFirstChar { it.uppercase() }

    fun range(p: Programme): String = "${time(p.start)} – ${time(p.stop)}"

    /** Avanzamento del programma in millesimi (0..1000), per le ProgressBar con max = 1000. */
    fun progress(p: Programme?, now: Long = System.currentTimeMillis()): Int {
        if (p == null || p.stop <= p.start) return 0
        return (((now - p.start) * 1000) / (p.stop - p.start)).toInt().coerceIn(0, 1000)
    }

    fun next(p: Programme?): String = p?.let { "Dopo  ${time(it.start)}  ${it.title}" } ?: ""
}
