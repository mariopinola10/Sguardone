package it.gerry.iptvlite

import android.content.Context

/** Configurazione persistente, salvata nello storage privato dell'app. */
class Prefs(context: Context) {

    companion object {
        /** Valore di m3uUrl quando la lista è un file caricato (salvato in filesDir/playlist.m3u). */
        const val LOCAL_M3U = "local:playlist.m3u"
    }

    val isLocalM3u: Boolean get() = m3uUrl == LOCAL_M3U

    private val sp = context.getSharedPreferences("config", Context.MODE_PRIVATE)

    private fun str(key: String): String = sp.getString(key, "") ?: ""
    private fun putStr(key: String, value: String) = sp.edit().putString(key, value).apply()
    private fun long(key: String): Long = sp.getLong(key, 0L)
    private fun putLong(key: String, value: Long) = sp.edit().putLong(key, value).apply()

    // --- Sorgenti ---
    var m3uUrl: String
        get() = str("m3u_url")
        set(v) = putStr("m3u_url", v.trim())

    /** URL XMLTV inserito a mano (ha priorità su quello trovato nella lista M3U). */
    var epgUrl: String
        get() = str("epg_url")
        set(v) = putStr("epg_url", v.trim())

    /** URL XMLTV letto dall'intestazione #EXTM3U (url-tvg / x-tvg-url). */
    var detectedEpgUrl: String
        get() = str("epg_url_detected")
        set(v) = putStr("epg_url_detected", v.trim())

    // --- Mullvad ---
    var mullvadAccount: String
        get() = str("mullvad_account")
        set(v) = putStr("mullvad_account", v.filter { it.isDigit() })

    /** Codice paese dei server (es. it, ch, de, nl). */
    var country: String
        get() = str("country").ifEmpty { "it" }
        set(v) = putStr("country", v.trim().lowercase())

    var wgPrivateKey: String
        get() = str("wg_private_key")
        set(v) = putStr("wg_private_key", v)

    /** Indirizzi del tunnel assegnati da Mullvad, es. "10.64.1.2/32,fc00:bbbb:...:/128". */
    var wgAddresses: String
        get() = str("wg_addresses")
        set(v) = putStr("wg_addresses", v.trim())

    /** Server da evitare alla prossima connessione ("Cambia server VPN"). */
    var avoidRelay: String
        get() = str("avoid_relay")
        set(v) = putStr("avoid_relay", v)

    var relayHost: String
        get() = str("relay_host")
        set(v) = putStr("relay_host", v)

    // --- Sicurezza ---
    /** Se true (default) ogni connessione verso stream e segmenti deve essere HTTPS. */
    var httpsOnlyStreams: Boolean
        get() = sp.getBoolean("https_only_streams", true)
        set(v) = sp.edit().putBoolean("https_only_streams", v).apply()

    /** Versione delle regole EPG: se cambia, la guida viene riscaricata al prossimo avvio. */
    var epgRules: Int
        get() = sp.getInt("epg_rules", 1)
        set(v) = sp.edit().putInt("epg_rules", v).apply()

    // --- Aggiornamenti ---
    var lastM3u: Long
        get() = long("last_m3u")
        set(v) = putLong("last_m3u", v)

    var lastEpg: Long
        get() = long("last_epg")
        set(v) = putLong("last_epg", v)

    val isConfigured: Boolean
        get() = m3uUrl.isNotBlank() && mullvadAccount.length == 16
}
