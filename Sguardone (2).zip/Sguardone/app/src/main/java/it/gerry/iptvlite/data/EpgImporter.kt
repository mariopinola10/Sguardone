package it.gerry.iptvlite.data

import android.database.sqlite.SQLiteDatabase
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.util.Calendar
import java.util.TimeZone

/**
 * Import XMLTV in streaming (XmlPullParser): memoria costante anche con file da centinaia di MB.
 * Tiene solo i programmi da 2 ore fa a 48 ore avanti e solo per i canali presenti nella lista.
 * Va chiamato dentro una transazione aperta dal chiamante.
 */
class EpgImporter(private val db: SQLiteDatabase) {

    private val utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
    private val tzRegex = Regex("""([+-])(\d{2})(\d{2})""")
    private val qualitySuffix = Regex("(fhd|uhd|hd|sd|4k|hevc)$")

    fun import(input: InputStream, now: Long): Int {
        val from = now - 2 * HOUR
        val to = now + 48 * HOUR

        // Indici dei canali M3U per l'abbinamento: prima tvg-id, poi nome normalizzato.
        val byTvgId = HashMap<String, MutableList<Long>>()
        val byName = HashMap<String, MutableList<Long>>()
        db.rawQuery("SELECT id, tvg_id, tvg_name, name FROM channels", null).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (!c.isNull(1)) byTvgId.getOrPut(c.getString(1).lowercase()) { mutableListOf() }.add(id)
                if (!c.isNull(2)) byName.getOrPut(norm(c.getString(2))) { mutableListOf() }.add(id)
                byName.getOrPut(norm(c.getString(3))) { mutableListOf() }.add(id)
            }
        }

        db.delete("programmes", null, null)
        db.execSQL("UPDATE channels SET epg_key = NULL")
        val update = db.compileStatement("UPDATE channels SET epg_key = ? WHERE id = ?")
        val insert = db.compileStatement(
            "INSERT INTO programmes(epg_key, start, stop, title, descr) VALUES(?, ?, ?, ?, ?)"
        )

        val resolved = HashMap<String, Boolean>()
        fun resolve(xmlId: String, names: List<String>): Boolean {
            resolved[xmlId]?.let { return it }
            val ids = LinkedHashSet<Long>()
            byTvgId[xmlId.lowercase()]?.let { ids.addAll(it) }
            if (ids.isEmpty()) names.forEach { n -> byName[norm(n)]?.let { ids.addAll(it) } }
            for (id in ids) {
                update.bindString(1, xmlId)
                update.bindLong(2, id)
                update.executeUpdateDelete()
            }
            return ids.isNotEmpty().also { resolved[xmlId] = it }
        }

        val parser = Xml.newPullParser()
        runCatching { parser.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true) }
        parser.setInput(input, null)

        var count = 0
        var channelId: String? = null
        val channelNames = ArrayList<String>()
        var progKey: String? = null
        var start = 0L
        var stop = 0L
        var title: String? = null
        var desc: String? = null

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "channel" -> {
                        channelId = parser.getAttributeValue(null, "id")
                        channelNames.clear()
                    }
                    "display-name" -> if (channelId != null) channelNames.add(parser.nextText())
                    "programme" -> {
                        val ch = parser.getAttributeValue(null, "channel")
                        start = parseTime(parser.getAttributeValue(null, "start"))
                        stop = parseTime(parser.getAttributeValue(null, "stop")).let { if (it > 0) it else start + HOUR }
                        progKey = if (ch != null && start > 0 && stop > from && start < to && resolve(ch, emptyList())) ch else null
                        title = null
                        desc = null
                    }
                    "title" -> if (progKey != null && title == null) title = parser.nextText()
                    "desc" -> if (progKey != null && desc == null) desc = parser.nextText()
                }

                XmlPullParser.END_TAG -> when (parser.name) {
                    "channel" -> {
                        channelId?.let { resolve(it, channelNames) }
                        channelId = null
                    }
                    "programme" -> {
                        val key = progKey
                        val t = title
                        if (key != null && !t.isNullOrBlank()) {
                            insert.bindString(1, key)
                            insert.bindLong(2, start)
                            insert.bindLong(3, stop)
                            insert.bindString(4, t.trim())
                            insert.bindOrNull(5, desc?.trim()?.takeIf { it.isNotEmpty() })
                            insert.executeInsert()
                            count++
                        }
                        progKey = null
                    }
                }
            }
            event = parser.next()
        }
        return count
    }

    /** Formato XMLTV: "20261111203000 +0100" (secondi e fuso opzionali). */
    private fun parseTime(s: String?): Long {
        if (s == null || s.length < 12) return -1
        return try {
            utc.clear()
            val seconds = if (s.length >= 14 && s[12].isDigit() && s[13].isDigit()) s.substring(12, 14).toInt() else 0
            utc.set(
                s.substring(0, 4).toInt(), s.substring(4, 6).toInt() - 1, s.substring(6, 8).toInt(),
                s.substring(8, 10).toInt(), s.substring(10, 12).toInt(), seconds,
            )
            var t = utc.timeInMillis
            tzRegex.find(s, 12)?.let { m ->
                val sign = if (m.groupValues[1] == "-") -1 else 1
                t -= sign * (m.groupValues[2].toInt() * 60 + m.groupValues[3].toInt()) * 60_000L
            }
            t
        } catch (e: NumberFormatException) {
            -1
        }
    }

    /** "Rai 1 HD" -> "rai1": abbinamento tollerante quando manca il tvg-id. */
    private fun norm(s: String): String =
        s.lowercase().filter { it.isLetterOrDigit() }.replace(qualitySuffix, "")

    private companion object {
        const val HOUR = 3_600_000L
    }
}
