package it.gerry.iptvlite.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import android.widget.ImageView
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.Executors

/**
 * Caricatore di loghi minimale (nessuna libreria esterna):
 * - solo HTTPS e solo con VPN attiva
 * - immagini ridotte a misura di riga (max ~160x90 px), cache in RAM da 4 MB
 * - cache su disco da 20 MB tramite OkHttp
 * - 2 thread: non rallenta lo scorrimento
 */
class LogoLoader(
    http: OkHttpClient,
    cacheDir: File,
    private val allowed: () -> Boolean,
) {
    private val client = http.newBuilder()
        .cache(Cache(File(cacheDir, "logos"), 20L * 1024 * 1024))
        .build()

    private val memory = object : LruCache<String, Bitmap>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val failed = HashSet<String>()
    private val executor = Executors.newFixedThreadPool(2) { r -> Thread(r, "logo").apply { isDaemon = true } }
    private val main = Handler(Looper.getMainLooper())

    fun load(url: String?, view: ImageView) {
        view.tag = url
        if (url.isNullOrBlank() || !url.startsWith("https://", ignoreCase = true)) {
            view.setImageDrawable(null)
            view.visibility = View.INVISIBLE
            return
        }
        memory.get(url)?.let {
            view.setImageBitmap(it)
            view.visibility = View.VISIBLE
            return
        }
        view.setImageDrawable(null)
        view.visibility = View.INVISIBLE
        if (!allowed() || synchronized(failed) { url in failed }) return

        executor.execute {
            val bitmap = runCatching { fetch(url) }.getOrNull()
            if (bitmap == null) {
                synchronized(failed) { failed.add(url) }
            } else {
                memory.put(url, bitmap)
                main.post {
                    if (view.tag == url) {
                        view.setImageBitmap(bitmap)
                        view.visibility = View.VISIBLE
                    }
                }
            }
        }
    }

    private fun fetch(url: String): Bitmap? {
        client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) return null
            val bytes = r.body?.bytes() ?: return null
            if (bytes.isEmpty() || bytes.size > 2 * 1024 * 1024) return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null   // formato non supportato (es. SVG)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= MAX_W || bounds.outHeight / (sample * 2) >= MAX_H) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        }
    }

    private companion object {
        const val MAX_W = 160
        const val MAX_H = 90
    }
}
