package it.gerry.iptvlite.ui

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration

/** Rilevamento automatico del tipo di dispositivo: TV (Fire Stick), tablet o telefono. */
object Device {

    fun isTv(context: Context): Boolean {
        val ui = context.getSystemService(UiModeManager::class.java)
        val pm = context.packageManager
        return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            pm.hasSystemFeature("amazon.hardware.fire_tv") ||
            !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
    }

    fun isTablet(context: Context): Boolean =
        context.resources.configuration.smallestScreenWidthDp >= 600

    fun isLandscape(context: Context): Boolean =
        context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
}
