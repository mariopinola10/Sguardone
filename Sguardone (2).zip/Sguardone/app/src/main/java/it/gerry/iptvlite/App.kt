package it.gerry.iptvlite

import android.app.Application
import it.gerry.iptvlite.data.Db
import it.gerry.iptvlite.data.Repository
import it.gerry.iptvlite.ui.LogoLoader
import it.gerry.iptvlite.vpn.VpnManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class App : Application() {

    lateinit var prefs: Prefs
        private set
    lateinit var http: OkHttpClient
        private set
    lateinit var repo: Repository
        private set
    lateinit var vpn: VpnManager
        private set

    /** Lista M3U caricata da file (telefono o selettore file). */
    val localM3uFile: File by lazy { File(filesDir, "playlist.m3u") }

    /** Loghi dei canali: scaricati solo con VPN attiva. */
    val logos: LogoLoader by lazy { LogoLoader(http, cacheDir) { vpn.isUp } }

    /** Scope che sopravvive alle Activity (usato per chiudere il tunnel all'uscita). */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Impostato dalle impostazioni: la MainActivity riparte da capo al resume. */
    @Volatile
    var configDirty = false

    private companion object {
        const val EPG_RULES = 2
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        // Regole EPG aggiornate (guida pubblica prima di quella della lista): forza il riscaricamento.
        if (prefs.epgRules < EPG_RULES) {
            prefs.lastEpg = 0L
            prefs.epgRules = EPG_RULES
        }
        http = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            // Controlla ogni richiesta reale, inclusi i redirect e i segmenti HLS.
            .addNetworkInterceptor { chain ->
                val url = chain.request().url
                if (!url.isHttps && prefs.httpsOnlyStreams) {
                    throw IOException("Connessione non HTTPS bloccata (${url.host})")
                }
                chain.proceed(chain.request())
            }
            .build()
        repo = Repository(Db(this), http, prefs, localM3uFile)
        vpn = VpnManager(this, prefs, http)
    }
}
