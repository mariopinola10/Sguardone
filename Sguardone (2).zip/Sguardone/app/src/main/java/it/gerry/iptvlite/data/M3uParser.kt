package it.gerry.iptvlite.data

import java.io.InputStream

/** Parser M3U/M3U8 in streaming: non carica mai l'intera lista in memoria. */
object M3uParser {

    data class Entry(
        val name: String,
        val tvgId: String?,
        val tvgName: String?,
        val logo: String?,
        val group: String,
        val url: String,
        val userAgent: String?,
        val referer: String?,
    )

    private val attrRegex = Regex("""([A-Za-z0-9_-]+)="([^"]*)"""")

    /** Chiama [onEntry] per ogni canale. Restituisce l'URL EPG dichiarato nell'intestazione, se c'è. */
    fun parse(input: InputStream, onEntry: (Entry) -> Unit): String? {
        var epgUrl: String? = null
        var attrs: Map<String, String> = emptyMap()
        var name: String? = null
        var groupTag: String? = null
        var userAgent: String? = null
        var referer: String? = null

        input.bufferedReader(Charsets.UTF_8).forEachLine { raw ->
            val line = raw.trim().removePrefix("﻿")
            when {
                line.isEmpty() -> Unit

                line.startsWith("#EXTM3U", ignoreCase = true) -> {
                    val a = attributes(line)
                    epgUrl = (a["url-tvg"] ?: a["x-tvg-url"])
                        ?.split(',')?.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() }
                }

                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    attrs = attributes(line)
                    // Il nome è dopo la prima virgola che segue l'ultimo attributo tra virgolette.
                    val afterAttrs = maxOf(line.lastIndexOf('"'), 0)
                    val comma = line.indexOf(',', afterAttrs)
                    name = if (comma >= 0) line.substring(comma + 1).trim() else null
                }

                line.startsWith("#EXTGRP:", ignoreCase = true) ->
                    groupTag = line.substringAfter(':').trim()

                line.startsWith("#EXTVLCOPT:http-user-agent=", ignoreCase = true) ->
                    userAgent = line.substringAfter('=').trim()

                line.startsWith("#EXTVLCOPT:http-referrer=", ignoreCase = true) ||
                    line.startsWith("#EXTVLCOPT:http-referer=", ignoreCase = true) ->
                    referer = line.substringAfter('=').trim()

                line.startsWith("#") -> Unit

                else -> {
                    val title = name?.takeIf { it.isNotEmpty() }
                        ?: attrs["tvg-name"]?.takeIf { it.isNotEmpty() }
                        ?: line
                    onEntry(
                        Entry(
                            name = title,
                            tvgId = attrs["tvg-id"]?.takeIf { it.isNotBlank() },
                            tvgName = attrs["tvg-name"]?.takeIf { it.isNotBlank() },
                            logo = attrs["tvg-logo"]?.takeIf { it.isNotBlank() },
                            group = attrs["group-title"]?.takeIf { it.isNotBlank() }
                                ?: groupTag?.takeIf { it.isNotBlank() }
                                ?: "Senza gruppo",
                            url = line,
                            userAgent = userAgent ?: attrs["user-agent"]?.takeIf { it.isNotBlank() },
                            referer = referer,
                        )
                    )
                    attrs = emptyMap(); name = null; groupTag = null; userAgent = null; referer = null
                }
            }
        }
        return epgUrl
    }

    private fun attributes(line: String): Map<String, String> =
        attrRegex.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
}
