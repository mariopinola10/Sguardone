package it.gerry.iptvlite.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteStatement

class Db(context: Context) : SQLiteOpenHelper(context, "iptv.db", null, 2) {

    override fun onConfigure(db: SQLiteDatabase) {
        // WAL: la UI può leggere mentre l'import EPG scrive in background.
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE channels(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                tvg_id TEXT,
                tvg_name TEXT,
                logo TEXT,
                grp TEXT NOT NULL,
                url TEXT NOT NULL,
                ua TEXT,
                referer TEXT,
                epg_key TEXT
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_channels_grp ON channels(grp)")
        db.execSQL(
            """
            CREATE TABLE programmes(
                epg_key TEXT NOT NULL,
                start INTEGER NOT NULL,
                stop INTEGER NOT NULL,
                title TEXT NOT NULL,
                descr TEXT
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_programmes_key_start ON programmes(epg_key, start)")
        createFavorites(db)
    }

    private fun createFavorites(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS favorites(name TEXT PRIMARY KEY, added INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // v2: tabella preferiti. Canali ed EPG restano intatti.
        if (oldVersion < 2) createFavorites(db)
    }
}

internal fun SQLiteStatement.bindOrNull(index: Int, value: String?) {
    if (value == null) bindNull(index) else bindString(index, value)
}
