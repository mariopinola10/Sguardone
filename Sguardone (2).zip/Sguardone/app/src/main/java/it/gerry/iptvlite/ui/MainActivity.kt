package it.gerry.iptvlite.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Repository
import it.gerry.iptvlite.vpn.VpnManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Schermata principale in stile Sky: solo i canali preferiti.
 * Avvio: consenso VPN -> tunnel Mullvad verificato -> lista M3U -> guida preferiti -> EPG in background.
 * La gestione di tutti i canali e dei preferiti è in BrowseActivity (dalle impostazioni).
 */
class MainActivity : ComponentActivity() {

    private val app by lazy { application as App }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var vpnStatus: TextView
    private lateinit var info: TextView
    private lateinit var retryButton: Button
    private lateinit var channelList: RecyclerView
    private lateinit var emptyPanel: View
    private lateinit var heroLogo: ImageView
    private lateinit var heroChannel: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroTime: TextView
    private lateinit var heroProgress: ProgressBar
    private lateinit var heroDesc: TextView
    private lateinit var heroNext: TextView
    private lateinit var heroUpcoming: TextView

    private lateinit var adapter: ChannelGuideAdapter

    private var started = false
    private lateinit var listMessage: TextView
    private lateinit var tabAdapter: TabAdapter
    private lateinit var tabsList: RecyclerView
    private var currentTab = Repository.FAVORITES
    private var pendingTab: Runnable? = null
    private var ticks = 0
    private lateinit var highlight: TextView
    private var ready = false
    private var focused: Channel? = null
    private var loadJob: Job? = null
    private var epgJob: Job? = null

    /** Ogni 30 s: orologio, barre di avanzamento e riquadro del programma. */
    private val ticker = object : Runnable {
        override fun run() {
            updateClock()
            if (ready) {
                adapter.refreshRows()
                focused?.let { showHero(it) }
                if (ticks++ % 4 == 0) updateHighlight()   // ogni 2 minuti
            }
            handler.postDelayed(this, 30_000L)
        }
    }

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) connectAndLoad()
            else showError("Permesso VPN negato: senza VPN l'app non si collega a nulla.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        vpnStatus = findViewById(R.id.vpnStatus)
        info = findViewById(R.id.info)
        retryButton = findViewById(R.id.retryButton)
        channelList = findViewById(R.id.channelList)
        emptyPanel = findViewById(R.id.emptyPanel)
        heroLogo = findViewById(R.id.heroLogo)
        heroChannel = findViewById(R.id.heroChannel)
        heroTitle = findViewById(R.id.heroTitle)
        heroTime = findViewById(R.id.heroTime)
        heroProgress = findViewById(R.id.heroProgress)
        heroDesc = findViewById(R.id.heroDesc)
        heroNext = findViewById(R.id.heroNext)
        heroUpcoming = findViewById(R.id.heroUpcoming)

        retryButton.setOnClickListener { startFlow() }
        findViewById<TextView>(R.id.appVersion).text = "v${app.versionName}"
        listMessage = findViewById(R.id.listMessage)
        findViewById<Button>(R.id.chooseButton).setOnClickListener { openBrowse() }
        findViewById<View>(R.id.searchButton).setOnClickListener { SearchActivity.start(this) }
        findViewById<View>(R.id.channelsButton).setOnClickListener { openBrowse() }
        findViewById<View>(R.id.settingsButton).setOnClickListener { openSettings() }
        findViewById<View>(R.id.exitButton).setOnClickListener { exitApp() }
        highlight = findViewById(R.id.highlight)
        // Indietro dalla guida: chiede se uscire e chiudere la VPN.
        onBackPressedDispatcher.addCallback(this) { confirmExit() }

        adapter = ChannelGuideAdapter(
            app = app,
            onFocus = { ch, _ ->
                focused = ch
                showHero(ch)
            },
            onClick = { _, pos -> PlayerActivity.start(this, currentTab, pos) },
            onLongClick = { ch, _ -> ChannelActions.show(this, app, ch) { reloadFavorites(focusList = false) } },
        )

        tabAdapter = TabAdapter(
            // Col telecomando basta spostarsi sulla scheda; OK/tocco apre e porta sulla lista.
            onFocus = { tab ->
                pendingTab?.let { handler.removeCallbacks(it) }
                pendingTab = Runnable { selectTab(tab, focusList = false) }.also { handler.postDelayed(it, 400) }
            },
            onClick = { tab -> selectTab(tab, focusList = true) },
        )
        tabsList = findViewById(R.id.tabsList)
        tabsList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tabsList.adapter = tabAdapter
        tabsList.itemAnimator = null
        currentTab = app.prefs.guideTab.ifEmpty { Repository.FAVORITES }

        findViewById<CheckBox>(R.id.httpsOnlyToggle).apply {
            isChecked = app.prefs.showHttpsOnly
            setOnCheckedChangeListener { _, checked ->
                app.prefs.showHttpsOnly = checked
                setInfo("")
                if (ready) reloadFavorites(focusList = false)
            }
        }
        channelList.layoutManager = LinearLayoutManager(this)
        channelList.adapter = adapter
        channelList.itemAnimator = null
        adaptToDevice()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                app.vpn.state.collect { renderVpn(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!app.prefs.isConfigured) {
            openSettings()
            return
        }
        if (app.configDirty) {
            app.configDirty = false
            started = false
            ready = false
            adapter.items = emptyList()
        }
        if (!started) {
            started = true
            startFlow()
        } else if (ready) {
            if (!app.vpn.isUp && app.vpn.state.value !is VpnManager.State.Connecting) {
                startFlow()       // VPN chiusa per inattività: si ricollega
            } else {
                reloadFavorites() // di ritorno dalla gestione canali o dal player
            }
        }
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        // Uscita dall'app: chiude il tunnel.
        if (isFinishing) app.appScope.launch { app.shutdown() }
    }

    // ---------- Uscita ----------

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle("Uscire da Sguardone?")
            .setMessage("La VPN e tutte le connessioni verranno chiuse.")
            .setPositiveButton("Esci") { _, _ -> exitApp() }
            .setNegativeButton("Annulla", null)
            .show()
    }

    /** Chiude VPN e connessioni, poi l'app (anche dalle app recenti). */
    private fun exitApp() {
        setInfo("Chiusura della VPN…")
        app.appScope.launch {
            app.shutdown()
            runOnUiThread { finishAndRemoveTask() }
        }
    }

    /**
     * Tasto Menu (≡): sul canale apre preferiti/numero, altrove le impostazioni.
     * Tasti numerici: vanno al canale con quel numero, come in TV.
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            val ch = focused
            if (channelList.hasFocus() && ch != null) {
                ChannelActions.show(this, app, ch) { reloadFavorites(focusList = false) }
            } else {
                openSettings()
            }
            return true
        }
        if (keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 && ready) {
            digits += (keyCode - KeyEvent.KEYCODE_0).toString()
            setInfo("Canale  $digits…")
            handler.removeCallbacks(digitJump)
            handler.postDelayed(digitJump, 1_500L)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private var digits = ""
    private val digitJump = Runnable {
        val n = digits.toIntOrNull()
        digits = ""
        setInfo("")
        val pos = adapter.items.indexOfFirst { it.number == n }
        if (pos < 0) {
            setInfo("Canale $n non presente in questa scheda")
            return@Runnable
        }
        channelList.scrollToPosition(pos)
        channelList.post { channelList.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }
    }

    // ---------- Avvio ----------

    private fun startFlow() {
        retryButton.visibility = View.GONE
        val intent = app.vpn.permissionIntent()
        if (intent != null) vpnPermission.launch(intent) else connectAndLoad()
    }

    private fun connectAndLoad() {
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            try {
                setInfo("Connessione a Mullvad…")
                app.vpn.connect()
                withContext(Dispatchers.IO) { app.repo.refreshPlaylist(false, ::postInfo) }
                ready = true
                reloadFavorites()
                setInfo("")
                refreshEpgInBackground()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                showError(e.message ?: e.toString())
            }
        }
    }

    private fun refreshEpgInBackground() {
        epgJob?.cancel()
        epgJob = lifecycleScope.launch {
            try {
                val updated = withContext(Dispatchers.IO) { app.repo.refreshEpg(false, ::postInfo) }
                if (updated) {
                    reloadFavorites()   // l'abbinamento EPG dei canali può essere cambiato
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setInfo("Guida EPG non disponibile: ${e.message}")
            }
        }
    }

    // ---------- Guida preferiti ----------

    private class GuideData(
        val tabs: List<String>,
        val tab: String,
        val list: List<Channel>,
        val nothingChosen: Boolean,
        val hidden: Int,
    )

    /** Ricarica schede e canali della scheda aperta (preferiti o cartella), con il filtro HTTPS. */
    private fun reloadFavorites(focusList: Boolean = true) {
        lifecycleScope.launch {
            val data = withContext(Dispatchers.IO) {
                val groups = app.repo.favoriteGroups()
                val hasFavChannels = app.repo.favoriteNames().isNotEmpty() &&
                    app.repo.channels(Repository.FAVORITES).isNotEmpty()
                val tabs = (if (hasFavChannels || groups.isEmpty()) listOf(Repository.FAVORITES) else emptyList()) + groups
                val tab = if (currentTab in tabs) currentTab else tabs.first()
                val visible = app.repo.visibleChannels(tab)
                val hidden = if (app.prefs.showHttpsOnly) app.repo.channels(tab).size - visible.size else 0
                GuideData(tabs, tab, visible, !hasFavChannels && groups.isEmpty(), hidden)
            }
            currentTab = data.tab
            app.prefs.guideTab = data.tab
            // Le schede si ricreano solo se cambiano: così il focus del telecomando resta sulla scheda.
            if (tabAdapter.items != data.tabs) tabAdapter.items = data.tabs
            tabAdapter.selected = data.tab
            tabsList.visibility = if (data.tabs.size > 1) View.VISIBLE else View.INVISIBLE

            val keepId = focused?.id
            val list = data.list
            adapter.items = list

            listMessage.visibility = View.GONE
            if (data.nothingChosen) {
                channelList.visibility = View.GONE
                emptyPanel.visibility = View.VISIBLE
                clearHero()
                findViewById<Button>(R.id.chooseButton).requestFocus()
                return@launch
            }
            channelList.visibility = View.VISIBLE
            emptyPanel.visibility = View.GONE

            if (list.isEmpty()) {
                clearHero()
                // Messaggio fisso al centro: non viene sovrascritto dagli aggiornamenti della guida.
                listMessage.text = if (data.hidden > 0) {
                    "${data.hidden} canali di questa scheda sono nascosti perché non HTTPS.\n" +
                        "Togli la spunta «Solo HTTPS» qui a destra per vederli."
                } else {
                    "Nessun canale in questa scheda."
                }
                listMessage.visibility = View.VISIBLE
                if (focusList) tabsList.post { tabsList.getChildAt(0)?.requestFocus() }
                return@launch
            }

            val pos = list.indexOfFirst { it.id == keepId }.coerceAtLeast(0)
            if (focusList) channelList.scrollToPosition(pos)
            if (focusList) {
                channelList.post {
                    channelList.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus()
                        ?: channelList.requestFocus()
                }
            }
            focused = list[pos]
            showHero(list[pos])
            updateHighlight()
        }
    }

    private fun selectTab(tab: String, focusList: Boolean) {
        if (tab == currentTab) {
            if (focusList) channelList.post { channelList.getChildAt(0)?.requestFocus() }
            return
        }
        currentTab = tab
        focused = null
        reloadFavorites(focusList)
    }

    /**
     * "In evidenza": il prossimo evento (o quello in onda) che corrisponde alle ricerche salvate,
     * es. "★ Napoli · Oggi 20:45  Napoli - Inter  ·  DAZN 1". OK/tocco: guarda o apre la ricerca.
     */
    private fun updateHighlight() {
        val terms = app.prefs.savedSearches
        if (terms.isEmpty()) {
            highlight.visibility = View.GONE
            return
        }
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) { runCatching { app.repo.nextHighlight(terms) }.getOrNull() }
            if (found == null) {
                highlight.visibility = View.GONE
                return@launch
            }
            val (term, hit) = found
            val onAir = hit.programme.start <= System.currentTimeMillis()
            val whenText = if (onAir) "● IN ONDA" else Format.day(hit.programme.start)
            highlight.text = "★ $term   ·   $whenText   ${hit.programme.title}   ·   ${hit.channel.name}"
            highlight.setTextColor(if (onAir) COLOR_OK else Color.WHITE)
            highlight.setOnClickListener {
                if (hit.programme.start <= System.currentTimeMillis()) PlayerActivity.startByName(this@MainActivity, hit.channel.name)
                else SearchActivity.start(this@MainActivity, term)
            }
            highlight.visibility = View.VISIBLE
        }
    }

    private fun showHero(ch: Channel) {
        lifecycleScope.launch {
            val (now, next) = withContext(Dispatchers.IO) { app.repo.nowNext(ch.epgKey) }
            val upcoming = withContext(Dispatchers.IO) { app.repo.programmes(ch.epgKey, 8) }
                .filter { next == null || it.start > next.start }
                .take(6)
            if (focused != ch) return@launch
            heroChannel.text = if (ch.number > 0) "${ch.number}   ${ch.name}" else ch.name
            app.logos.load(ch.logo, heroLogo)
            if (now != null) {
                heroTitle.text = now.title
                heroTime.text = Format.range(now)
                heroProgress.progress = Format.progress(now)
                heroProgress.visibility = View.VISIBLE
                heroDesc.text = now.description.orEmpty()
            } else {
                heroTitle.text = ch.name
                heroTime.text = ""
                heroProgress.visibility = View.INVISIBLE
                heroDesc.text = if (ch.epgKey == null) "Nessuna guida disponibile per questo canale" else ""
            }
            heroNext.text = Format.next(next)
            heroUpcoming.text = upcoming.joinToString("\n") { "${Format.time(it.start)}   ${it.title}" }
        }
    }

    private fun clearHero() {
        heroChannel.text = ""
        heroTitle.text = ""
        heroTime.text = ""
        heroDesc.text = ""
        heroNext.text = ""
        heroUpcoming.text = ""
        heroProgress.visibility = View.INVISIBLE
        heroLogo.setImageDrawable(null)
    }

    /**
     * TV: riquadro del programma sempre visibile, comandi da telecomando.
     * Tablet in orizzontale: come la TV. Telefono (e tablet in verticale): niente riquadro,
     * le righe mostrano già tutto e si tocca il canale per guardarlo.
     */
    private fun adaptToDevice() {
        val tv = Device.isTv(this)
        val landscape = Device.isLandscape(this)
        val showHero = tv || (Device.isTablet(this) && landscape)
        findViewById<View>(R.id.hero).visibility = if (showHero) View.VISIBLE else View.GONE
        adapter.showNext = !showHero
        if (!landscape) date.visibility = View.GONE
        findViewById<TextView>(R.id.hint).text = if (tv) {
            "OK  guarda     ·     ≡ Menu su un canale  preferiti e numero     ·     ▲ in alto  Cerca, Canali, Impostazioni, Esci"
        } else {
            "Tocca un canale per guardarlo  ·  tieni premuto per preferiti e numero  ·  🔍 cerca  ·  ☰ canali"
        }
    }

    private fun updateClock() {
        val now = System.currentTimeMillis()
        clock.text = Format.time(now)
        date.text = Format.date(now)
    }

    // ---------- Stato ----------

    private fun renderVpn(state: VpnManager.State) {
        when (state) {
            VpnManager.State.Down -> setVpn("● VPN disattivata", COLOR_ERROR)
            VpnManager.State.Connecting -> setVpn("● VPN in connessione…", COLOR_WAIT)
            is VpnManager.State.Up -> setVpn("● Mullvad · ${state.relay}", COLOR_OK)
            is VpnManager.State.Error -> {
                setVpn("● VPN errore", COLOR_ERROR)
                if (started) showError(state.message)
            }
        }
    }

    private fun setVpn(text: String, color: Int) {
        vpnStatus.text = text
        vpnStatus.setTextColor(color)
    }

    private fun setInfo(text: String) {
        info.text = text
        info.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun postInfo(text: String) {
        runOnUiThread { setInfo(text) }
    }

    private fun showError(message: String) {
        setInfo(message)
        retryButton.visibility = View.VISIBLE
        retryButton.requestFocus()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun openBrowse() {
        startActivity(Intent(this, BrowseActivity::class.java))
    }

    private companion object {
        val COLOR_OK = Color.parseColor("#4CAF50")
        val COLOR_WAIT = Color.parseColor("#FFC107")
        val COLOR_ERROR = Color.parseColor("#F44336")
    }
}
