package it.gerry.iptvlite.ui

import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import it.gerry.iptvlite.R

/**
 * Colori del testo nelle righe: bianco sul fondo blu, blu notte quando la riga col focus diventa bianca.
 * Impostati da codice a ogni cambio di focus, così il testo resta sempre leggibile.
 * tag="dim": testo secondario (grigio / blu attenuato). tag="fixed": colore lasciato com'è.
 */
object FocusColors {

    fun apply(root: View, focused: Boolean) {
        when (root) {
            is TextView -> if (root.tag != "fixed") {
                val dim = root.tag == "dim"
                val color = when {
                    focused && dim -> R.color.navy_dim
                    focused -> R.color.navy
                    dim -> R.color.text_dim
                    else -> R.color.text
                }
                root.setTextColor(ContextCompat.getColor(root.context, color))
            }
            is ViewGroup -> for (i in 0 until root.childCount) apply(root.getChildAt(i), focused)
        }
    }
}
