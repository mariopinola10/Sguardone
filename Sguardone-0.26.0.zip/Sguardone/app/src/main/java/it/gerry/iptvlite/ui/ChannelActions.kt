package it.gerry.iptvlite.ui

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import it.gerry.iptvlite.App
import it.gerry.iptvlite.data.Channel

/** Menu di un canale (tieni premuto / tasto Menu): preferiti e numero del canale. */
object ChannelActions {

    fun show(activity: Activity, app: App, ch: Channel, onChanged: () -> Unit) {
        val favorite = app.repo.isFavorite(ch.name)
        val manual = app.repo.manualNumber(ch.name)
        val actions = ArrayList<Pair<String, () -> Unit>>()

        actions.add(
            (if (favorite) "Togli dai preferiti" else "★ Aggiungi ai preferiti") to {
                val added = app.repo.toggleFavorite(ch.name)
                val hiddenByFilter = app.prefs.showHttpsOnly && !ch.url.startsWith("https://", ignoreCase = true)
                toast(
                    activity,
                    when {
                        !added -> "${ch.name} tolto dai preferiti"
                        hiddenByFilter -> "★ ${ch.name} aggiunto, ma non è HTTPS: nella guida lo vedi togliendo «Solo canali HTTPS» in Impostazioni"
                        else -> "★ ${ch.name} aggiunto ai preferiti"
                    },
                )
                onChanged()
            }
        )
        actions.add("#  Imposta numero canale" to { askNumber(activity, app, ch, onChanged) })
        if (manual != null) {
            actions.add(
                "Ripristina numero automatico" to {
                    app.repo.setManualNumber(ch.name, null)
                    toast(activity, "${ch.name}: numero automatico")
                    onChanged()
                }
            )
        }

        val title = if (ch.number > 0) "${ch.number}   ${ch.name}" else ch.name
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun askNumber(activity: Activity, app: App, ch: Channel, onChanged: () -> Unit) {
        val field = EditText(activity).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Es. 1, 101, 201"
            app.repo.manualNumber(ch.name)?.let { setText(it.toString()) }
            setSelection(text.length)
        }
        AlertDialog.Builder(activity)
            .setTitle("Numero per ${ch.name}")
            .setMessage("Il numero manuale ha la precedenza sull'ordine automatico.")
            .setView(field)
            .setPositiveButton("Salva") { _, _ ->
                val n = field.text.toString().toIntOrNull()
                if (n == null || n !in 1..9999) {
                    toast(activity, "Inserisci un numero da 1 a 9999")
                } else {
                    app.repo.setManualNumber(ch.name, n)
                    toast(activity, "${ch.name} → canale $n")
                    onChanged()
                }
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun toast(activity: Activity, text: String) =
        Toast.makeText(activity, text, Toast.LENGTH_LONG).show()
}
