package it.gerry.iptvlite.vpn

import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.IOException

/** Mullvad ha limitato le registrazioni della chiave (HTTP 429): bisogna aspettare. */
class MullvadThrottled(val retryAfterSec: Long) : IOException(
    "Mullvad ha limitato le registrazioni della chiave: aspetta circa " +
        "${(retryAfterSec / 60).coerceAtLeast(1)} minuti e riprova, senza premere Rigenera chiave."
)

data class Relay(
    val hostname: String,
    val country: String,
    val city: String,
    val ipv4: String,
    val publicKey: String,
)

/** Chiamate all'API pubblica Mullvad usate per configurare WireGuard. */
class MullvadApi(private val http: OkHttpClient) {

    /**
     * Registra la chiave pubblica WireGuard sull'account (max 5 dispositivi per account).
     * Restituisce gli indirizzi del tunnel, es. "10.64.12.34/32,fc00:bbbb:bbbb:bb01::c:1234/128".
     */
    fun registerKey(account: String, publicKey: String): String {
        val body = FormBody.Builder()
            .add("account", account)
            .add("pubkey", publicKey)
            .build()
        val request = Request.Builder().url("https://api.mullvad.net/wg/").post(body).build()
        http.newCall(request).execute().use { r ->
            val text = r.body?.string()?.trim().orEmpty()
            if (r.code == 429) {
                // Troppe registrazioni: Mullvad blocca per un po'. Retry-After o "exceeded in N second".
                val secs = r.header("Retry-After")?.toLongOrNull()
                    ?: Regex("(\\d+)\\s*second").find(text)?.groupValues?.get(1)?.toLongOrNull()
                    ?: 3600L
                throw MullvadThrottled(secs)
            }
            if (!r.isSuccessful || !text.contains('/')) {
                throw IOException("Mullvad: registrazione chiave fallita (HTTP ${r.code}). $text".trim())
            }
            return text
        }
    }

    /** Lista dei server WireGuard attivi. */
    fun relays(): List<Relay> {
        val request = Request.Builder().url("https://api.mullvad.net/www/relays/wireguard/").build()
        http.newCall(request).execute().use { r ->
            if (!r.isSuccessful) throw IOException("Mullvad: lista server non disponibile (HTTP ${r.code})")
            val array = JSONArray(r.body?.string() ?: "[]")
            val out = ArrayList<Relay>(array.length())
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                if (!o.optBoolean("active", true)) continue
                val key = o.optString("pubkey").ifEmpty { o.optString("public_key") }
                val ip = o.optString("ipv4_addr_in")
                if (key.isEmpty() || ip.isEmpty()) continue
                out.add(
                    Relay(
                        hostname = o.optString("hostname"),
                        country = o.optString("country_code"),
                        city = o.optString("city_code"),
                        ipv4 = ip,
                        publicKey = key,
                    )
                )
            }
            return out
        }
    }
}
