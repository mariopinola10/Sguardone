package it.gerry.iptvlite.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.R

/**
 * Adapter generico a due righe, navigabile con il D-pad del telecomando.
 * - riga con focus: sfondo blu con bordo bianco
 * - riga "attiva" (es. gruppo selezionato mentre il focus è altrove): sfondo evidenziato
 * - OK tenuto premuto: onLongClick
 */
class RowAdapter<T>(
    private val title: (T) -> String,
    private val subtitle: (T) -> String? = { null },
    private val focusable: Boolean = true,
    private val isActive: (T) -> Boolean = { false },
    private val onFocus: (T, Int) -> Unit = { _, _ -> },
    private val onClick: (T, Int) -> Unit = { _, _ -> },
    private val onLongClick: ((T, Int) -> Unit)? = null,
) : RecyclerView.Adapter<RowAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.title)
        val subtitle: TextView = view.findViewById(R.id.subtitle)
    }

    var items: List<T> = emptyList()
        @SuppressLint("NotifyDataSetChanged")
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    /** Ridisegna le righe senza togliere il focus (aggiorna stelle, gruppo attivo, titoli EPG). */
    fun refreshRows() = notifyItemRangeChanged(0, itemCount)

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false)
        view.isFocusable = focusable
        view.isClickable = focusable
        view.isLongClickable = focusable && onLongClick != null
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.title.text = title(item)
        val sub = subtitle(item)
        holder.subtitle.text = sub.orEmpty()
        holder.subtitle.visibility = if (sub.isNullOrEmpty()) View.GONE else View.VISIBLE
        holder.itemView.isActivated = isActive(item)
        if (focusable) {
            FocusColors.apply(holder.itemView, holder.itemView.isFocused)
            holder.itemView.setOnFocusChangeListener { v, hasFocus ->
                FocusColors.apply(v, hasFocus)
                if (hasFocus) onFocus(item, holder.bindingAdapterPosition)
            }
            holder.itemView.setOnClickListener { onClick(item, holder.bindingAdapterPosition) }
            onLongClick?.let { cb ->
                holder.itemView.setOnLongClickListener {
                    cb(item, holder.bindingAdapterPosition)
                    true
                }
            }
        }
    }
}
