package it.gerry.iptvlite.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Channel

/**
 * Righe della guida in stile Sky: numero, logo, nome, programma in onda con avanzamento, successivo.
 * Il now/next viene dalla cache del Repository: nessun accesso pesante durante lo scorrimento.
 */
class ChannelGuideAdapter(
    private val app: App,
    private val onFocus: (Channel, Int) -> Unit,
    private val onClick: (Channel, Int) -> Unit,
    private val onLongClick: (Channel, Int) -> Unit = { _, _ -> },
) : RecyclerView.Adapter<ChannelGuideAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val number: TextView = view.findViewById(R.id.number)
        val logo: ImageView = view.findViewById(R.id.logo)
        val name: TextView = view.findViewById(R.id.name)
        val nowTitle: TextView = view.findViewById(R.id.nowTitle)
        val progress: ProgressBar = view.findViewById(R.id.progress)
        val next: TextView = view.findViewById(R.id.next)
    }

    /** Colonna "Dopo" nelle righe: nascosta quando la guida del canale è già a destra. */
    var showNext: Boolean = true

    var items: List<Channel> = emptyList()
        @SuppressLint("NotifyDataSetChanged")
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    /** Aggiorna titoli e barre di avanzamento senza togliere il focus. */
    fun refreshRows() = notifyItemRangeChanged(0, itemCount)

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val ch = items[position]
        holder.number.text = (if (ch.number > 0) ch.number else position + 1).toString()
        holder.name.text = ch.displayName
        // Senza logo lo spazio si chiude: il nome parte subito dopo il numero.
        holder.logo.visibility = if (ch.logo.isNullOrBlank()) View.GONE else View.VISIBLE
        app.logos.load(ch.logo, holder.logo)

        val (now, next) = app.repo.nowNext(ch.epgKey)
        if (now != null) {
            holder.nowTitle.text = now.title
            holder.progress.progress = Format.progress(now)
            holder.progress.visibility = View.VISIBLE
        } else {
            // Nessun programma adesso: mostro almeno il prossimo (come il riquadro a destra).
            holder.nowTitle.text = when {
                next != null -> "Dalle ${Format.time(next.start)}  ${next.title}"
                ch.epgKey == null -> "Nessuna guida"
                else -> "Nessun programma in corso"
            }
            holder.progress.visibility = View.INVISIBLE
        }
        holder.next.text = if (now != null) Format.next(next) else ""
        holder.next.visibility = if (showNext) View.VISIBLE else View.GONE

        FocusColors.apply(holder.itemView, holder.itemView.isFocused)
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            FocusColors.apply(v, hasFocus)
            if (hasFocus) onFocus(ch, holder.bindingAdapterPosition)
        }
        holder.itemView.setOnClickListener { onClick(ch, holder.bindingAdapterPosition) }
        holder.itemView.setOnLongClickListener {
            onLongClick(ch, holder.bindingAdapterPosition)
            true
        }
    }
}
