package it.gerry.iptvlite.ui

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.CalendarContract
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Programme
import it.gerry.iptvlite.data.ProgrammeHit
import it.gerry.iptvlite.data.Rating
import it.gerry.iptvlite.data.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Home: "Da non perdere".
 * - ⚽ il Napoli in onda o nelle prossime 12 ore, con i canali delle liste che lo trasmettono;
 * - 🎬 film e serie in onda o che iniziano entro un'ora con voto TMDB alto.
 * TV/tablet: elenco a destra sotto il programma del canale. Telefono: una riga di riepilogo (tocca per l'elenco).
 */
class HomePicks(private val activity: ComponentActivity, private val app: App) {

    sealed interface Item {
        data class Napoli(val match: Repository.Match) : Item
        data class Film(val hit: ProgrammeHit, val rating: Rating) : Item
    }

    private val title: TextView = activity.findViewById(R.id.picksTitle)
    private val list: RecyclerView = activity.findViewById(R.id.picksList)
    private val status: TextView = activity.findViewById(R.id.picksStatus)
    private val line: TextView = activity.findViewById(R.id.picksLine)

    /** Righe compatte: voto a sinistra, titolo su 2 righe, canale e orario sotto. */
    private class PickAdapter(
        private val badge: (Item) -> String,
        private val title: (Item) -> String,
        private val sub: (Item) -> String,
        private val onClick: (Item) -> Unit,
    ) : RecyclerView.Adapter<PickAdapter.Holder>() {

        class Holder(v: View) : RecyclerView.ViewHolder(v) {
            val badge: TextView = v.findViewById(R.id.badge)
            val title: TextView = v.findViewById(R.id.pickTitle)
            val sub: TextView = v.findViewById(R.id.pickSub)
        }

        var items: List<Item> = emptyList()
            @SuppressLint("NotifyDataSetChanged")
            set(value) {
                field = value
                notifyDataSetChanged()
            }

        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_pick, parent, false))

        override fun onBindViewHolder(h: Holder, position: Int) {
            val item = items[position]
            h.badge.text = badge(item)
            h.title.text = title(item)
            h.sub.text = sub(item)
            FocusColors.apply(h.itemView, h.itemView.isFocused)
            h.itemView.setOnFocusChangeListener { v, f -> FocusColors.apply(v, f) }
            h.itemView.setOnClickListener { onClick(item) }
        }
    }

    private val adapter = PickAdapter(::badge, ::pickTitle, ::rowSubtitle, ::openItem)

    /** true = elenco laterale (TV, tablet orizzontale); false = riga di riepilogo (telefono). */
    var wide = true
        set(value) {
            field = value
            render()
        }

    private var job: Job? = null
    private var lastRun = 0L
    private var napoli: List<Repository.Match> = emptyList()
    private val films = LinkedHashMap<String, Item.Film>()
    private var searching = 0

    init {
        list.layoutManager = LinearLayoutManager(activity)
        list.adapter = adapter
        list.itemAnimator = null
        line.setOnClickListener { showDialog() }
    }

    /** Aggiorna (al massimo ogni 10 minuti, o subito con [force]: es. guida appena scaricata). */
    fun refresh(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (job?.isActive == true) return
        if (!force && now - lastRun < REFRESH_MS) {
            render()
            return
        }
        lastRun = now
        job = activity.lifecycleScope.launch {
            napoli = withContext(Dispatchers.IO) { runCatching { app.repo.napoliMatches() }.getOrDefault(emptyList()) }
            val candidates = withContext(Dispatchers.IO) { runCatching { app.repo.filmCandidates() }.getOrDefault(emptyList()) }
            films.clear()
            val known = withContext(Dispatchers.IO) {
                candidates.mapNotNull { h -> app.repo.cachedRating(h.programme)?.let { Item.Film(h, it) } }
            }
            known.forEach { films[key(it.hit)] = it }
            render()

            // Voti mancanti: dall'API TMDB, 4 alla volta, solo con la VPN attiva.
            if (!app.prefs.ratingsActive || !app.vpn.isUp) return@launch
            val missing = withContext(Dispatchers.IO) {
                candidates.filter { !app.repo.ratingKnown(it.programme) }.take(MAX_LOOKUPS)
            }
            searching = missing.size
            render()
            for (chunk in missing.chunked(4)) {
                val results = chunk.map { h -> async(Dispatchers.IO) { h to app.repo.rating(h.programme) } }.awaitAll()
                for ((h, r) in results) if (r != null) films[key(h)] = Item.Film(h, r)
                searching -= chunk.size
                render()
            }
            searching = 0
            render()
        }
    }

    private fun key(h: ProgrammeHit) = h.programme.title.lowercase() + "@" + h.programme.start

    private fun items(): List<Item> {
        val now = System.currentTimeMillis()
        val best = films.values
            .filter { it.rating.value >= app.prefs.minRating && it.rating.votes >= MIN_VOTES && it.hit.programme.stop > now }
            .sortedWith(compareByDescending<Item.Film> { it.rating.value }.thenBy { it.hit.programme.start })
            .take(8)
        return napoli.filter { it.programme.stop > now }.map { Item.Napoli(it) } + best
    }

    private fun render() {
        val items = items()
        val now = System.currentTimeMillis()
        val noNapoli = napoli.none { it.programme.stop > now }
        val info = buildList {
            if (noNapoli && lastRun > 0) add("⚽ Napoli: nessuna partita nelle prossime 12 ore")
            if (searching > 0) add("Cerco i voti TMDB… ($searching)")
            else if (lastRun > 0 && !app.prefs.ratingsActive) add("🎬 Per i film da non perdere inserisci la chiave TMDB nelle Impostazioni")
            else if (lastRun > 0 && items.none { it is Item.Film }) add("🎬 Nessun film o serie con voto ≥ ${String.format(java.util.Locale.ITALY, "%.1f", app.prefs.minRating)} ora o nella prossima ora")
        }.joinToString("\n")

        if (wide) {
            line.visibility = View.GONE
            if (adapter.items != items) adapter.items = items   // senza ricreare le righe il focus resta dov'è
            title.visibility = View.VISIBLE
            status.text = info
            status.visibility = if (info.isEmpty()) View.GONE else View.VISIBLE
        } else {
            title.visibility = View.GONE
            status.visibility = View.GONE
            if (adapter.items.isNotEmpty()) adapter.items = emptyList()
            val onAir = items.filterIsInstance<Item.Napoli>().firstOrNull()
            val nFilms = items.count { it is Item.Film }
            val parts = buildList {
                onAir?.let { add("⚽ ${whenText(it.match.programme.start)}  ${it.match.programme.title} · ${it.match.channels.firstOrNull()?.displayName.orEmpty()}") }
                if (nFilms > 0) add("🎬 $nFilms da non perdere")
                if (searching > 0) add("cerco i voti…")
            }
            line.text = parts.joinToString("   ·   ")
            line.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun whenText(start: Long): String =
        if (start <= System.currentTimeMillis()) "● IN ONDA" else Format.day(start)

    private fun badge(item: Item): String = when (item) {
        is Item.Napoli -> "⚽"
        is Item.Film -> "★" + String.format(java.util.Locale.ITALY, "%.1f", item.rating.value)
    }

    private fun pickTitle(item: Item): String = when (item) {
        is Item.Napoli -> item.match.programme.title
        is Item.Film -> item.hit.programme.title
    }

    private fun rowSubtitle(item: Item): String = when (item) {
        is Item.Napoli -> whenText(item.match.programme.start) + "  ·  " +
            item.match.channels.take(3).joinToString(", ") { it.displayName } +
            if (item.match.channels.size > 3) " +${item.match.channels.size - 3}" else ""
        is Item.Film -> whenText(item.hit.programme.start) + "  ·  " + item.hit.channel.displayName +
            "  ·  " + Format.range(item.hit.programme)
    }

    private fun showDialog() {
        val items = items()
        if (items.isEmpty()) return
        AlertDialog.Builder(activity)
            .setTitle("Da non perdere")
            .setItems(items.map { badge(it) + "  " + pickTitle(it) + "\n" + rowSubtitle(it) }.toTypedArray()) { _, which -> openItem(items[which]) }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    /** Scheda dell'evento: trama completa e voto, poi Guarda / Promemoria, Calendario, Trasmetti. */
    private fun openItem(item: Item) {
        val (programme, channels) = when (item) {
            is Item.Napoli -> item.match.programme to item.match.channels
            is Item.Film -> item.hit.programme to listOf(item.hit.channel)
        }
        if (channels.isEmpty()) return
        val rating = (item as? Item.Film)?.rating
        val onAir = programme.start <= System.currentTimeMillis()
        val text = buildString {
            append(if (onAir) "● IN ONDA  " else "").append(Format.day(programme.start))
            append("  (").append(Format.range(programme)).append(")")
            append("\n").append(channels.joinToString(", ") { it.displayName })
            listOfNotNull(programme.category, programme.year?.toString()).takeIf { it.isNotEmpty() }
                ?.let { append("\n").append(it.joinToString("  ·  ")) }
            if (rating != null) append("\n\n").append(Format.rating(rating)).append("   (").append(rating.votes).append(" voti)")
            append("\n\n").append(programme.description?.takeIf { it.isNotBlank() } ?: "Nessuna trama nella guida.")
        }
        val d = AlertDialog.Builder(activity)
            .setTitle(programme.title)
            .setMessage(text)
            .setNeutralButton("📅 Calendario") { _, _ -> addToCalendar(channels[0], programme) }
            .setNegativeButton("📺 Trasmetti") { _, _ -> pickChannel(channels, "Trasmetti da") { PlayerActivity.startByName(activity, it.name, cast = true) } }
        if (onAir) {
            d.setPositiveButton("▶ Guarda") { _, _ -> pickChannel(channels, "Guarda su") { PlayerActivity.startByName(activity, it.name) } }
        } else {
            d.setPositiveButton("⏰ Promemoria") { _, _ ->
                activity.lifecycleScope.launch {
                    withContext(Dispatchers.IO) { app.repo.addReminder(channels[0].name, programme) }
                    Toast.makeText(activity, "Promemoria alle ${Format.time(programme.start)}: ${programme.title}", Toast.LENGTH_LONG).show()
                }
            }
        }
        d.show()
    }

    /** Con un solo canale va diretto, altrimenti chiede quale. */
    private fun pickChannel(channels: List<Channel>, title: String, then: (Channel) -> Unit) {
        if (channels.size == 1) return then(channels[0])
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setItems(channels.map { it.displayName }.toTypedArray()) { _, which -> then(channels[which]) }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun addToCalendar(ch: Channel, p: Programme) {
        val intent = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, p.start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, p.stop)
            .putExtra(CalendarContract.Events.TITLE, p.title)
            .putExtra(CalendarContract.Events.DESCRIPTION, "Su ${ch.displayName} — Sguardone")
        try {
            activity.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(activity, "Nessuna app calendario su questo dispositivo: uso il promemoria di Sguardone", Toast.LENGTH_LONG).show()
            activity.lifecycleScope.launch { withContext(Dispatchers.IO) { app.repo.addReminder(ch.name, p) } }
        }
    }

    private companion object {
        const val REFRESH_MS = 10 * 60_000L
        const val MAX_LOOKUPS = 40
        /** Valutazioni minime perché il voto TMDB sia affidabile (il voto minimo è nelle impostazioni). */
        const val MIN_VOTES = 50
    }
}
