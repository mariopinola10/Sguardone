package it.gerry.iptvlite.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.crypto.KeyPair
import it.gerry.iptvlite.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Tunnel WireGuard verso Mullvad, limitato al traffico di questa sola app.
 *
 * Kill-switch applicativo: il player e i download partono solo con stato [State.Up].
 * Se il tunnel cade, lo stato passa a [State.Error] e la riproduzione viene fermata.
 */
class VpnManager(
    context: Context,
    private val prefs: Prefs,
    private val http: OkHttpClient,
) {
    sealed interface State {
        data object Down : State
        data object Connecting : State
        data class Up(val relay: String) : State
        data class Error(val message: String) : State
    }

    private val ctx = context.applicationContext
    private val api = MullvadApi(http)
    private val backend: GoBackend by lazy { GoBackend(ctx) }
    private val mutex = Mutex()

    private val _state = MutableStateFlow<State>(State.Down)
    val state: StateFlow<State> = _state.asStateFlow()
    val isUp: Boolean get() = _state.value is State.Up

    private val tunnel = object : Tunnel {
        override fun getName(): String = "iptvlite"
        override fun onStateChange(newState: Tunnel.State) {
            if (newState != Tunnel.State.UP && _state.value is State.Up) {
                _state.value = State.Error("Tunnel VPN interrotto")
            }
        }
    }

    /** Intent del consenso VPN di sistema, oppure null se già concesso. */
    fun permissionIntent(): Intent? = VpnService.prepare(ctx)

    suspend fun connect() {
        mutex.withLock { connectLocked() }
    }

    private suspend fun connectLocked() {
        withContext<Unit>(Dispatchers.IO) {
            if (isUp) return@withContext
            _state.value = State.Connecting
            try {
                ensureKey()
                val relay = pickRelay()
                backend.setState(tunnel, Tunnel.State.UP, buildConfig(relay))
                // Chiude eventuali connessioni aperte prima del tunnel, così tutto il resto passa da Mullvad.
                http.connectionPool.evictAll()
                verifyThroughMullvad()
                prefs.relayHost = relay.hostname
                _state.value = State.Up(relay.hostname)
            } catch (e: Exception) {
                runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
                _state.value = State.Error(e.message ?: e.javaClass.simpleName)
                throw e
            }
        }
    }

    suspend fun disconnect() {
        mutex.withLock {
            withContext<Unit>(Dispatchers.IO) {
                _state.value = State.Down
                runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
                http.connectionPool.evictAll()
            }
        }
    }

    /** Elimina la chiave locale: alla prossima connessione ne viene registrata una nuova. */
    fun resetKey() {
        prefs.wgPrivateKey = ""
        prefs.wgAddresses = ""
    }

    private fun ensureKey() {
        if (prefs.wgPrivateKey.isNotEmpty() && prefs.wgAddresses.isNotEmpty()) return
        val keyPair = KeyPair()
        val addresses = api.registerKey(prefs.mullvadAccount, keyPair.publicKey.toBase64())
        prefs.wgPrivateKey = keyPair.privateKey.toBase64()
        prefs.wgAddresses = addresses
    }

    private fun pickRelay(): Relay {
        val all = api.relays()
        if (all.isEmpty()) throw IOException("Nessun server Mullvad disponibile")
        val sameCountry = all.filter { it.country.equals(prefs.country, ignoreCase = true) }
        val pool = sameCountry.ifEmpty { all }
        // Preferisce l'ultimo server usato, se è ancora attivo.
        return pool.firstOrNull { it.hostname == prefs.relayHost } ?: pool.random()
    }

    private fun buildConfig(relay: Relay): Config {
        val iface = Interface.Builder()
            .parsePrivateKey(prefs.wgPrivateKey)
            .parseAddresses(prefs.wgAddresses)
            .parseDnsServers("10.64.0.1")            // DNS Mullvad interno al tunnel
            .includeApplication(ctx.packageName)     // solo il traffico di questa app
            .build()
        val peer = Peer.Builder()
            .parsePublicKey(relay.publicKey)
            .parseEndpoint("${relay.ipv4}:51820")
            .parseAllowedIPs("0.0.0.0/0, ::/0")
            .parsePersistentKeepalive("25")
            .build()
        return Config.Builder().setInterface(iface).addPeer(peer).build()
    }

    /** Verifica reale: chiede a Mullvad se la richiesta arriva dal tunnel. */
    private suspend fun verifyThroughMullvad() {
        val client = http.newBuilder().callTimeout(8, TimeUnit.SECONDS).build()
        val request = Request.Builder().url("https://am.i.mullvad.net/connected").build()
        var last = ""
        repeat(4) {
            try {
                last = client.newCall(request).execute().use { it.body?.string()?.trim().orEmpty() }
                if (last.startsWith("You are connected", ignoreCase = true)) return
            } catch (e: IOException) {
                last = e.message ?: "timeout"
            }
            delay(1500)
        }
        throw IOException(
            "Il tunnel è attivo ma il traffico non risulta passare da Mullvad ($last). " +
                "Se persiste, rigenera la chiave dalle impostazioni."
        )
    }
}
