package it.gerry.iptvlite.ui

import android.content.ActivityNotFoundException
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import it.gerry.iptvlite.App
import it.gerry.iptvlite.Prefs
import it.gerry.iptvlite.R
import it.gerry.iptvlite.config.ConfigServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.Locale
import kotlin.random.Random

/**
 * Configurazione: account Mullvad, paese server, lista M3U (link o file), EPG.
 * Si può compilare col telecomando oppure dal telefono tramite il mini server web locale.
 */
class SettingsActivity : ComponentActivity() {

    private val app by lazy { application as App }
    private val pin = String.format(Locale.ROOT, "%04d", Random.nextInt(10_000))
    private var server: ConfigServer? = null

    private lateinit var m3uField: EditText
    private lateinit var epgField: EditText
    private lateinit var accountField: EditText
    private lateinit var countryField: EditText
    private lateinit var localInfo: TextView
    private lateinit var phoneInfo: TextView
    private lateinit var allowHttp: CheckBox

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            val error = withContext(Dispatchers.IO) {
                try {
                    val tmp = File(filesDir, "upload.tmp")
                    contentResolver.openInputStream(uri)?.use { input ->
                        tmp.outputStream().use { input.copyTo(it) }
                    } ?: throw IOException("File non leggibile")
                    storeM3uFile(tmp)
                } catch (e: Exception) {
                    e.message ?: "Errore nella lettura del file"
                }
            }
            if (error != null) {
                toast(error)
            } else {
                m3uField.setText("")
                updateLocalInfo()
                toast("File caricato. Lascia vuoto il link M3U e premi Salva.")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        m3uField = findViewById(R.id.m3uUrl)
        epgField = findViewById(R.id.epgUrl)
        accountField = findViewById(R.id.mullvadAccount)
        countryField = findViewById(R.id.country)
        localInfo = findViewById(R.id.localInfo)
        phoneInfo = findViewById(R.id.phoneInfo)
        allowHttp = findViewById(R.id.allowHttpStreams)
        fillFields()

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            val result = applyConfig(
                m3u = m3uField.text.toString().trim().ifEmpty {
                    if (app.localM3uFile.exists()) Prefs.LOCAL_M3U else ""
                },
                epg = epgField.text.toString().trim(),
                account = accountField.text.toString(),
                country = countryField.text.toString(),
            )
            if (result.error != null) {
                toast(result.error)
            } else {
                app.prefs.httpsOnlyStreams = !allowHttp.isChecked
                applyAndClose(result.reconnect)
            }
        }

        findViewById<Button>(R.id.pickFileButton).setOnClickListener {
            try {
                pickFile.launch(arrayOf("*/*"))
            } catch (e: ActivityNotFoundException) {
                toast("Questo dispositivo non ha un selettore file: carica il file dal telefono (indirizzo in alto).")
            }
        }

        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            if (!app.prefs.isConfigured) return@setOnClickListener toast("Prima salva la configurazione")
            app.prefs.lastM3u = 0L
            app.prefs.lastEpg = 0L
            applyAndClose(reconnect = false)
        }

        findViewById<Button>(R.id.regenKeyButton).setOnClickListener {
            if (!app.prefs.isConfigured) return@setOnClickListener toast("Prima salva la configurazione")
            app.vpn.resetKey()
            toast("Nuova chiave alla prossima connessione. Rimuovi il vecchio dispositivo dal tuo account Mullvad (max 5).")
            applyAndClose(reconnect = true)
        }

        onBackPressedDispatcher.addCallback(this) {
            if (app.prefs.isConfigured) finish() else finishAffinity()
        }
    }

    override fun onStart() {
        super.onStart()
        startServer()
    }

    override fun onStop() {
        super.onStop()
        server?.stop()
        server = null
    }

    // ---------- Configurazione dal telefono ----------

    private fun startServer() {
        val ip = ConfigServer.localIp()
        if (ip == null) {
            phoneInfo.text = "Configurazione dal telefono non disponibile: Fire Stick non connesso alla rete locale."
            return
        }
        val s = ConfigServer(
            pin = pin,
            uploadDir = filesDir,
            onUpload = { tmp -> storeM3uFile(tmp) },
            onConfig = { form -> onPhoneConfig(form) },
        )
        try {
            val port = s.start()
            server = s
            phoneInfo.text = "Dal telefono (stessa Wi-Fi) apri  http://$ip:$port    PIN  $pin"
        } catch (e: IOException) {
            phoneInfo.text = "Configurazione dal telefono non disponibile: ${e.message}"
        }
    }

    /** Chiamato sul thread del server. I campi vuoti mantengono il valore attuale. */
    private fun onPhoneConfig(form: Map<String, String>): String? {
        val p = app.prefs
        val m3u = when {
            form["local"] == "1" -> Prefs.LOCAL_M3U
            !form["m3u"].isNullOrBlank() -> form["m3u"]!!.trim()
            else -> p.m3uUrl
        }
        val result = applyConfig(
            m3u = m3u,
            epg = form["epg"]?.trim()?.ifEmpty { null } ?: p.epgUrl,
            account = form["account"]?.ifBlank { null } ?: p.mullvadAccount,
            country = form["country"]?.ifBlank { null } ?: p.country,
        )
        if (result.error == null) {
            runOnUiThread {
                fillFields()
                toast("Configurazione ricevuta dal telefono")
                applyAndClose(result.reconnect)
            }
        }
        return result.error
    }

    // ---------- Logica comune ----------

    private class Result(val error: String?, val reconnect: Boolean = false)

    /** Valida e salva. Usata sia dal telecomando sia dal telefono. */
    @Synchronized
    private fun applyConfig(m3u: String, epg: String, account: String, country: String): Result {
        val p = app.prefs
        val newAccount = account.filter { it.isDigit() }
        val newCountry = country.trim().lowercase().ifEmpty { "it" }

        if (m3u == Prefs.LOCAL_M3U) {
            if (!app.localM3uFile.exists()) return Result("Nessun file M3U caricato")
        } else if (!m3u.startsWith("https://", ignoreCase = true)) {
            return Result(
                if (m3u.startsWith("http://", ignoreCase = true)) "Il link M3U non è HTTPS: per sicurezza non è accettato"
                else "Inserisci un link M3U https:// oppure carica un file"
            )
        }
        if (epg.isNotEmpty() && !epg.startsWith("https://", ignoreCase = true)) {
            return Result("Il link EPG deve essere HTTPS (https://)")
        }
        if (newAccount.length != 16) return Result("Il numero account Mullvad ha 16 cifre")
        if (!newCountry.matches(Regex("[a-z]{2}"))) return Result("Paese: usa un codice di 2 lettere (es. it)")

        val accountChanged = newAccount != p.mullvadAccount
        val reconnect = accountChanged || newCountry != p.country
        if (accountChanged) app.vpn.resetKey()
        if (m3u != p.m3uUrl) p.lastM3u = 0L
        if (epg != p.epgUrl) p.lastEpg = 0L
        if (reconnect) p.relayHost = ""

        p.m3uUrl = m3u
        p.epgUrl = epg
        p.mullvadAccount = newAccount
        p.country = newCountry
        return Result(null, reconnect)
    }

    /** Valida un file M3U appena ricevuto e lo rende la lista locale. Restituisce un errore o null. */
    private fun storeM3uFile(tmp: File): String? {
        val head = ByteArray(64 * 1024)
        val n = tmp.inputStream().use { it.read(head) }
        val gzip = n >= 2 && head[0] == 0x1f.toByte() && head[1] == 0x8b.toByte()
        val text = if (n > 0) String(head, 0, n, Charsets.UTF_8) else ""
        if (!gzip && !text.contains("#EXTINF", ignoreCase = true) && !text.contains("#EXTM3U", ignoreCase = true)) {
            tmp.delete()
            return "Il file non sembra una lista M3U"
        }
        val target = app.localM3uFile
        target.delete()
        if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
        app.prefs.lastM3u = 0L   // forza la reimportazione
        runOnUiThread { updateLocalInfo() }
        return null
    }

    private fun fillFields() {
        val p = app.prefs
        m3uField.setText(if (p.isLocalM3u) "" else p.m3uUrl)
        epgField.setText(p.epgUrl)
        accountField.setText(p.mullvadAccount)
        countryField.setText(p.country)
        allowHttp.isChecked = !p.httpsOnlyStreams
        findViewById<TextView>(R.id.vpnInfo).text =
            if (p.relayHost.isNotEmpty()) "Ultimo server Mullvad: ${p.relayHost}" else ""
        updateLocalInfo()
    }

    private fun updateLocalInfo() {
        val f = app.localM3uFile
        localInfo.text = when {
            !f.exists() -> "Nessun file M3U caricato."
            app.prefs.isLocalM3u -> "In uso: file M3U caricato (${f.length() / 1024} KB)."
            else -> "File M3U caricato (${f.length() / 1024} KB): lascia vuoto il link per usarlo."
        }
    }

    private fun applyAndClose(reconnect: Boolean) {
        lifecycleScope.launch {
            if (reconnect) app.vpn.disconnect()
            app.configDirty = true
            finish()
        }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
