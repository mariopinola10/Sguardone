package it.gerry.iptvlite.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.annotation.OptIn
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Repository
import it.gerry.iptvlite.vpn.VpnManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Player a schermo intero.
 * Telecomando: SU/GIÙ cambia canale, OK mostra le info, INDIETRO torna alla lista.
 */
@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_GROUP = "group"
        private const val EXTRA_INDEX = "index"

        fun start(context: Context, group: String, index: Int) {
            context.startActivity(
                Intent(context, PlayerActivity::class.java)
                    .putExtra(EXTRA_GROUP, group)
                    .putExtra(EXTRA_INDEX, index)
            )
        }
    }

    private val app by lazy { application as App }
    private val handler = Handler(Looper.getMainLooper())
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.ITALY)

    private lateinit var playerView: PlayerView
    private lateinit var overlay: View
    private lateinit var overlayChannel: TextView
    private lateinit var overlayProgramme: TextView
    private lateinit var message: TextView

    private var player: ExoPlayer? = null
    private var dataSourceFactory: OkHttpDataSource.Factory? = null
    private var channels: List<Channel> = emptyList()
    private var index = 0
    private var retries = 0

    private val hideOverlay = Runnable { overlay.visibility = View.GONE }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY) {
                retries = 0
                message.visibility = View.GONE
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val p = player ?: return
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            if (error.cause?.message?.contains("non HTTPS") == true ||
                error.cause?.cause?.message?.contains("non HTTPS") == true
            ) {
                showMessage("Lo stream usa connessioni non HTTPS: bloccato.\nPuoi consentirlo nelle impostazioni (sconsigliato).")
                return
            }
            if (retries < 3 && app.vpn.isUp) {
                retries++
                showMessage("Riconnessione… ($retries/3)")
                handler.postDelayed({ if (app.vpn.isUp) player?.prepare() }, 2000L)
            } else {
                showMessage("Stream non disponibile (${error.errorCodeName})")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        overlayChannel = findViewById(R.id.overlayChannel)
        overlayProgramme = findViewById(R.id.overlayProgramme)
        message = findViewById(R.id.message)

        index = intent.getIntExtra(EXTRA_INDEX, 0)
        val group = intent.getStringExtra(EXTRA_GROUP) ?: Repository.ALL

        lifecycleScope.launch {
            channels = withContext(Dispatchers.IO) { app.repo.channels(group) }
            if (player != null) play(index)
        }

        // Kill-switch applicativo: se il tunnel non è attivo, la riproduzione si ferma subito.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                app.vpn.state.collect { state ->
                    if (state !is VpnManager.State.Up) {
                        player?.stop()
                        showMessage("VPN non attiva: riproduzione bloccata")
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        initPlayer()
        if (channels.isNotEmpty()) play(index)
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { play(index - 1); true }
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { play(index + 1); true }
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_INFO -> {
            channels.getOrNull(index)?.let { showOverlay(it) }
            true
        }
        else -> super.onKeyDown(keyCode, event)
    }

    private fun initPlayer() {
        val dsf = OkHttpDataSource.Factory(app.http).setUserAgent(Repository.DEFAULT_UA)
        dataSourceFactory = dsf
        // Buffer contenuti: avvio rapido e poca RAM, adatti a Fire Stick.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(8_000, 30_000, 1_500, 3_000)
            .build()
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsf))
            .setLoadControl(loadControl)
            .build()
            .also { p ->
                p.addListener(listener)
                playerView.player = p
            }
    }

    private fun releasePlayer() {
        handler.removeCallbacksAndMessages(null)
        playerView.player = null
        player?.release()
        player = null
    }

    private fun play(target: Int) {
        val p = player ?: return
        if (channels.isEmpty()) return
        index = ((target % channels.size) + channels.size) % channels.size
        val ch = channels[index]
        showOverlay(ch)

        if (!app.vpn.isUp) {
            p.stop()
            showMessage("VPN non attiva: riproduzione bloccata")
            return
        }

        if (app.prefs.httpsOnlyStreams && !ch.url.startsWith("https://", ignoreCase = true)) {
            p.stop()
            showMessage("Canale non HTTPS: bloccato.\nPuoi consentirlo nelle impostazioni (sconsigliato).")
            return
        }

        retries = 0
        message.visibility = View.GONE
        dataSourceFactory?.setUserAgent(ch.userAgent ?: Repository.DEFAULT_UA)
        dataSourceFactory?.setDefaultRequestProperties(ch.referer?.let { mapOf("Referer" to it) } ?: emptyMap())

        val item = MediaItem.Builder()
            .setUri(ch.url)
            .apply { if (ch.url.contains(".m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        p.setMediaItem(item)
        p.prepare()
        p.playWhenReady = true
    }

    private fun showOverlay(ch: Channel) {
        overlayChannel.text = "${index + 1}   ${ch.name}"
        overlayProgramme.text = ""
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlay)
        handler.postDelayed(hideOverlay, 5000L)
        lifecycleScope.launch {
            val now = withContext(Dispatchers.IO) { app.repo.nowPlaying(ch.epgKey) }
            if (channels.getOrNull(index) == ch && now != null) {
                overlayProgramme.text =
                    "${timeFmt.format(Date(now.start))} – ${timeFmt.format(Date(now.stop))}   ${now.title}"
            }
        }
    }

    private fun showMessage(text: String) {
        message.text = text
        message.visibility = View.VISIBLE
    }
}
