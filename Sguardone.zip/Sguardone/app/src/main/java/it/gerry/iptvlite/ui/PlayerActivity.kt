package it.gerry.iptvlite.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.annotation.OptIn
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Repository
import it.gerry.iptvlite.vpn.VpnManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Player a schermo intero.
 * Telecomando: SU/GIÙ cambia canale, OK mostra le info, INDIETRO torna alla lista.
 */
@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_GROUP = "group"
        private const val EXTRA_INDEX = "index"

        fun start(context: Context, group: String, index: Int) {
            context.startActivity(
                Intent(context, PlayerActivity::class.java)
                    .putExtra(EXTRA_GROUP, group)
                    .putExtra(EXTRA_INDEX, index)
            )
        }
    }

    private val app by lazy { application as App }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var playerView: PlayerView
    private lateinit var overlay: View
    private lateinit var overlayNumber: TextView
    private lateinit var overlayLogo: ImageView
    private lateinit var overlayName: TextView
    private lateinit var overlayTitle: TextView
    private lateinit var overlayTime: TextView
    private lateinit var overlayProgress: ProgressBar
    private lateinit var overlayNext: TextView
    private lateinit var message: TextView

    private var player: ExoPlayer? = null
    private var dataSourceFactory: OkHttpDataSource.Factory? = null
    private var channels: List<Channel> = emptyList()
    private var index = 0
    private var retries = 0

    private val hideOverlay = Runnable { overlay.visibility = View.GONE }
    private val retryRunnable = Runnable { if (app.vpn.isUp) player?.prepare() }
    private var pendingZap: Runnable? = null

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY) {
                retries = 0
                message.visibility = View.GONE
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val p = player ?: return
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                p.seekToDefaultPosition()
                p.prepare()
                return
            }
            if (causes(error).any { it.message?.contains("non HTTPS") == true }) {
                showMessage("Lo stream usa connessioni non HTTPS: bloccato.\nPuoi consentirlo nelle impostazioni (sconsigliato).")
                return
            }
            val status = causes(error).filterIsInstance<HttpDataSource.InvalidResponseCodeException>()
                .firstOrNull()?.responseCode
            // Riprovare ha senso solo per errori temporanei (rete o server 5xx), non per 4xx.
            val retryable = status == null || status >= 500
            if (retryable && retries < 3 && app.vpn.isUp) {
                retries++
                showMessage("Riconnessione… ($retries/3)")
                handler.removeCallbacks(retryRunnable)
                handler.postDelayed(retryRunnable, 2000L * retries)
            } else {
                showMessage(if (status != null) httpMessage(status) else "Stream non disponibile (${error.errorCodeName})")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        overlayNumber = findViewById(R.id.overlayNumber)
        overlayLogo = findViewById(R.id.overlayLogo)
        overlayName = findViewById(R.id.overlayName)
        overlayTitle = findViewById(R.id.overlayTitle)
        overlayTime = findViewById(R.id.overlayTime)
        overlayProgress = findViewById(R.id.overlayProgress)
        overlayNext = findViewById(R.id.overlayNext)
        message = findViewById(R.id.message)

        index = intent.getIntExtra(EXTRA_INDEX, 0)
        val group = intent.getStringExtra(EXTRA_GROUP) ?: Repository.ALL

        lifecycleScope.launch {
            channels = withContext(Dispatchers.IO) { app.repo.channels(group) }
            if (player != null) play(index)
        }

        // Kill-switch applicativo: se il tunnel non è attivo, la riproduzione si ferma subito.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                app.vpn.state.collect { state ->
                    if (state !is VpnManager.State.Up) {
                        player?.stop()
                        showMessage("VPN non attiva: riproduzione bloccata")
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        initPlayer()
        if (channels.isNotEmpty()) play(index)
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(-1); true }
        KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(+1); true }
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_INFO -> {
            channels.getOrNull(index)?.let { showOverlay(it) }
            true
        }
        KeyEvent.KEYCODE_MENU -> { toggleFavorite(); true }
        else -> super.onKeyDown(keyCode, event)
    }

    /**
     * Cambio canale: l'info del canale si aggiorna subito, lo stream parte solo quando
     * smetti di premere (0,7 s). Così non si aprono tante connessioni verso il fornitore.
     */
    private fun zap(delta: Int) {
        if (channels.isEmpty()) return
        index = ((index + delta) % channels.size + channels.size) % channels.size
        showOverlay(channels[index])
        pendingZap?.let { handler.removeCallbacks(it) }
        pendingZap = Runnable { play(index) }.also { handler.postDelayed(it, 700L) }
    }

    private fun toggleFavorite() {
        val ch = channels.getOrNull(index) ?: return
        lifecycleScope.launch {
            val added = withContext(Dispatchers.IO) { app.repo.toggleFavorite(ch.name) }
            showOverlay(ch)
            overlayName.text = (if (added) "★ Aggiunto ai preferiti: " else "Tolto dai preferiti: ") + ch.name
        }
    }

    private fun causes(error: Throwable): List<Throwable> =
        generateSequence(error) { it.cause }.take(10).toList()

    private fun httpMessage(code: Int): String = when (code) {
        401, 403 ->
            "Accesso negato dal server del canale (HTTP $code).\n" +
                "Cause tipiche: il fornitore blocca gli IP VPN, abbonamento scaduto o troppe connessioni.\n" +
                "Prova \"Cambia server VPN\" nelle impostazioni."
        404, 410 ->
            "Canale non trovato (HTTP $code): il link non è più valido.\nAggiorna la lista dalle impostazioni."
        429, 458, 509 ->
            "Troppe connessioni contemporanee (HTTP $code).\nChiudi lo stream su altri dispositivi e riprova tra poco."
        in 500..599 ->
            "Server del canale non disponibile (HTTP $code). Riprova più tardi."
        else -> "Errore dal server del canale (HTTP $code)."
    }

    private fun initPlayer() {
        val dsf = OkHttpDataSource.Factory(app.http).setUserAgent(Repository.DEFAULT_UA)
        dataSourceFactory = dsf
        // Buffer contenuti: avvio rapido e poca RAM, adatti a Fire Stick.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(8_000, 30_000, 1_500, 3_000)
            .build()
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsf))
            .setLoadControl(loadControl)
            .build()
            .also { p ->
                p.addListener(listener)
                playerView.player = p
            }
    }

    private fun releasePlayer() {
        handler.removeCallbacksAndMessages(null)
        playerView.player = null
        player?.release()
        player = null
    }

    private fun play(target: Int) {
        val p = player ?: return
        if (channels.isEmpty()) return
        index = ((target % channels.size) + channels.size) % channels.size
        val ch = channels[index]
        showOverlay(ch)

        if (!app.vpn.isUp) {
            p.stop()
            showMessage("VPN non attiva: riproduzione bloccata")
            return
        }

        if (app.prefs.httpsOnlyStreams && !ch.url.startsWith("https://", ignoreCase = true)) {
            p.stop()
            showMessage("Canale non HTTPS: bloccato.\nPuoi consentirlo nelle impostazioni (sconsigliato).")
            return
        }

        retries = 0
        handler.removeCallbacks(retryRunnable)
        message.visibility = View.GONE
        dataSourceFactory?.setUserAgent(ch.userAgent ?: Repository.DEFAULT_UA)
        dataSourceFactory?.setDefaultRequestProperties(ch.referer?.let { mapOf("Referer" to it) } ?: emptyMap())

        val item = MediaItem.Builder()
            .setUri(ch.url)
            .apply { if (ch.url.contains(".m3u8", ignoreCase = true)) setMimeType(MimeTypes.APPLICATION_M3U8) }
            .build()
        p.setMediaItem(item)
        p.prepare()
        p.playWhenReady = true
    }

    /** Barra info in stile Sky: numero, logo, nome, programma in onda con avanzamento, successivo. */
    private fun showOverlay(ch: Channel) {
        val star = if (app.repo.isFavorite(ch.name)) "★ " else ""
        overlayNumber.text = (index + 1).toString()
        overlayName.text = "$star${ch.name}"
        overlayTitle.text = ""
        overlayTime.text = ""
        overlayNext.text = ""
        overlayProgress.visibility = View.INVISIBLE
        app.logos.load(ch.logo, overlayLogo)
        overlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideOverlay)
        handler.postDelayed(hideOverlay, 5000L)
        lifecycleScope.launch {
            val (now, next) = withContext(Dispatchers.IO) { app.repo.nowNext(ch.epgKey) }
            if (channels.getOrNull(index) != ch) return@launch
            if (now != null) {
                overlayTitle.text = now.title
                overlayTime.text = Format.range(now)
                overlayProgress.progress = Format.progress(now)
                overlayProgress.visibility = View.VISIBLE
            } else {
                overlayTitle.text = if (ch.epgKey == null) "Nessuna guida" else "Nessun programma in corso"
            }
            overlayNext.text = Format.next(next)
        }
    }

    private fun showMessage(text: String) {
        message.text = text
        message.visibility = View.VISIBLE
    }
}
