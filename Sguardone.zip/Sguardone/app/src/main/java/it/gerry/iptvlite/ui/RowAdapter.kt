package it.gerry.iptvlite.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.R

/** Adapter generico a due righe, navigabile con il D-pad del telecomando. */
class RowAdapter<T>(
    private val title: (T) -> String,
    private val subtitle: (T) -> String? = { null },
    private val focusable: Boolean = true,
    private val onFocus: (T, Int) -> Unit = { _, _ -> },
    private val onClick: (T, Int) -> Unit = { _, _ -> },
) : RecyclerView.Adapter<RowAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.title)
        val subtitle: TextView = view.findViewById(R.id.subtitle)
    }

    var items: List<T> = emptyList()
        @SuppressLint("NotifyDataSetChanged")
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false)
        view.isFocusable = focusable
        view.isClickable = focusable
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.title.text = title(item)
        val sub = subtitle(item)
        holder.subtitle.text = sub.orEmpty()
        holder.subtitle.visibility = if (sub.isNullOrEmpty()) View.GONE else View.VISIBLE
        if (focusable) {
            holder.itemView.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) onFocus(item, holder.bindingAdapterPosition)
            }
            holder.itemView.setOnClickListener { onClick(item, holder.bindingAdapterPosition) }
        }
    }
}
