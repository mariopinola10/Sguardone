package it.gerry.iptvlite.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Group
import it.gerry.iptvlite.data.Programme
import it.gerry.iptvlite.data.Repository
import it.gerry.iptvlite.vpn.VpnManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Flusso all'avvio: consenso VPN -> tunnel Mullvad verificato -> lista M3U -> UI -> EPG in background.
 * Finché il tunnel non è verificato l'app non scarica nulla dal fornitore IPTV.
 */
class MainActivity : ComponentActivity() {

    private val app by lazy { application as App }
    private val handler = Handler(Looper.getMainLooper())
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.ITALY)

    private lateinit var vpnStatus: TextView
    private lateinit var info: TextView
    private lateinit var retryButton: Button
    private lateinit var groupsList: RecyclerView
    private lateinit var channelsList: RecyclerView
    private lateinit var nowTitle: TextView
    private lateinit var nowTime: TextView
    private lateinit var nowDesc: TextView

    private lateinit var groupAdapter: RowAdapter<Group>
    private lateinit var channelAdapter: RowAdapter<Channel>
    private lateinit var epgAdapter: RowAdapter<Programme>

    private var currentGroup = Repository.ALL
    private var currentChannel: Channel? = null
    private var started = false
    private var loadJob: Job? = null
    private var epgJob: Job? = null
    private var pendingGroup: Runnable? = null
    private var pendingChannel: Runnable? = null

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) connectAndLoad()
            else showError("Permesso VPN negato: senza VPN l'app non si collega a nulla.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        vpnStatus = findViewById(R.id.vpnStatus)
        info = findViewById(R.id.info)
        retryButton = findViewById(R.id.retryButton)
        groupsList = findViewById(R.id.groupsList)
        channelsList = findViewById(R.id.channelsList)
        nowTitle = findViewById(R.id.nowTitle)
        nowTime = findViewById(R.id.nowTime)
        nowDesc = findViewById(R.id.nowDesc)

        findViewById<Button>(R.id.settingsButton).setOnClickListener { openSettings() }
        retryButton.setOnClickListener { startFlow() }

        groupAdapter = RowAdapter(
            title = { "${it.name}  (${it.count})" },
            onFocus = { g, _ -> debounceGroup(g.name) },
            onClick = { g, _ -> selectGroup(g.name, focusChannels = true) },
        )
        channelAdapter = RowAdapter(
            title = { it.name },
            subtitle = { app.repo.nowPlaying(it.epgKey)?.title },
            onFocus = { ch, _ -> debounceChannel(ch) },
            onClick = { _, pos -> PlayerActivity.start(this, currentGroup, pos) },
        )
        epgAdapter = RowAdapter(
            title = { "${timeFmt.format(Date(it.start))}   ${it.title}" },
            focusable = false,
        )

        groupsList.layoutManager = LinearLayoutManager(this)
        groupsList.adapter = groupAdapter
        channelsList.layoutManager = LinearLayoutManager(this)
        channelsList.adapter = channelAdapter
        findViewById<RecyclerView>(R.id.epgList).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = epgAdapter
            isFocusable = false
            descendantFocusability = RecyclerView.FOCUS_BLOCK_DESCENDANTS
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                app.vpn.state.collect { renderVpn(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!app.prefs.isConfigured) {
            openSettings()
            return
        }
        if (app.configDirty) {
            app.configDirty = false
            started = false
            clearLists()
        }
        if (!started) {
            started = true
            startFlow()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        // Uscita dall'app: chiude il tunnel.
        if (isFinishing) app.appScope.launch { app.vpn.disconnect() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            openSettings()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- Avvio ----------

    private fun startFlow() {
        retryButton.visibility = View.GONE
        val intent = app.vpn.permissionIntent()
        if (intent != null) vpnPermission.launch(intent) else connectAndLoad()
    }

    private fun connectAndLoad() {
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            try {
                setInfo("Connessione a Mullvad…")
                app.vpn.connect()
                withContext(Dispatchers.IO) { app.repo.refreshPlaylist(false, ::postInfo) }
                loadGroups()
                setInfo("")
                refreshEpgInBackground()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                showError(e.message ?: e.toString())
            }
        }
    }

    private fun refreshEpgInBackground() {
        epgJob?.cancel()
        epgJob = lifecycleScope.launch {
            try {
                val updated = withContext(Dispatchers.IO) { app.repo.refreshEpg(false, ::postInfo) }
                if (updated) {
                    channelAdapter.notifyItemRangeChanged(0, channelAdapter.itemCount)
                    currentChannel?.let { showEpg(it) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setInfo("Guida EPG non disponibile: ${e.message}")
            }
        }
    }

    // ---------- Liste ----------

    private suspend fun loadGroups() {
        val groups = withContext(Dispatchers.IO) { app.repo.groups() }
        groupAdapter.items = groups
        currentGroup = ""
        selectGroup(Repository.ALL, focusChannels = true)
    }

    private fun selectGroup(name: String, focusChannels: Boolean) {
        if (name == currentGroup) {
            if (focusChannels) focusFirst(channelsList)
            return
        }
        currentGroup = name
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { app.repo.channels(name) }
            if (currentGroup != name) return@launch
            channelAdapter.items = list
            channelsList.scrollToPosition(0)
            if (focusChannels) focusFirst(channelsList)
            list.firstOrNull()?.let { showEpg(it) }
        }
    }

    private fun debounceGroup(name: String) {
        pendingGroup?.let { handler.removeCallbacks(it) }
        pendingGroup = Runnable { selectGroup(name, focusChannels = false) }.also { handler.postDelayed(it, 300) }
    }

    private fun debounceChannel(ch: Channel) {
        currentChannel = ch
        pendingChannel?.let { handler.removeCallbacks(it) }
        pendingChannel = Runnable { showEpg(ch) }.also { handler.postDelayed(it, 150) }
    }

    private fun showEpg(ch: Channel) {
        currentChannel = ch
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { app.repo.programmes(ch.epgKey) }
            if (currentChannel != ch) return@launch
            val now = System.currentTimeMillis()
            val current = list.firstOrNull()?.takeIf { it.start <= now }
            if (current != null) {
                nowTitle.text = current.title
                nowTime.text = "${ch.name}  ·  ${timeFmt.format(Date(current.start))} – ${timeFmt.format(Date(current.stop))}"
                nowDesc.text = current.description.orEmpty()
                epgAdapter.items = list.drop(1)
            } else {
                nowTitle.text = ch.name
                nowTime.text = ""
                nowDesc.text = if (ch.epgKey == null) "Nessuna guida per questo canale" else ""
                epgAdapter.items = list
            }
        }
    }

    private fun clearLists() {
        groupAdapter.items = emptyList()
        channelAdapter.items = emptyList()
        epgAdapter.items = emptyList()
        currentGroup = Repository.ALL
        currentChannel = null
        nowTitle.text = ""
        nowTime.text = ""
        nowDesc.text = ""
    }

    private fun focusFirst(list: RecyclerView) {
        list.post {
            list.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() ?: list.requestFocus()
        }
    }

    // ---------- Stato ----------

    private fun renderVpn(state: VpnManager.State) {
        when (state) {
            VpnManager.State.Down -> setVpn("VPN: disattivata", COLOR_ERROR)
            VpnManager.State.Connecting -> setVpn("VPN: connessione…", COLOR_WAIT)
            is VpnManager.State.Up -> setVpn("VPN Mullvad: connessa · ${state.relay}", COLOR_OK)
            is VpnManager.State.Error -> {
                setVpn("VPN: errore", COLOR_ERROR)
                if (started) showError(state.message)
            }
        }
    }

    private fun setVpn(text: String, color: Int) {
        vpnStatus.text = text
        vpnStatus.setTextColor(color)
    }

    private fun setInfo(text: String) {
        info.text = text
    }

    private fun postInfo(text: String) {
        runOnUiThread { info.text = text }
    }

    private fun showError(message: String) {
        info.text = message
        retryButton.visibility = View.VISIBLE
        retryButton.requestFocus()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private companion object {
        val COLOR_OK = Color.parseColor("#4CAF50")
        val COLOR_WAIT = Color.parseColor("#FFC107")
        val COLOR_ERROR = Color.parseColor("#F44336")
    }
}
