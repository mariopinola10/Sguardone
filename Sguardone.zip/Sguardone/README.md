# Sguardone (Fire TV)

App Android leggera per Fire TV Stick: liste M3U, guida EPG XMLTV e player Media3.
Tutto il traffico dell'app passa da un tunnel **WireGuard Mullvad**, configurato da solo tramite API.

## Come funziona all'avvio
1. Chiede il consenso VPN di sistema (solo la prima volta).
2. Genera una chiave WireGuard e la registra sull'account Mullvad (`api.mullvad.net/wg/`), solo la prima volta.
3. Scarica la lista server, sceglie un server del paese impostato e alza il tunnel, **solo per questa app**.
4. Verifica su `am.i.mullvad.net/connected` che il traffico esca davvero da Mullvad.
5. Solo dopo scarica la lista M3U, mostra i canali e aggiorna l'EPG in background (cache di 12 ore).

**Tentativi automatici di collegamento**: se la verifica fallisce l'app riprova sulla porta 53 (quasi mai bloccata), poi registra di nuovo la chiave sull'account (utile se era stata rimossa dalla lista dispositivi), poi prova un altro server. Se non ci riesce, il messaggio indica la causa più probabile: rete che blocca WireGuard (UDP), chiave non valida o server con problemi.

**Kill-switch applicativo**: se il tunnel cade, il player si ferma e la UI mostra "Riprova".
All'uscita dall'app il tunnel viene chiuso.

## Compilazione
1. Apri la cartella in **Android Studio** (Ladybug o successivo, JDK 17+).
2. Aspetta la sincronizzazione Gradle.
3. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. L'APK si trova in `app/build/outputs/apk/debug/app-debug.apk`.

Da riga di comando: `./gradlew assembleDebug`

## Compilazione con GitHub (senza PC)
A ogni push su `main`, GitHub Actions compila l'APK e lo pubblica come release.
Link fisso all'ultima versione:
`https://github.com/<utente>/<repo>/releases/latest/download/Sguardone.apk`

## Installazione su Fire Stick
1. Sul Fire Stick: Impostazioni → La mia Fire TV → Opzioni sviluppatore → **Debug ADB: ON**.
2. Annota l'IP del Fire Stick (Impostazioni → La mia Fire TV → Informazioni → Rete).
3. Dal PC:
   ```
   adb connect 192.168.1.XX:5555
   adb install -r app-debug.apk
   ```
4. Log per il debug: `adb logcat | grep -iE "iptvlite|WireGuard|ExoPlayer|AndroidRuntime"`

**Nota**: i modelli Fire TV con **Vega OS** non eseguono APK. Serve un modello con Fire OS.

## Configurazione
Al primo avvio si aprono le impostazioni:
- **Account Mullvad**: le 16 cifre.
- **Paese**: codice a due lettere (`it`, `ch`, `de`, `nl`…).
- **Liste M3U**: uno o più **link** https, uno per riga (massimo 10), e/o un **file** caricato (anche `.gz`). Con più liste i canali vengono uniti e i gruppi diventano «Lista N · Gruppo». Se una lista non risponde, le altre vengono caricate lo stesso.
- **Guida EPG XMLTV**: facoltativa. Se vuota, l'app usa `url-tvg` / `x-tvg-url` dall'intestazione della lista.

### Account Xtream Codes
Nelle impostazioni, o dalla pagina sul telefono, inserisci **server https**, **utente** e **password** e premi "Aggiungi account Xtream" (massimo 5). L'app legge dall'API del fornitore categorie, canali live, loghi e la guida EPG (`xmltv.php`), e li unisce alle liste M3U. Con più sorgenti i gruppi diventano «Xtream N · Categoria». Con "Stream HLS (m3u8)" gli stream usano HLS, altrimenti MPEG-TS. Per rimuovere un account, selezionalo nell'elenco.

Limiti: sono supportati solo i canali live (niente film e serie on demand) e solo server HTTPS. Le credenziali restano salvate nello storage privato dell'app.

### Dal telefono (consigliato)
Con le impostazioni aperte, la TV mostra un indirizzo e un PIN, per esempio `http://192.168.1.50:8080 PIN 4821`.
1. Apri l'indirizzo dal browser del telefono, collegato alla stessa Wi-Fi.
2. Inserisci il PIN, l'account Mullvad e il link M3U, oppure scegli il file M3U dal telefono.
3. Premi **Invia alla TV**: l'app salva la configurazione e riparte.

I campi lasciati vuoti mantengono il valore attuale. Il server è attivo solo mentre le impostazioni sono aperte.

### Dal telecomando
Compila i campi e premi **Salva**. Il pulsante **Scegli file M3U** usa il selettore file di sistema, che su molti Fire Stick manca: in quel caso usa il telefono.

## Verifica HTTPS
- **Lista M3U e guida EPG**: solo `https://`. I link HTTP vengono rifiutati nelle impostazioni e ricontrollati prima di ogni download. Viene bloccato anche un redirect HTTPS → HTTP.
- **Stream dei canali**: per default ogni connessione, compresi segmenti HLS e redirect, deve essere HTTPS. In caso contrario il canale viene bloccato con un messaggio.
- All'import la lista indica quanti canali non sono HTTPS.
- L'opzione "Consenti stream dei canali non HTTPS" nelle impostazioni sblocca gli stream HTTP. Restano comunque cifrati verso l'ISP dal tunnel Mullvad, ma Mullvad potrebbe vederne il contenuto.

## Schermate
- **Guida (principale)**, in stile Sky: solo i canali **preferiti**, numerati, con logo, programma in onda, barra di avanzamento e programma successivo. In alto c'è il riquadro del programma selezionato, con orologio e stato della VPN.
- **Gestisci canali e preferiti**: dalle impostazioni (tasto Menu → "★ Gestisci canali e preferiti"). Mostra gruppi, canali e guida in tre colonne. Al primo avvio, se non hai preferiti, la guida propone direttamente questa schermata.

## Ricerca, eventi e promemoria
- **🔍 in alto nella guida**: cerca nei nomi dei canali e nella guida EPG (titolo e descrizione) per le prossime 48 ore. In cima i canali, poi i programmi in onda, poi quelli futuri in ordine di orario.
- **Programma in onda**: OK o tocco lo apre subito.
- **Programma futuro**: puoi impostare un **promemoria nell'app** (all'inizio compare un avviso con "Guarda") oppure, sul telefono, aggiungerlo al **calendario**. Si può anche tenere premuto per attivare o togliere il promemoria.
- **☆ Salva**: salva la ricerca (es. "Napoli") come scorciatoia. Le ricerche salvate compaiono **in evidenza** nella guida con il prossimo evento, per esempio "★ Napoli · Oggi 20:45 Napoli - Inter · DAZN 1". Toccandolo lo guardi, se è in onda, oppure apri la ricerca. Per eliminare una ricerca salvata, tienila premuta.
- **Limiti**: i promemoria nell'app funzionano solo con Sguardone aperto (per avvisi a app chiusa usa il calendario sul telefono). La ricerca dipende da come il fornitore della guida scrive i titoli.

## Chiusura della VPN
- Pulsante **spegnimento** in alto nella guida: chiude subito VPN, connessioni e app (anche dalle app recenti).
- **Indietro** dalla guida: chiede conferma e poi chiude tutto.
- App in **background per 5 minuti** (Home, app recenti, schermo spento): la VPN si chiude da sola. Tornando nell'app (guida o player) si ricollega automaticamente.

## Telefono, tablet e TV
L'app riconosce da sola il dispositivo:
- **Fire Stick / TV**: guida con riquadro del programma, comandi da telecomando.
- **Tablet in orizzontale**: come la TV, ma utilizzabile anche col tocco.
- **Telefono (e tablet in verticale)**: guida compatta senza riquadro. Tocca un canale per guardarlo; i pulsanti **Canali** e **⚙** in alto aprono la gestione dei preferiti e le impostazioni. Guida, impostazioni e gestione canali ruotano liberamente, il player resta in orizzontale.

## Lista canali rapida nel player
- **Telecomando**: freccia **SINISTRA** apre la lista (numero, nome e programma in onda in piccolo). OK cambia canale, DESTRA o Indietro la chiude.
- **Touch**: tocco sul lato sinistro dello schermo, oppure scorrimento verso destra. Scorrimento su/giù cambia canale, tocco al centro mostra le info.
- Nella lista, **tieni premuto** su un canale per aggiungerlo o toglierlo dai preferiti.

## Numerazione dei canali (come in TV)
- **Ordine automatico** (attivo di default, si può disattivare nelle impostazioni): i canali del digitale terrestre prendono il numero ufficiale LCN (Rai 1 = 1, Rai 2 = 2, Rai 3 = 3, Rete 4 = 4, Canale 5 = 5, Italia 1 = 6, La7 = 7, TV8 = 8, Nove = 9, 20Mediaset = 20, Rai 4 = 21…). **Sky da 101** (intrattenimento, poi Sport, poi Cinema), **DAZN da 201**, **tutti gli altri da 301** nell'ordine in cui li hai aggiunti.
- **Numero manuale**: tieni premuto un canale (o tasto Menu sul canale) e scegli "Imposta numero canale". Il numero manuale vince sempre; "Ripristina numero automatico" lo toglie.
- **Tasti numerici** (telecomandi che li hanno o tastiera): digitando il numero vai al canale, come in TV (conferma automatica dopo 1,5 s), sia nella guida sia nel player.
- La numerazione vale per la guida, per le schede delle cartelle e per lo zapping.
- Limite: la LCN nazionale cambia ogni tanto; se un canale finisce in un posto sbagliato, imposta il numero a mano.

## Cartelle preferite e filtro HTTPS
- In **gestione canali**, tieni premuto (o tasto Menu) su una **cartella** per aggiungerla ai preferiti. Nella guida compare come **scheda** accanto a "★ Preferiti"; spostandoti sulle schede (o toccandole) cambi l'elenco dei canali. Lo zapping nel player resta dentro la scheda aperta.
- La spunta **Solo HTTPS** accanto alle schede nasconde al volo i canali non HTTPS, sia nella guida sia nello zapping. La scelta resta salvata.

## Guida EPG
Le guide sono **sempre tutte attive** e vengono unite. Per ogni canale vince la prima che lo copre:
1. i link inseriti a mano nel campo EPG (facoltativi, separati da virgola);
2. la guida pubblica italiana (`epgshare01 IT1`);
3. le guide del fornitore: quelle dichiarate nelle liste M3U e `xmltv.php` degli account Xtream.

L'abbinamento guida-canale è tollerante: considera uguali per esempio "IT: Sky Sport Uno FHD", "Sky Sport 1 HD" e "SkySportUno.it", oppure "Rai Due" e "Rai 2". Ignora prefissi di paese, parentesi, accenti e parole di qualità (HD, FHD, 4K, HEVC, backup…). Nella schermata "Gestisci canali" vedi quanti canali hanno la guida.

## Lingue audio e sottotitoli
- Se il canale ha più lingue o sottotitoli (lingue alternative HLS, tracce multiple negli stream TS, sottotitoli DVB/CC/WebVTT), nella barra info compare "▶ 2 lingue · sottotitoli".
- **Telecomando**: freccia **DESTRA** nel player (o i tasti CC/Audio se presenti). **Telefono**: **tocco lungo** sul video, oppure il pulsante "Lingua/CC" nella lista rapida.
- La scelta viene ricordata come preferenza per gli altri canali. Di default: audio italiano, sottotitoli spenti.

## Video: decoder e compatibilità
- Sempre attivo: **ripiego automatico** su un altro decoder se quello hardware fallisce.
- **Modalità compatibilità**: dà la precedenza ai decoder software e attiva la **lettura MPEG-TS tollerante** (keyframe non marcati, confini dei fotogrammi ricostruiti) per stream `.ts` e HLS. Risolve molti casi di colori sbagliati o blocchi verdi, ma usa più CPU (sul Fire Stick i canali 1080p potrebbero scattare). Si attiva dalla spunta nelle impostazioni o dal pulsante "Compatibilità" nella lista canali rapida del player (SINISTRA), con effetto immediato.

## Buffer contro il lag
- **Automatico**: se lo stream si blocca dopo almeno 15 secondi di visione regolare, l'app aspetta una piccola riserva prima di ripartire, e la aumenta se succede di nuovo (5, 10, poi 20 secondi). Non resta mai ferma oltre la riserva più 5 secondi. In alto compare "Stream lento: accumulo riserva".
- **Manuale**: con **Play/Pausa** sul telecomando (o **doppio tocco** sul telefono) lo stream va in pausa ma continua a scaricare. In alto una barra mostra i secondi accumulati, fino a 2 minuti. Con Play riparte da dove eri, poco indietro rispetto alla diretta.
- **Limiti**: il buffer copre i cali momentanei, non una connessione troppo lenta per quello stream. Su alcuni stream HLS con poca "finestra" disponibile, una pausa molto lunga può far ripartire lo stream dalla diretta.

## Telecomando
- **Guida**: SU/GIÙ per scorrere, OK per guardare, Menu (≡) per le impostazioni.
- **Gestisci canali**: OK guarda; **OK tenuto premuto** o **Menu** aggiunge o toglie dai preferiti; Indietro torna alla guida. I preferiti restano anche quando aggiorni la lista, perché sono legati al nome del canale.
- **Player**: SU/GIÙ cambia canale (lo stream parte quando smetti di premere), OK mostra le info, Menu aggiunge o toglie dai preferiti, INDIETRO torna alla lista.

## Errori degli stream
- **HTTP 401/403**: il fornitore nega l'accesso, spesso perché blocca gli IP VPN, per un abbonamento scaduto o per troppe connessioni. Prova **Cambia server VPN** nelle impostazioni.
- **HTTP 404/410**: il link del canale non esiste più. Aggiorna la lista.
- **HTTP 429/458/509**: troppe connessioni contemporanee.
- Solo gli errori temporanei (rete, HTTP 5xx) vengono ritentati in automatico, fino a 3 volte con attese crescenti.

## Limiti noti
- Mullvad consente al massimo **5 dispositivi** per account. "Rigenera chiave VPN" ne usa uno nuovo: rimuovi quello vecchio dal sito Mullvad.
- La chiave privata WireGuard è salvata nello storage privato dell'app (non in un keystore hardware).
- Il kill-switch è a livello di app: in caso di caduta del tunnel può esserci un breve istante prima che il player si fermi.
- I loghi dei canali non sono mostrati, per tenere l'app leggera.

## Struttura
```
vpn/MullvadApi.kt      registrazione chiave + lista server
vpn/VpnManager.kt      tunnel WireGuard (GoBackend), verifica, stato
data/M3uParser.kt      parser M3U in streaming (tvg-*, group-title, EXTVLCOPT)
data/EpgImporter.kt    XMLTV in streaming -> SQLite (finestra -2h/+48h)
data/Repository.kt     download (gzip auto), cache, query
ui/MainActivity.kt     gruppi | canali | guida
ui/PlayerActivity.kt   Media3 ExoPlayer (HLS/TS), zapping, retry
ui/SettingsActivity.kt configurazione (telecomando, file, telefono)
config/ConfigServer.kt mini server web locale per configurare dal telefono
```
