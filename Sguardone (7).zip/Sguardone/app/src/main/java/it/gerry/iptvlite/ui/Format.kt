package it.gerry.iptvlite.ui

import it.gerry.iptvlite.data.Programme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Formattazione condivisa (solo thread principale). */
object Format {
    private val time = SimpleDateFormat("HH:mm", Locale.ITALY)
    private val date = SimpleDateFormat("EEE d MMM", Locale.ITALY)

    fun time(ms: Long): String = time.format(Date(ms))

    fun date(ms: Long): String = date.format(Date(ms)).replaceFirstChar { it.uppercase() }

    private val dayName = SimpleDateFormat("EEE d MMM", Locale.ITALY)
    private val dayKey = SimpleDateFormat("yyyyMMdd", Locale.ROOT)

    /** "Oggi 20:45", "Domani 15:00", "Sab 15 nov 18:00". */
    fun day(ms: Long): String {
        val now = System.currentTimeMillis()
        val key = dayKey.format(Date(ms))
        val label = when (key) {
            dayKey.format(Date(now)) -> "Oggi"
            dayKey.format(Date(now + 86_400_000L)) -> "Domani"
            else -> dayName.format(Date(ms)).replaceFirstChar { it.uppercase() }
        }
        return "$label ${time(ms)}"
    }

    fun range(p: Programme): String = "${time(p.start)} – ${time(p.stop)}"

    /** Avanzamento del programma in millesimi (0..1000), per le ProgressBar con max = 1000. */
    fun progress(p: Programme?, now: Long = System.currentTimeMillis()): Int {
        if (p == null || p.stop <= p.start) return 0
        return (((now - p.start) * 1000) / (p.stop - p.start)).toInt().coerceIn(0, 1000)
    }

    fun next(p: Programme?): String = p?.let { "Dopo  ${time(it.start)}  ${it.title}" } ?: ""
}
