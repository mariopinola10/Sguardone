package it.gerry.iptvlite.ui

import android.app.AlertDialog
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.ProgrammeHit
import it.gerry.iptvlite.data.Rating
import it.gerry.iptvlite.data.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Home: "Da non perdere".
 * - ⚽ il Napoli in onda o nelle prossime 12 ore, con i canali delle liste che lo trasmettono;
 * - 🎬 film e serie in onda o che iniziano entro un'ora con voto TMDB alto.
 * TV/tablet: elenco a destra sotto il programma del canale. Telefono: una riga di riepilogo (tocca per l'elenco).
 */
class HomePicks(private val activity: ComponentActivity, private val app: App) {

    sealed interface Item {
        data class Napoli(val match: Repository.Match) : Item
        data class Film(val hit: ProgrammeHit, val rating: Rating) : Item
    }

    private val title: TextView = activity.findViewById(R.id.picksTitle)
    private val list: RecyclerView = activity.findViewById(R.id.picksList)
    private val status: TextView = activity.findViewById(R.id.picksStatus)
    private val line: TextView = activity.findViewById(R.id.picksLine)

    private val adapter = RowAdapter<Item>(
        title = ::rowTitle,
        subtitle = ::rowSubtitle,
        onClick = { item, _ -> open(item) },
    )

    /** true = elenco laterale (TV, tablet orizzontale); false = riga di riepilogo (telefono). */
    var wide = true
        set(value) {
            field = value
            render()
        }

    private var job: Job? = null
    private var lastRun = 0L
    private var napoli: List<Repository.Match> = emptyList()
    private val films = LinkedHashMap<String, Item.Film>()
    private var searching = 0

    init {
        list.layoutManager = LinearLayoutManager(activity)
        list.adapter = adapter
        list.itemAnimator = null
        line.setOnClickListener { showDialog() }
    }

    /** Aggiorna (al massimo ogni 10 minuti, o subito con [force]: es. guida appena scaricata). */
    fun refresh(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (job?.isActive == true) return
        if (!force && now - lastRun < REFRESH_MS) {
            render()
            return
        }
        lastRun = now
        job = activity.lifecycleScope.launch {
            napoli = withContext(Dispatchers.IO) { runCatching { app.repo.napoliMatches() }.getOrDefault(emptyList()) }
            val candidates = withContext(Dispatchers.IO) { runCatching { app.repo.filmCandidates() }.getOrDefault(emptyList()) }
            films.clear()
            val known = withContext(Dispatchers.IO) {
                candidates.mapNotNull { h -> app.repo.cachedRating(h.programme)?.let { Item.Film(h, it) } }
            }
            known.forEach { films[key(it.hit)] = it }
            render()

            // Voti mancanti: dall'API TMDB, 4 alla volta, solo con la VPN attiva.
            if (!app.prefs.ratingsActive || !app.vpn.isUp) return@launch
            val missing = withContext(Dispatchers.IO) {
                candidates.filter { !app.repo.ratingKnown(it.programme) }.take(MAX_LOOKUPS)
            }
            searching = missing.size
            render()
            for (chunk in missing.chunked(4)) {
                val results = chunk.map { h -> async(Dispatchers.IO) { h to app.repo.rating(h.programme) } }.awaitAll()
                for ((h, r) in results) if (r != null) films[key(h)] = Item.Film(h, r)
                searching -= chunk.size
                render()
            }
            searching = 0
            render()
        }
    }

    private fun key(h: ProgrammeHit) = h.programme.title.lowercase() + "@" + h.programme.start

    private fun items(): List<Item> {
        val now = System.currentTimeMillis()
        val best = films.values
            .filter { it.rating.value >= MIN_RATING && it.rating.votes >= MIN_VOTES && it.hit.programme.stop > now }
            .sortedWith(compareByDescending<Item.Film> { it.rating.value }.thenBy { it.hit.programme.start })
            .take(8)
        return napoli.filter { it.programme.stop > now }.map { Item.Napoli(it) } + best
    }

    private fun render() {
        val items = items()
        val now = System.currentTimeMillis()
        val noNapoli = napoli.none { it.programme.stop > now }
        val info = buildList {
            if (noNapoli && lastRun > 0) add("⚽ Napoli: nessuna partita nelle prossime 12 ore")
            if (searching > 0) add("Cerco i voti TMDB… ($searching)")
            else if (lastRun > 0 && !app.prefs.ratingsActive) add("🎬 Per i film da non perdere inserisci la chiave TMDB nelle Impostazioni")
            else if (lastRun > 0 && items.none { it is Item.Film }) add("🎬 Nessun film o serie con voto alto ora o nella prossima ora")
        }.joinToString("\n")

        if (wide) {
            line.visibility = View.GONE
            if (adapter.items != items) adapter.items = items   // senza ricreare le righe il focus resta dov'è
            title.visibility = if (items.isNotEmpty() || info.isNotEmpty()) View.VISIBLE else View.GONE
            status.text = info
            status.visibility = if (info.isEmpty()) View.GONE else View.VISIBLE
        } else {
            title.visibility = View.GONE
            status.visibility = View.GONE
            if (adapter.items.isNotEmpty()) adapter.items = emptyList()
            val onAir = items.filterIsInstance<Item.Napoli>().firstOrNull()
            val nFilms = items.count { it is Item.Film }
            val parts = buildList {
                onAir?.let { add("⚽ ${whenText(it.match.programme.start)}  ${it.match.programme.title} · ${it.match.channels.firstOrNull()?.name.orEmpty()}") }
                if (nFilms > 0) add("🎬 $nFilms da non perdere")
                if (searching > 0) add("cerco i voti…")
            }
            line.text = parts.joinToString("   ·   ")
            line.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun whenText(start: Long): String =
        if (start <= System.currentTimeMillis()) "● IN ONDA" else Format.day(start)

    private fun rowTitle(item: Item): String = when (item) {
        is Item.Napoli -> "⚽ ${whenText(item.match.programme.start)}   ${item.match.programme.title}"
        is Item.Film -> "🎬 ${whenText(item.hit.programme.start)}   ${item.hit.programme.title}   ${Format.rating(item.rating)}"
    }

    private fun rowSubtitle(item: Item): String = when (item) {
        is Item.Napoli -> item.match.channels.take(4).joinToString("  ·  ") { it.name } +
            if (item.match.channels.size > 4) "  · +${item.match.channels.size - 4}" else ""
        is Item.Film -> listOfNotNull(
            item.hit.channel.name,
            Format.range(item.hit.programme),
            item.hit.programme.category,
        ).joinToString("  ·  ")
    }

    private fun showDialog() {
        val items = items()
        if (items.isEmpty()) return
        AlertDialog.Builder(activity)
            .setTitle("Da non perdere")
            .setItems(items.map { rowTitle(it) + "\n" + rowSubtitle(it) }.toTypedArray()) { _, which -> open(items[which]) }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private fun open(item: Item) {
        val now = System.currentTimeMillis()
        val (programme, channels) = when (item) {
            is Item.Napoli -> item.match.programme to item.match.channels
            is Item.Film -> item.hit.programme to listOf(item.hit.channel)
        }
        if (channels.isEmpty()) return
        val onAir = programme.start <= now
        if (onAir && channels.size == 1) {
            PlayerActivity.startByName(activity, channels[0].name)
            return
        }
        val options = ArrayList<Pair<String, () -> Unit>>()
        if (!onAir) {
            options.add("⏰ Promemoria alle ${Format.time(programme.start)}" to {
                activity.lifecycleScope.launch {
                    withContext(Dispatchers.IO) { app.repo.addReminder(channels[0].name, programme) }
                    Toast.makeText(activity, "Promemoria impostato: ${programme.title}", Toast.LENGTH_LONG).show()
                }
                Unit
            })
        }
        for (ch in channels) {
            options.add((if (onAir) "▶ Guarda su ${ch.name}" else "▶ Guarda ${ch.name} adesso") to {
                PlayerActivity.startByName(activity, ch.name)
            })
        }
        AlertDialog.Builder(activity)
            .setTitle(programme.title)
            .setItems(options.map { it.first }.toTypedArray()) { _, which -> options[which].second() }
            .setNegativeButton("Chiudi", null)
            .show()
    }

    private companion object {
        const val REFRESH_MS = 10 * 60_000L
        const val MAX_LOOKUPS = 40
        /** Voto minimo TMDB (su 10) e voti minimi perché sia affidabile. */
        const val MIN_RATING = 7.0
        const val MIN_VOTES = 100
    }
}
