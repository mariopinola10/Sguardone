package it.gerry.iptvlite.ui

import android.app.AlertDialog
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText

/**
 * Campi di testo comodi col telecomando.
 * Su TV il campo si comporta come un pulsante: le frecce cambiano campo (non muovono il cursore)
 * e OK apre un riquadro con la tastiera. Su telefono/tablet non cambia nulla.
 */
object TvText {

    fun apply(field: EditText, title: String, onDone: (() -> Unit)? = null) {
        val ctx = field.context
        if (!Device.isTv(ctx)) return
        field.showSoftInputOnFocus = false
        field.isCursorVisible = false
        field.isFocusable = true
        field.isFocusableInTouchMode = false
        field.setOnClickListener { open(field, title, onDone) }
        field.setOnKeyListener { v, keyCode, event ->
            if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener when (keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> true
                else -> false
            }
            val dir = when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> View.FOCUS_UP
                KeyEvent.KEYCODE_DPAD_DOWN -> View.FOCUS_DOWN
                KeyEvent.KEYCODE_DPAD_LEFT -> View.FOCUS_LEFT
                KeyEvent.KEYCODE_DPAD_RIGHT -> View.FOCUS_RIGHT
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    open(field, title, onDone)
                    return@setOnKeyListener true
                }
                else -> return@setOnKeyListener false
            }
            v.focusSearch(dir)?.requestFocus()
            true
        }
    }

    private fun open(field: EditText, title: String, onDone: (() -> Unit)?) {
        val ctx = field.context
        val multi = (field.inputType and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        val input = EditText(ctx).apply {
            inputType = field.inputType
            setText(field.text)
            setSelection(text.length)
            hint = field.hint
            if (multi) {
                minLines = 3
                maxLines = 8
            } else {
                setSingleLine(true)
                imeOptions = EditorInfo.IME_ACTION_DONE
            }
        }
        val dialog = AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ ->
                field.setText(input.text)
                onDone?.invoke()
            }
            .setNegativeButton("Annulla", null)
            .create()
        if (!multi) {
            input.setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_DONE || action == EditorInfo.IME_NULL) {
                    field.setText(input.text)
                    onDone?.invoke()
                    dialog.dismiss()
                    true
                } else false
            }
        }
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        dialog.show()
        input.requestFocus()
    }
}
