package it.gerry.iptvlite.data

data class Channel(
    val id: Long,
    val name: String,
    val group: String,
    val url: String,
    val userAgent: String?,
    val referer: String?,
    val epgKey: String?,
    val logo: String? = null,
)

data class Programme(
    val start: Long,
    val stop: Long,
    val title: String,
    val description: String?,
)

data class Group(val name: String, val count: Int)

/** Risultato di ricerca EPG: programma e canale su cui va in onda. */
data class ProgrammeHit(val channel: Channel, val programme: Programme)

data class Reminder(val channel: String, val title: String, val start: Long, val stop: Long)
