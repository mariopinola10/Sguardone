package it.gerry.iptvlite.update

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * Aggiornamento dall'ultima release GitHub del progetto.
 * La build pubblica accanto all'APK un file version.json con versione e impronta SHA-256:
 * l'APK scaricato si installa solo se l'impronta coincide ed è proprio Sguardone in versione più nuova.
 */
class Updater(private val context: Context, http: OkHttpClient) {

    data class Info(val versionCode: Long, val versionName: String, val sha256: String, val apk: String)

    private val client = http.newBuilder().readTimeout(60, TimeUnit.SECONDS).build()

    val installedCode: Long
        get() = runCatching {
            PackageInfoCompat.getLongVersionCode(context.packageManager.getPackageInfo(context.packageName, 0))
        }.getOrDefault(0L)

    /** Legge version.json dell'ultima release. Fuori dal thread principale. */
    fun latest(): Info {
        val req = Request.Builder().url(VERSION_URL).header("Accept", "application/json").build()
        val json = client.newCall(req).execute().use { r ->
            if (r.code == 404) throw IOException("l'ultima build non ha version.json: aggiorna il file build.yml su GitHub")
            if (!r.isSuccessful) throw IOException("GitHub HTTP ${r.code}")
            JSONObject(r.body?.string().orEmpty())
        }
        val apk = json.optString("apk")
        if (!apk.startsWith("https://github.com/$REPO/")) throw IOException("indirizzo APK non valido")
        val sha = json.optString("sha256").lowercase()
        if (!sha.matches(Regex("[0-9a-f]{64}"))) throw IOException("impronta SHA-256 mancante")
        return Info(json.optLong("versionCode"), json.optString("versionName"), sha, apk)
    }

    fun isNewer(info: Info) = info.versionCode > installedCode

    /** Scarica e verifica l'APK. [progress] riceve la percentuale (0..100, -1 se sconosciuta). */
    fun download(info: Info, progress: (Int) -> Unit): File {
        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        val file = File(dir, "Sguardone.apk")
        if (file.exists() && sha256(file) == info.sha256) return verify(file, info)
        file.delete()
        val tmp = File(dir, "download.tmp")
        val req = Request.Builder().url(info.apk).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("download non riuscito (HTTP ${r.code})")
            val body = r.body ?: throw IOException("download vuoto")
            val total = body.contentLength()
            var done = 0L
            var lastPct = -2
            body.byteStream().use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n == -1) break
                        out.write(buf, 0, n)
                        done += n
                        if (done > MAX_APK) throw IOException("file troppo grande")
                        val pct = if (total > 0) (done * 100 / total).toInt() else -1
                        if (pct != lastPct) {
                            lastPct = pct
                            progress(pct)
                        }
                    }
                }
            }
        }
        if (sha256(tmp) != info.sha256) {
            tmp.delete()
            throw IOException("impronta SHA-256 diversa: file scartato")
        }
        if (!tmp.renameTo(file)) {
            tmp.copyTo(file, overwrite = true)
            tmp.delete()
        }
        return verify(file, info)
    }

    /** Deve essere Sguardone e della versione annunciata. */
    private fun verify(file: File, info: Info): File {
        val pkg = context.packageManager.getPackageArchiveInfo(file.path, 0)
            ?: run { file.delete(); throw IOException("APK non leggibile") }
        if (pkg.packageName != context.packageName) {
            file.delete()
            throw IOException("l'APK non è Sguardone")
        }
        if (PackageInfoCompat.getLongVersionCode(pkg) != info.versionCode) {
            file.delete()
            throw IOException("versione dell'APK diversa da quella annunciata")
        }
        return file
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n == -1) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        const val REPO = "mariopinola10/Sguardone"
        private const val VERSION_URL = "https://github.com/$REPO/releases/latest/download/version.json"
        private const val MAX_APK = 200L * 1024 * 1024
    }
}
