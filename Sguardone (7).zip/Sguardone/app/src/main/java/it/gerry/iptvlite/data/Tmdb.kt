package it.gerry.iptvlite.data

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.text.Normalizer

/**
 * Voti di TMDB (The Movie Database, voto medio degli utenti da 0 a 10) per film e serie.
 * API ufficiale, gratuita per uso personale con la propria chiave. Sempre HTTPS, dentro la VPN.
 * Ricerca con i titoli italiani (language=it-IT): una sola richiesta leggera per titolo.
 */
class Tmdb(private val http: OkHttpClient, private val key: () -> String) {

    /**
     * Voto del titolo, null se TMDB non lo conosce.
     * Eccezione per errori di rete o chiave non valida (non vanno in cache).
     */
    fun lookup(title: String, year: Int?, series: Boolean? = null): Rating? {
        val k = key().trim()
        if (k.isEmpty()) throw IOException("chiave TMDB mancante")
        val clean = cleanTitle(title)
        val wanted = norm(clean)
        if (wanted.length < 2) return null

        val b = "$BASE/search/multi".toHttpUrl().newBuilder()
            .addQueryParameter("query", clean)
            .addQueryParameter("language", "it-IT")
            .addQueryParameter("include_adult", "false")
        val bearer = isReadToken(k)
        if (!bearer) b.addQueryParameter("api_key", k)
        val req = Request.Builder().url(b.build()).header("Accept", "application/json")
        if (bearer) req.header("Authorization", "Bearer $k")

        val json = http.newCall(req.build()).execute().use { r ->
            if (r.code == 401) throw IOException("chiave TMDB non valida")
            if (!r.isSuccessful) throw IOException("TMDB HTTP ${r.code}")
            JSONObject(r.body?.string().orEmpty())
        }
        val results = json.optJSONArray("results") ?: return null

        data class Hit(val id: Long, val tv: Boolean, val names: List<String>, val year: Int?, val vote: Double, val votes: Int, val pop: Double)

        val hits = (0 until results.length()).mapNotNull { i ->
            val o = results.optJSONObject(i) ?: return@mapNotNull null
            val type = o.optString("media_type")
            if (type != "movie" && type != "tv") return@mapNotNull null
            val tv = type == "tv"
            val names = listOf(
                o.optString(if (tv) "name" else "title"),
                o.optString(if (tv) "original_name" else "original_title"),
            ).filter { it.isNotBlank() }
            val date = o.optString(if (tv) "first_air_date" else "release_date")
            Hit(
                id = o.optLong("id"),
                tv = tv,
                names = names,
                year = date.take(4).toIntOrNull(),
                vote = o.optDouble("vote_average", 0.0),
                votes = o.optInt("vote_count", 0),
                pop = o.optDouble("popularity", 0.0),
            )
        }
        // Solo titoli uguali (normalizzati); poi anno vicino, tipo giusto, più voti.
        val exact = hits.filter { h -> h.names.any { norm(it) == wanted } }
        // Senza titolo identico: titolo che inizia uguale ("Dune" / "Dune - Parte due"), solo se l'anno coincide.
        val candidates = exact.ifEmpty {
            if (year == null || wanted.length < 6) emptyList()
            else hits.filter { h -> h.year == year && h.names.any { val n = norm(it); n.startsWith(wanted) || wanted.startsWith(n) } }
        }
        val best = candidates
            .filter { h -> year == null || h.year == null || kotlin.math.abs(h.year - year) <= 1 }
            .sortedWith(
                compareBy<Hit>(
                    { if (year != null && it.year == year) 0 else 1 },
                    { if (series == null || it.tv == series) 0 else 1 },
                    { -it.votes },
                )
            )
            .firstOrNull() ?: return null
        if (best.votes < MIN_VOTES || best.vote <= 0.0) return null
        val url = "https://www.themoviedb.org/${if (best.tv) "tv" else "movie"}/${best.id}"
        return Rating(best.vote, url, best.votes)
    }

    companion object {
        private const val BASE = "https://api.themoviedb.org/3"
        /** Sotto questa soglia il voto è poco affidabile e non si mostra. */
        private const val MIN_VOTES = 20

        private val DIACRITICS = Regex("\\p{Mn}+")
        private val NOISE = listOf(
            Regex("""(?i)\(\s*(1[ªa°]?\s*tv|prima\s+tv|replica|r)\s*\)"""),
            Regex("""(?i)\s*-\s*(1[ªa°]?\s*tv|prima\s+tv)\b.*$"""),
            Regex("""(?i)\s*[-:,]?\s+(stagione|st\.|season|s)\s*\d+.*$"""),
            Regex("""(?i)\s*[-:,]?\s+(episodio|ep\.?|puntata|e(?=\d))\s*\d+.*$"""),
            Regex("""\s*\(\d{4}\)\s*$"""),
            Regex("""\s*\[[^\]]*]"""),
        )

        /** Chiave v4 (token di lettura, "eyJ…") oppure chiave v3 (32 caratteri esadecimali). */
        fun isReadToken(k: String) = k.startsWith("eyJ")

        fun isValidKey(k: String): Boolean {
            val t = k.trim()
            return (isReadToken(t) && t.length > 100) || t.matches(Regex("[0-9a-fA-F]{32}"))
        }

        /** Titolo senza "1ª TV", stagione/episodio, anno tra parentesi. */
        fun cleanTitle(title: String): String {
            var t = title
            for (r in NOISE) t = t.replace(r, "")
            return t.trim().trimEnd('-', ':', ',', ' ')
        }

        /** "Il Gladiatore!" -> "ilgladiatore": per confrontare i titoli. */
        fun norm(title: String): String =
            Normalizer.normalize(title.lowercase().replace("&", "e"), Normalizer.Form.NFD)
                .replace(DIACRITICS, "")
                .filter { it in 'a'..'z' || it in '0'..'9' }

        /** Chiave della cache: titolo pulito + anno. */
        fun cacheKey(title: String, year: Int?): String = norm(cleanTitle(title)) + (year?.let { "@$it" } ?: "")
    }
}
