package it.gerry.iptvlite.cast

import android.content.Context
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManager
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Google Cast senza pulsanti di sistema: ricerca dei dispositivi con MediaRouter,
 * connessione e invio dello stream HLS servito dal ponte (quindi sempre dentro la VPN).
 * Tutte le funzioni vanno chiamate sul thread principale.
 */
class GoogleCast(private val context: Context) {

    private val selector: MediaRouteSelector = MediaRouteSelector.Builder()
        .addControlCategory(CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
        .build()

    /** Null se il dispositivo non ha i servizi Google (es. Fire Stick). */
    private val castContext: CastContext? by lazy {
        val available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS
        if (!available) null else runCatching { CastContext.getSharedInstance(context) }.getOrNull()
    }

    val isAvailable: Boolean get() = castContext != null

    /** Cerca i dispositivi Cast per [timeoutMs] millisecondi. */
    suspend fun scan(timeoutMs: Long): List<MediaRouter.RouteInfo> {
        if (castContext == null) return emptyList()
        val router = MediaRouter.getInstance(context)
        val callback = object : MediaRouter.Callback() {}
        router.addCallback(selector, callback, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN)
        try {
            delay(timeoutMs)
        } finally {
            router.removeCallback(callback)
        }
        return router.routes.filter { !it.isDefault && it.isEnabled && it.matchesSelector(selector) }
    }

    /** Si collega al dispositivo (se serve) e avvia lo stream HLS in diretta. */
    suspend fun load(route: MediaRouter.RouteInfo, title: String, hlsUrl: String) {
        val ctx = castContext ?: throw IOException("Google Cast non disponibile su questo dispositivo")
        val sessionManager = ctx.sessionManager
        val router = MediaRouter.getInstance(context)
        val current = sessionManager.currentCastSession
        val session = if (current != null && current.isConnected && router.selectedRoute.id == route.id) {
            current
        } else {
            withTimeout(25_000L) { connect(route, sessionManager, router) }
        }
        val client = session.remoteMediaClient ?: throw IOException("il dispositivo Cast non è pronto")
        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, title)
            putString(MediaMetadata.KEY_SUBTITLE, "Sguardone")
        }
        val info = MediaInfo.Builder(hlsUrl)
            .setStreamType(MediaInfo.STREAM_TYPE_LIVE)
            .setContentType("application/x-mpegURL")
            .setMetadata(metadata)
            .build()
        client.load(MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build())
    }

    private suspend fun connect(
        route: MediaRouter.RouteInfo,
        sessionManager: SessionManager,
        router: MediaRouter,
    ): CastSession = suspendCancellableCoroutine { cont ->
        val listener = object : SessionManagerListener<CastSession> {
            private fun done() = sessionManager.removeSessionManagerListener(this, CastSession::class.java)

            override fun onSessionStarted(session: CastSession, sessionId: String) {
                done()
                if (cont.isActive) cont.resume(session)
            }

            override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
                done()
                if (cont.isActive) cont.resume(session)
            }

            override fun onSessionStartFailed(session: CastSession, error: Int) {
                done()
                if (cont.isActive) cont.resumeWithException(IOException("collegamento alla TV non riuscito (codice $error)"))
            }

            override fun onSessionStarting(session: CastSession) = Unit
            override fun onSessionEnding(session: CastSession) = Unit
            override fun onSessionEnded(session: CastSession, error: Int) = Unit
            override fun onSessionResuming(session: CastSession, sessionId: String) = Unit
            override fun onSessionResumeFailed(session: CastSession, error: Int) = Unit
            override fun onSessionSuspended(session: CastSession, reason: Int) = Unit
        }
        sessionManager.addSessionManagerListener(listener, CastSession::class.java)
        cont.invokeOnCancellation { sessionManager.removeSessionManagerListener(listener, CastSession::class.java) }
        router.selectRoute(route)
    }

    /** Chiude la sessione Cast e ferma la riproduzione sulla TV. */
    fun end() {
        castContext?.sessionManager?.endCurrentSession(true)
    }
}
