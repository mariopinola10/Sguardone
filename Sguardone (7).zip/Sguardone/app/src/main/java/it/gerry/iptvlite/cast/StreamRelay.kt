package it.gerry.iptvlite.cast

import android.util.Base64
import it.gerry.iptvlite.App
import it.gerry.iptvlite.config.ConfigServer
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Repository
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Ponte tra la VPN e la TV: un piccolo server HTTP in rete locale.
 * La TV chiede lo stream al telefono/Fire Stick, che lo scarica dal fornitore DENTRO il tunnel
 * e lo inoltra. Gli stream HLS vengono convertiti in un flusso MPEG-TS continuo
 * (concatenando i segmenti), il formato che quasi tutte le TV DLNA leggono.
 */
class StreamRelay(private val app: App) {

    companion object {
        private const val BUFFER_BYTES = 16 * 1024 * 1024
        private const val PREBUFFER_BYTES = 3 * 1024 * 1024
        private const val PREBUFFER_MAX_WAIT_MS = 10_000L

        /** Diretta in streaming, senza salti: OP=00 (no seek), flag "streaming" come i server DLNA comuni. */
        const val DLNA_FEATURES = "DLNA.ORG_OP=00;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000"
    }

    private var server: ServerSocket? = null
    @Volatile private var running = false
    @Volatile private var current: Pair<String, Channel>? = null
    @Volatile private var currentHls: String? = null

    /** Client senza timeout di lettura totale: gli stream in diretta non finiscono mai. */
    private val client: OkHttpClient = app.http.newBuilder()
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    var port = 0
        private set

    fun start() {
        for (p in 8091..8099) {
            try {
                server = ServerSocket(p)
                port = p
                break
            } catch (e: IOException) {
            }
        }
        val s = server ?: throw IOException("nessuna porta libera per la trasmissione")
        running = true
        thread(name = "cast-relay", isDaemon = true) {
            while (running) {
                val incoming = try {
                    s.accept()
                } catch (e: IOException) {
                    break
                }
                thread(isDaemon = true) { runCatching { handle(incoming) } }
            }
        }
    }

    fun stop() {
        running = false
        current = null
        runCatching { server?.close() }
        server = null
    }

    /** Pubblica il canale per DLNA (flusso MPEG-TS continuo) e restituisce l'indirizzo da dare alla TV. */
    fun publish(ch: Channel): String {
        val ip = ConfigServer.localIp() ?: throw IOException("il dispositivo non è collegato alla rete di casa")
        val token = UUID.randomUUID().toString().replace("-", "").take(16)
        current = token to ch
        currentHls = null
        return "http://$ip:$port/live/$token.ts"
    }

    /**
     * Pubblica il canale per Google Cast come HLS "riscritto": playlist e segmenti passano tutti
     * dal ponte (quindi dalla VPN). Null se il canale non ha una versione HLS.
     */
    fun publishHls(ch: Channel): String? {
        val hls = hlsUrlFor(ch.url) ?: return null
        val ip = ConfigServer.localIp() ?: throw IOException("il dispositivo non è collegato alla rete di casa")
        val token = UUID.randomUUID().toString().replace("-", "").take(16)
        current = token to ch
        currentHls = hls
        return "http://$ip:$port/hls/$token/index.m3u8"
    }

    /** Link HLS del canale: .m3u8 diretto, oppure la versione .m3u8 dei link Xtream .ts / senza estensione. */
    private fun hlsUrlFor(url: String): String? {
        val base = url.substringBefore('?')
        if (base.endsWith(".m3u8", ignoreCase = true)) return url
        Regex("^(.*/live/[^/]+/[^/]+/\\d+)\\.ts$", RegexOption.IGNORE_CASE).find(base)?.let {
            return it.groupValues[1] + ".m3u8"
        }
        Regex("^(https?://[^/]+)/([^/]+)/([^/]+)/(\\d+)$").find(base)?.let { m ->
            return "${m.groupValues[1]}/live/${m.groupValues[2]}/${m.groupValues[3]}/${m.groupValues[4]}.m3u8"
        }
        return null
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 30_000
            val input = BufferedInputStream(s.getInputStream())
            val requestLine = readLine(input) ?: return
            while (true) {
                val line = readLine(input) ?: return
                if (line.isEmpty()) break
            }
            val parts = requestLine.split(' ')
            val method = parts.getOrElse(0) { "" }
            val path = parts.getOrElse(1) { "/" }
            val out = s.getOutputStream()

            if (path.startsWith("/hls/")) {
                handleHls(method, path, out)
                return
            }

            val token = path.substringAfter("/live/", "").substringBefore('.')
            val entry = current
            if (entry == null || entry.first != token) return respondError(out, 404, "Not Found")
            if (!app.vpn.isUp) return respondError(out, 503, "VPN non attiva")

            // Diretta non spostabile: niente Range (Accept-Ranges: none, DLNA.ORG_OP=00).
            // Una richiesta di salto della TV riceve comunque lo stream dal punto attuale, senza chiudere.
            out.write(
                ("HTTP/1.1 200 OK\r\n" +
                    "Content-Type: video/mp2t\r\n" +
                    "Connection: close\r\n" +
                    "Cache-Control: no-cache\r\n" +
                    "Accept-Ranges: none\r\n" +
                    "transferMode.dlna.org: Streaming\r\n" +
                    "contentFeatures.dlna.org: $DLNA_FEATURES\r\n" +
                    "\r\n").toByteArray(Charsets.ISO_8859_1)
            )
            out.flush()
            if (method == "HEAD") return

            val ch = entry.second
            streamBuffered(ch, out) { current?.first == token }
        }
    }

    /**
     * Buffer tra fornitore e TV: un thread scarica (nel tunnel) e riempie un buffer da 16 MB,
     * questo thread invia alla TV. La TV riceve dati solo quando c'è una riserva iniziale
     * (circa 3 MB o 10 s di attesa massima): assorbe i rallentamenti del fornitore.
     */
    private fun streamBuffered(ch: Channel, tv: OutputStream, stillWanted: () -> Boolean) {
        val pipeIn = PipedInputStream(BUFFER_BYTES)
        val pipeOut = PipedOutputStream(pipeIn)
        val producer = thread(name = "cast-download", isDaemon = true) {
            try {
                if (ch.url.contains(".m3u8", ignoreCase = true)) pipeHls(ch, pipeOut, stillWanted)
                else pipeDirect(ch, pipeOut)
            } catch (e: Exception) {
                // fine dello stream o TV scollegata
            } finally {
                runCatching { pipeOut.close() }
            }
        }
        try {
            val deadline = System.currentTimeMillis() + PREBUFFER_MAX_WAIT_MS
            while (pipeIn.available() < PREBUFFER_BYTES && producer.isAlive && System.currentTimeMillis() < deadline) {
                Thread.sleep(200)
            }
            val buffer = ByteArray(64 * 1024)
            while (running && stillWanted()) {
                val n = pipeIn.read(buffer)
                if (n < 0) break
                tv.write(buffer, 0, n)
            }
            tv.flush()
        } finally {
            runCatching { pipeIn.close() }   // ferma anche il download se la TV si è scollegata
        }
    }

    private fun request(url: String, ch: Channel): Request = Request.Builder()
        .url(url)
        .header("User-Agent", ch.userAgent ?: Repository.DEFAULT_UA)
        .apply { ch.referer?.let { header("Referer", it) } }
        .build()

    /** Stream continuo (es. .ts): copia byte per byte finché la TV resta collegata. */
    private fun pipeDirect(ch: Channel, out: OutputStream) {
        client.newCall(request(ch.url, ch)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body ?: throw IOException("risposta vuota")
            copy(body.byteStream(), out)
        }
    }

    /**
     * HLS -> MPEG-TS: legge la playlist (sceglie la qualità migliore), scarica i segmenti nuovi
     * in ordine e li scrive uno dopo l'altro. Supporta segmenti TS non cifrati.
     */
    private fun pipeHls(ch: Channel, out: OutputStream, stillWanted: () -> Boolean) {
        var mediaUrl = ch.url
        var lastSequence = -1L
        var first = true
        while (running && stillWanted()) {
            if (!app.vpn.isUp) throw IOException("VPN non attiva")
            val text = fetchText(mediaUrl, ch)
            if (text.contains("#EXT-X-STREAM-INF")) {
                mediaUrl = bestVariant(mediaUrl, text) ?: throw IOException("playlist HLS senza varianti")
                continue
            }
            if (text.contains("#EXT-X-MAP")) throw IOException("stream HLS in formato fMP4: non trasmissibile via DLNA")
            if (Regex("#EXT-X-KEY:METHOD=(?!NONE)").containsMatchIn(text)) throw IOException("stream HLS cifrato: non trasmissibile")

            val sequenceStart = Regex("#EXT-X-MEDIA-SEQUENCE:(\\d+)").find(text)?.groupValues?.get(1)?.toLong() ?: 0L
            val target = Regex("#EXT-X-TARGETDURATION:(\\d+)").find(text)?.groupValues?.get(1)?.toLong() ?: 6L
            val segments = text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
            // Alla prima lettura parte dagli ultimi 3 segmenti: vicino alla diretta, con un po' di margine.
            val startIndex = if (first) (segments.size - 3).coerceAtLeast(0) else 0
            first = false

            for ((i, segment) in segments.withIndex()) {
                val sequence = sequenceStart + i
                if (i < startIndex || sequence <= lastSequence) continue
                if (!stillWanted()) return
                val segmentUrl = URL(URL(mediaUrl), segment).toString()
                client.newCall(request(segmentUrl, ch)).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("segmento HLS: HTTP ${r.code}")
                    r.body?.byteStream()?.let { copy(it, out) }
                }
                lastSequence = sequence
            }
            if (text.contains("#EXT-X-ENDLIST")) return
            Thread.sleep((target * 1000L / 2).coerceAtLeast(1_000L))
        }
    }

    private fun fetchText(url: String, ch: Channel): String =
        client.newCall(request(url, ch)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("playlist HLS: HTTP ${r.code}")
            r.body?.string() ?: ""
        }

    /**
     * Sceglie la variante di una master playlist. Le TV via DLNA ricevono un solo flusso TS:
     * servono varianti con audio e video INSIEME. Se la playlist ha l'audio in una traccia separata
     * (#EXT-X-MEDIA TYPE=AUDIO con URI) uso solo le varianti senza gruppo audio esterno; se non ce ne
     * sono, lo segnalo invece di mandare video muto.
     */
    private fun bestVariant(baseUrl: String, text: String): String? {
        val lines = text.lines().map { it.trim() }
        // Gruppi audio che hanno un file separato (URI=...): l'audio NON è dentro i segmenti video.
        val externalAudioGroups = lines
            .filter { it.startsWith("#EXT-X-MEDIA") && it.contains("TYPE=AUDIO") && it.contains("URI=") }
            .mapNotNull { Regex("GROUP-ID=\"([^\"]+)\"").find(it)?.groupValues?.get(1) }
            .toSet()

        var best: String? = null
        var bestBandwidth = -1L
        var skippedForAudio = 0
        for ((i, line) in lines.withIndex()) {
            if (!line.startsWith("#EXT-X-STREAM-INF")) continue
            val audioGroup = Regex("AUDIO=\"([^\"]+)\"").find(line)?.groupValues?.get(1)
            if (audioGroup != null && audioGroup in externalAudioGroups) {
                skippedForAudio++
                continue
            }
            // Varianti solo-audio o con codec video non TS: le ignoro.
            val codecs = Regex("CODECS=\"([^\"]+)\"").find(line)?.groupValues?.get(1).orEmpty()
            if (codecs.isNotEmpty() && !codecs.contains("avc1") && !codecs.contains("hvc1") &&
                !codecs.contains("hev1") && !codecs.contains("mp4v")
            ) continue
            val bandwidth = Regex("BANDWIDTH=(\\d+)").find(line)?.groupValues?.get(1)?.toLong() ?: 0L
            val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: continue
            if (bandwidth > bestBandwidth) {
                bestBandwidth = bandwidth
                best = URL(URL(baseUrl), uri).toString()
            }
        }
        if (best == null && skippedForAudio > 0) {
            throw IOException("questo canale ha l'audio separato dal video: via DLNA la TV riceverebbe solo le immagini")
        }
        return best
    }

    private fun copy(input: InputStream, out: OutputStream) {
        val buffer = ByteArray(64 * 1024)
        while (running) {
            if (!app.vpn.isUp) throw IOException("VPN non attiva")
            val n = input.read(buffer)
            if (n < 0) break
            out.write(buffer, 0, n)
        }
        out.flush()
    }

    // ---------- HLS per Google Cast ----------

    private fun handleHls(method: String, path: String, out: OutputStream) {
        if (method == "OPTIONS") return respondRaw(out, "204 No Content", "text/plain", ByteArray(0))
        val token = path.removePrefix("/hls/").substringBefore('/')
        val entry = current
        val hls = currentHls
        if (entry == null || entry.first != token || hls == null) {
            return respondRaw(out, "404 Not Found", "text/plain", ByteArray(0))
        }
        if (!app.vpn.isUp) return respondRaw(out, "503 Service Unavailable", "text/plain", ByteArray(0))
        val ch = entry.second
        val rest = path.substringAfter("/hls/$token")
        val isIndex = rest.startsWith("/index.m3u8")
        val target = if (isIndex) hls else decodeUrl(rest.substringAfter("u=", ""))
            ?: return respondRaw(out, "404 Not Found", "text/plain", ByteArray(0))

        client.newCall(request(target, ch)).execute().use { r ->
            if (!r.isSuccessful) return respondRaw(out, "502 Bad Gateway", "text/plain", ByteArray(0))
            val body = r.body ?: return respondRaw(out, "502 Bad Gateway", "text/plain", ByteArray(0))
            val type = r.header("Content-Type").orEmpty()
            val finalUrl = r.request.url.toString()   // dopo eventuali redirect: base per i link relativi
            val playlist = isIndex || type.contains("mpegurl", ignoreCase = true) ||
                finalUrl.substringBefore('?').endsWith(".m3u8", ignoreCase = true)
            if (method == "HEAD") {
                return writeHead(out, "200 OK", if (playlist) "application/vnd.apple.mpegurl" else type.ifEmpty { "video/mp2t" }, -1)
            }
            if (playlist) {
                val text = rewritePlaylist(body.string(), finalUrl, token)
                respondRaw(out, "200 OK", "application/vnd.apple.mpegurl", text.toByteArray(Charsets.UTF_8))
            } else {
                writeHead(out, "200 OK", type.ifEmpty { "video/mp2t" }, body.contentLength())
                copy(body.byteStream(), out)
            }
        }
    }

    /** Ogni link della playlist (segmenti, varianti, audio, chiavi) diventa un link al ponte. */
    private fun rewritePlaylist(text: String, baseUrl: String, token: String): String {
        val uriAttr = Regex("URI=\"([^\"]+)\"")
        return text.lines().joinToString("\n") { line ->
            val t = line.trim()
            when {
                t.isEmpty() -> line
                t.startsWith("#") -> uriAttr.replace(t) { m -> "URI=\"" + proxied(URL(URL(baseUrl), m.groupValues[1]).toString(), token) + "\"" }
                else -> proxied(URL(URL(baseUrl), t).toString(), token)
            }
        }
    }

    private fun proxied(absoluteUrl: String, token: String): String =
        "/hls/$token/p?u=" + Base64.encodeToString(
            absoluteUrl.toByteArray(Charsets.UTF_8),
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING,
        )

    private fun decodeUrl(encoded: String): String? = runCatching {
        String(Base64.decode(encoded, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING), Charsets.UTF_8)
    }.getOrNull()?.takeIf { it.startsWith("http://") || it.startsWith("https://") }

    /** Intestazioni con CORS: il lettore Cast (pagina web) altrimenti rifiuta i dati. */
    private fun writeHead(out: OutputStream, status: String, type: String, length: Long) {
        val head = StringBuilder()
            .append("HTTP/1.1 ").append(status).append("\r\n")
            .append("Content-Type: ").append(type).append("\r\n")
            .append("Access-Control-Allow-Origin: *\r\n")
            .append("Access-Control-Allow-Headers: *\r\n")
            .append("Access-Control-Allow-Methods: GET, HEAD, OPTIONS\r\n")
            .append("Cache-Control: no-cache\r\n")
            .append("Connection: close\r\n")
        if (length >= 0) head.append("Content-Length: ").append(length).append("\r\n")
        head.append("\r\n")
        out.write(head.toString().toByteArray(Charsets.ISO_8859_1))
        out.flush()
    }

    private fun respondRaw(out: OutputStream, status: String, type: String, body: ByteArray) {
        writeHead(out, status, type, body.size.toLong())
        out.write(body)
        out.flush()
    }

    private fun respondError(out: OutputStream, code: Int, text: String) {
        out.write("HTTP/1.1 $code $text\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
        out.flush()
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = input.read()
            if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
        return null
    }
}
