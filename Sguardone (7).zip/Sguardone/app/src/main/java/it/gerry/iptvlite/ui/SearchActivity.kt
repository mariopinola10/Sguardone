package it.gerry.iptvlite.ui

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Programme
import it.gerry.iptvlite.data.ProgrammeHit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Ricerca in canali e guida EPG (titolo e descrizione dei programmi, finestra di 48 ore).
 * - Risultati: canali, poi programmi in onda, poi quelli futuri in ordine di orario.
 * - Programma in onda: OK/tocco lo guarda. Programma futuro: promemoria nell'app o calendario (telefono).
 * - Ricerche salvate ("★ Napoli"): un tocco per ripeterle; appaiono anche "in evidenza" nella guida.
 */
class SearchActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_QUERY = "query"

        fun start(context: Context, query: String? = null) {
            context.startActivity(Intent(context, SearchActivity::class.java).putExtra(EXTRA_QUERY, query))
        }
    }

    private sealed interface Row {
        data class ChannelRow(val channel: Channel, val now: Programme?) : Row
        data class ProgrammeRow(val hit: ProgrammeHit, val reminder: Boolean) : Row
    }

    private val app by lazy { application as App }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var field: EditText
    private lateinit var info: TextView
    private lateinit var results: RecyclerView
    private lateinit var resultsAdapter: RowAdapter<Row>
    private lateinit var chipAdapter: ChipAdapter

    private var searchJob: Job? = null
    private var pending: Runnable? = null
    private var lastQuery = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        field = findViewById(R.id.searchField)
        info = findViewById(R.id.searchInfo)
        results = findViewById(R.id.results)

        resultsAdapter = RowAdapter(
            title = ::rowTitle,
            subtitle = ::rowSubtitle,
            onClick = { row, _ -> onRowClick(row) },
            onLongClick = { row, _ -> if (row is Row.ProgrammeRow) toggleReminder(row) },
        )
        results.layoutManager = LinearLayoutManager(this)
        results.adapter = resultsAdapter
        results.itemAnimator = null

        chipAdapter = ChipAdapter(
            onClick = { term ->
                field.setText(term)
                field.setSelection(term.length)
                search(term, focusResults = true)
            },
            onLongClick = { term ->
                app.prefs.savedSearches = app.prefs.savedSearches - term
                refreshChips()
                toast("Ricerca \"$term\" eliminata")
            },
        )
        findViewById<RecyclerView>(R.id.chips).apply {
            layoutManager = LinearLayoutManager(this@SearchActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = chipAdapter
        }
        refreshChips()

        findViewById<Button>(R.id.saveSearchButton).setOnClickListener {
            val term = field.text.toString().trim()
            if (term.length < 2) return@setOnClickListener toast("Scrivi almeno 2 caratteri da salvare")
            app.prefs.savedSearches = listOf(term) + app.prefs.savedSearches
            refreshChips()
            toast("Salvata: \"$term\" comparirà in evidenza nella guida")
        }

        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                pending?.let { handler.removeCallbacks(it) }
                val q = s?.toString().orEmpty()
                pending = Runnable { search(q, focusResults = false) }.also { handler.postDelayed(it, 400) }
            }
        })
        field.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                pending?.let { handler.removeCallbacks(it) }
                search(field.text.toString(), focusResults = true)
                true
            } else {
                false
            }
        }

        val initial = intent.getStringExtra(EXTRA_QUERY)
        if (!initial.isNullOrBlank()) {
            field.setText(initial)
            field.setSelection(initial.length)
            search(initial, focusResults = true)
        } else {
            info.text = "Scrivi almeno 2 caratteri. La guida copre le prossime 48 ore."
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    // ---------- Ricerca ----------

    private fun search(raw: String, focusResults: Boolean) {
        val q = raw.trim()
        if (q.length < 2) {
            lastQuery = ""
            resultsAdapter.items = emptyList()
            info.text = "Scrivi almeno 2 caratteri. La guida copre le prossime 48 ore."
            return
        }
        lastQuery = q
        searchJob?.cancel()
        searchJob = lifecycleScope.launch {
            info.text = "Cerco \"$q\"…"
            val rows = withContext(Dispatchers.IO) {
                val channels = app.repo.searchChannels(q).map { Row.ChannelRow(it, app.repo.nowPlaying(it.epgKey)) }
                val programmes = app.repo.searchProgrammes(q).map {
                    Row.ProgrammeRow(it, app.repo.hasReminder(it.channel.name, it.programme.start))
                }
                channels + programmes
            }
            if (q != lastQuery) return@launch
            resultsAdapter.items = rows
            val nCh = rows.count { it is Row.ChannelRow }
            val nPr = rows.size - nCh
            val onAir = rows.count { it is Row.ProgrammeRow && it.hit.programme.start <= System.currentTimeMillis() }
            info.text = when {
                rows.isEmpty() -> "Nessun risultato per \"$q\" nelle prossime 48 ore."
                else -> "$nCh canali · $nPr programmi ($onAir in onda). " +
                    "OK guarda · tieni premuto su un programma per il promemoria"
            }
            if (focusResults && rows.isNotEmpty()) {
                hideKeyboard()
                results.post {
                    results.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() ?: results.requestFocus()
                }
            }
        }
    }

    private fun rowTitle(row: Row): String = when (row) {
        is Row.ChannelRow -> "Canale  ·  ${row.channel.name}"
        is Row.ProgrammeRow -> {
            val p = row.hit.programme
            val whenText = if (p.start <= System.currentTimeMillis()) "● IN ONDA" else Format.day(p.start)
            "$whenText   ${p.title}"
        }
    }

    private fun rowSubtitle(row: Row): String? = when (row) {
        is Row.ChannelRow -> row.now?.let { "In onda: ${it.title}" }
        is Row.ProgrammeRow -> {
            val p = row.hit.programme
            "${row.hit.channel.name}  ·  ${Format.range(p)}" + if (row.reminder) "  ·  ⏰ promemoria" else ""
        }
    }

    // ---------- Azioni ----------

    private fun onRowClick(row: Row) {
        when (row) {
            is Row.ChannelRow -> PlayerActivity.startByName(this, row.channel.name)
            is Row.ProgrammeRow -> {
                val p = row.hit.programme
                if (p.start <= System.currentTimeMillis()) {
                    PlayerActivity.startByName(this, row.hit.channel.name)
                } else {
                    showFutureOptions(row)
                }
            }
        }
    }

    /** Programma futuro: promemoria nell'app, calendario (solo telefono/tablet) o canale subito. */
    private fun showFutureOptions(row: Row.ProgrammeRow) {
        val p = row.hit.programme
        val ch = row.hit.channel
        val options = ArrayList<Pair<String, () -> Unit>>()
        options.add(
            (if (row.reminder) "Togli il promemoria" else "⏰ Promemoria nell'app") to { toggleReminder(row) }
        )
        if (!Device.isTv(this)) options.add("📅 Aggiungi al calendario" to { addToCalendar(ch, p) })
        options.add("Guarda ${ch.name} adesso" to { PlayerActivity.startByName(this, ch.name) })

        AlertDialog.Builder(this)
            .setTitle(p.title)
            .setItems(options.map { it.first }.toTypedArray()) { _, which -> options[which].second() }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun toggleReminder(row: Row.ProgrammeRow) {
        val p = row.hit.programme
        val ch = row.hit.channel.name
        if (p.stop <= System.currentTimeMillis()) return
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                if (row.reminder) app.repo.removeReminder(ch, p.start) else app.repo.addReminder(ch, p)
            }
            toast(
                if (row.reminder) "Promemoria tolto"
                else "⏰ Ti avviso all'inizio (${Format.day(p.start)}) se Sguardone è aperto"
            )
            search(lastQuery, focusResults = false)
        }
    }

    private fun addToCalendar(ch: Channel, p: Programme) {
        val intent = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, p.start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, p.stop)
            .putExtra(CalendarContract.Events.TITLE, p.title)
            .putExtra(CalendarContract.Events.DESCRIPTION, "Su ${ch.name} — Sguardone")
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast("Nessuna app calendario disponibile")
        }
    }

    // ---------- Varie ----------

    private fun refreshChips() {
        val saved = app.prefs.savedSearches
        chipAdapter.items = saved
        findViewById<RecyclerView>(R.id.chips).visibility =
            if (saved.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun hideKeyboard() {
        val imm = getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(field.windowToken, 0)
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
}
