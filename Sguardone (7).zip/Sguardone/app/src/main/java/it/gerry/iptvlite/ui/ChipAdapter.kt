package it.gerry.iptvlite.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.R

/** Ricerche salvate come "chip" orizzontali: OK/tocco = cerca, tieni premuto = elimina. */
class ChipAdapter(
    private val onClick: (String) -> Unit,
    private val onLongClick: (String) -> Unit,
) : RecyclerView.Adapter<ChipAdapter.Holder>() {

    class Holder(val text: TextView) : RecyclerView.ViewHolder(text)

    var items: List<String> = emptyList()
        @SuppressLint("NotifyDataSetChanged")
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_chip, parent, false) as TextView)

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val term = items[position]
        holder.text.text = "★ $term"
        holder.text.setOnClickListener { onClick(term) }
        holder.text.setOnLongClickListener {
            onLongClick(term)
            true
        }
    }
}
