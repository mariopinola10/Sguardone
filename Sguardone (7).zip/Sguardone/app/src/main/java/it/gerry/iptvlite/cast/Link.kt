package it.gerry.iptvlite.cast

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import it.gerry.iptvlite.App
import it.gerry.iptvlite.ui.PlayerActivity
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import kotlin.concurrent.thread

/** Un altro dispositivo con Sguardone aperto (es. il Fire Stick), trovato in rete locale. */
data class Peer(val name: String, val host: String, val port: Int)

/**
 * "Trasmetti a Sguardone": il telefono non invia lo stream, invia solo il NOME del canale.
 * Il Fire Stick lo apre con le sue liste e la sua VPN Mullvad. Funziona solo in rete locale.
 *
 * Ricerca: broadcast UDP "SGUARDONE?" sulla porta [DISCOVERY_PORT], risposta "SGUARDONE 1 <porta> <nome>".
 * Comandi: GET /play?name=…  ·  GET /stop
 */
object Link {

    const val DISCOVERY_PORT = 41900
    private const val ASK = "SGUARDONE?"
    private const val REPLY = "SGUARDONE 1 "

    /** Cerca altri Sguardone aperti in rete per [timeoutMs]. Fuori dal thread principale. */
    fun discover(context: Context, timeoutMs: Long = 2_500L): List<Peer> {
        val own = ownAddresses()
        val found = LinkedHashMap<String, Peer>()
        val lock = multicastLock(context)
        try {
            DatagramSocket(null).use { socket ->
                socket.reuseAddress = true
                socket.broadcast = true
                socket.soTimeout = 300
                socket.bind(InetSocketAddress(0))
                val msg = ASK.toByteArray()
                val targets = (broadcastAddresses() + InetAddress.getByName("255.255.255.255")).distinct()
                repeat(2) {
                    for (t in targets) runCatching { socket.send(DatagramPacket(msg, msg.size, t, DISCOVERY_PORT)) }
                }
                val buffer = ByteArray(512)
                val end = System.currentTimeMillis() + timeoutMs
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buffer, buffer.size)
                        socket.receive(p)
                        val from = p.address
                        val host = from.hostAddress ?: continue
                        if (host in own || !(from.isSiteLocalAddress || from.isLinkLocalAddress)) continue
                        val text = String(p.data, 0, p.length, Charsets.UTF_8)
                        if (!text.startsWith(REPLY)) continue
                        val rest = text.removePrefix(REPLY)
                        val port = rest.substringBefore(' ').toIntOrNull() ?: continue
                        val name = rest.substringAfter(' ', "").ifBlank { "Sguardone" }
                        found[host] = Peer(name, host, port)
                    } catch (e: SocketTimeoutException) {
                        // continua fino allo scadere
                    }
                }
            }
        } finally {
            lock?.release()
        }
        return found.values.toList()
    }

    /** Chiede al dispositivo di aprire il canale. Errore con il messaggio del dispositivo se non riesce. */
    fun play(peer: Peer, channelName: String) {
        request(peer, "/play?name=" + URLEncoder.encode(channelName, "UTF-8"))
    }

    fun stop(peer: Peer) {
        request(peer, "/stop")
    }

    private fun request(peer: Peer, path: String) {
        val address = InetAddress.getByName(peer.host)
        if (!(address.isSiteLocalAddress || address.isLinkLocalAddress)) throw IOException("indirizzo fuori dalla rete locale")
        val conn = (URL("http://${peer.host}:${peer.port}$path").openConnection() as HttpURLConnection).apply {
            connectTimeout = 4_000
            readTimeout = 6_000
            useCaches = false
        }
        try {
            val code = conn.responseCode
            if (code != 200) {
                val msg = runCatching { conn.errorStream?.bufferedReader()?.readText() }.getOrNull()
                throw IOException(msg?.takeIf { it.isNotBlank() } ?: "il dispositivo ha risposto $code")
            }
            conn.inputStream.close()
        } finally {
            conn.disconnect()
        }
    }

    internal fun multicastLock(context: Context): WifiManager.MulticastLock? =
        runCatching {
            context.applicationContext.getSystemService(WifiManager::class.java)
                ?.createMulticastLock("sguardone-link")
                ?.apply { setReferenceCounted(false); acquire() }
        }.getOrNull()

    private fun interfaces() = runCatching { NetworkInterface.getNetworkInterfaces()?.toList().orEmpty() }
        .getOrDefault(emptyList())
        .filter { runCatching { it.isUp && !it.isLoopback && !it.name.startsWith("tun") }.getOrDefault(false) }

    private fun broadcastAddresses(): List<InetAddress> =
        interfaces().flatMap { it.interfaceAddresses }.mapNotNull { it.broadcast }

    private fun ownAddresses(): Set<String> =
        interfaces().flatMap { it.inetAddresses.toList() }.filterIsInstance<Inet4Address>().mapNotNull { it.hostAddress }.toSet()
}

/**
 * Ricevitore attivo sul dispositivo mentre Sguardone è aperto in primo piano:
 * risponde alla ricerca e apre i canali richiesti dal telefono.
 */
class LinkReceiver(private val app: App) {

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var udp: DatagramSocket? = null
    private var http: ServerSocket? = null
    private var lock: WifiManager.MulticastLock? = null

    fun start() {
        if (running) return
        running = true
        val server = (41901..41905).firstNotNullOfOrNull { p -> runCatching { ServerSocket(p) }.getOrNull() }
        if (server == null) {
            running = false
            return
        }
        http = server
        lock = Link.multicastLock(app)
        thread(name = "link-http", isDaemon = true) {
            while (running) {
                val client = try { server.accept() } catch (e: IOException) { break }
                thread(isDaemon = true) { runCatching { handle(client) } }
            }
        }
        thread(name = "link-udp", isDaemon = true) {
            val socket = runCatching {
                DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                    bind(InetSocketAddress(Link.DISCOVERY_PORT))
                }
            }.getOrNull() ?: return@thread
            udp = socket
            val buffer = ByteArray(256)
            while (running) {
                try {
                    val p = DatagramPacket(buffer, buffer.size)
                    socket.receive(p)
                    val from = p.address
                    if (!(from.isSiteLocalAddress || from.isLinkLocalAddress)) continue
                    if (String(p.data, 0, p.length, Charsets.UTF_8).trim() != "SGUARDONE?") continue
                    val reply = "SGUARDONE 1 ${server.localPort} ${deviceName()}".toByteArray(Charsets.UTF_8)
                    socket.send(DatagramPacket(reply, reply.size, from, p.port))
                } catch (e: IOException) {
                    if (!running) break
                }
            }
        }
    }

    fun stop() {
        running = false
        runCatching { udp?.close() }
        runCatching { http?.close() }
        udp = null
        http = null
        runCatching { lock?.release() }
        lock = null
    }

    private fun deviceName(): String {
        val custom = runCatching { Settings.Global.getString(app.contentResolver, "device_name") }.getOrNull()
        val base = custom?.takeIf { it.isNotBlank() } ?: Build.MODEL ?: "TV"
        return "Sguardone · $base"
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 10_000
            val remote = s.inetAddress
            val out = s.getOutputStream()
            fun respond(code: Int, body: String) {
                val bytes = body.toByteArray(Charsets.UTF_8)
                val head = "HTTP/1.1 $code ${if (code == 200) "OK" else "Error"}\r\n" +
                    "Content-Type: text/plain; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n"
                out.write(head.toByteArray(Charsets.ISO_8859_1))
                out.write(bytes)
                out.flush()
            }
            if (!(remote.isSiteLocalAddress || remote.isLinkLocalAddress)) return respond(403, "Solo rete locale")
            val input = BufferedInputStream(s.getInputStream())
            val line = readLine(input) ?: return
            while (true) {
                val h = readLine(input) ?: break
                if (h.isEmpty()) break
            }
            val target = line.split(' ').getOrElse(1) { "/" }
            val path = target.substringBefore('?')
            val query = target.substringAfter('?', "").split('&').filter { it.contains('=') }.associate {
                URLDecoder.decode(it.substringBefore('='), "UTF-8") to URLDecoder.decode(it.substringAfter('='), "UTF-8")
            }
            when (path) {
                "/play" -> {
                    val name = query["name"].orEmpty().trim()
                    if (name.isEmpty()) return respond(400, "Canale mancante")
                    if (!app.prefs.isConfigured || !app.repo.hasChannels()) {
                        return respond(409, "Sguardone su ${deviceName()} non è ancora configurato")
                    }
                    if (!app.vpn.isUp) {
                        return respond(409, "La VPN del Fire Stick non è ancora attiva: attendi qualche secondo e riprova")
                    }
                    val ch = app.repo.findForRemote(name)
                        ?: return respond(404, "«$name» non è nelle liste del Fire Stick")
                    main.post {
                        Toast.makeText(app, "📺 Dal telefono: ${ch.name}", Toast.LENGTH_SHORT).show()
                        PlayerActivity.startRemote(app, ch.name)
                    }
                    respond(200, "OK")
                }
                "/stop" -> {
                    main.post { (app.foregroundActivity() as? PlayerActivity)?.finish() }
                    respond(200, "OK")
                }
                else -> respond(404, "Non trovato")
            }
        }
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 4096) {
            val b = input.read()
            if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
        return null
    }
}
