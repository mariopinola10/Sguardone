package it.gerry.iptvlite.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.crypto.Key
import com.wireguard.crypto.KeyPair
import it.gerry.iptvlite.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Tunnel WireGuard verso Mullvad, limitato al traffico di questa sola app.
 *
 * Kill-switch applicativo: il player e i download partono solo con stato [State.Up].
 * Se il tunnel cade, lo stato passa a [State.Error] e la riproduzione viene fermata.
 */
/**
 * Tutto Internet nel tunnel, tranne la rete di casa (10/8, 172.16/12, 192.168/16) e il multicast:
 * servono per la pagina di configurazione dal telefono e per trasmettere alla TV (DLNA).
 * 10.64.0.1 (DNS Mullvad) resta nel tunnel. È la lista "escludi IP privati" di WireGuard.
 */
private const val ALLOWED_IPS =
    "0.0.0.0/5, 8.0.0.0/7, 11.0.0.0/8, 12.0.0.0/6, 16.0.0.0/4, 32.0.0.0/3, 64.0.0.0/2, 128.0.0.0/3, " +
        "160.0.0.0/5, 168.0.0.0/6, 172.0.0.0/12, 172.32.0.0/11, 172.64.0.0/10, 172.128.0.0/9, " +
        "173.0.0.0/8, 174.0.0.0/7, 176.0.0.0/4, 192.0.0.0/9, 192.128.0.0/11, 192.160.0.0/13, " +
        "192.169.0.0/16, 192.170.0.0/15, 192.172.0.0/14, 192.176.0.0/12, 192.192.0.0/10, 193.0.0.0/8, " +
        "194.0.0.0/7, 196.0.0.0/6, 200.0.0.0/5, 208.0.0.0/4, 10.64.0.1/32, ::/0"

class VpnManager(
    context: Context,
    private val prefs: Prefs,
    private val http: OkHttpClient,
) {
    sealed interface State {
        data object Down : State
        data object Connecting : State
        data class Up(val relay: String) : State
        data class Error(val message: String) : State
    }

    private val ctx = context.applicationContext
    private val api = MullvadApi(http)
    private val backend: GoBackend by lazy { GoBackend(ctx) }
    private val mutex = Mutex()

    private val _state = MutableStateFlow<State>(State.Down)
    val state: StateFlow<State> = _state.asStateFlow()
    val isUp: Boolean get() = _state.value is State.Up

    private val tunnel = object : Tunnel {
        override fun getName(): String = "iptvlite"
        override fun onStateChange(newState: Tunnel.State) {
            if (newState != Tunnel.State.UP && _state.value is State.Up) {
                _state.value = State.Error("Tunnel VPN interrotto")
            }
        }
    }

    /** Intent del consenso VPN di sistema, oppure null se già concesso. */
    fun permissionIntent(): Intent? = VpnService.prepare(ctx)

    suspend fun connect() {
        mutex.withLock { connectLocked() }
    }

    /**
     * Collegamento con tentativi automatici, dal più veloce al più "aggressivo":
     * 1) server preferito, porta 51820   2) stesso server, porta 53 (quasi mai bloccata)
     * 3) chiave registrata di nuovo sull'account (se era stata rimossa), poi altro server su 51820 e 53.
     */
    private suspend fun connectLocked() {
        withContext<Unit>(Dispatchers.IO) {
            if (isUp) return@withContext
            _state.value = State.Connecting
            try {
                ensureKey()
                val relays = pickRelays()
                val first = relays.first()
                val second = relays.getOrElse(1) { first }
                val attempts = listOf(first to 51820, first to 53, second to 51820, second to 53)

                var noResponse = true
                var keyNote = ""
                var lastError = ""
                for ((i, attempt) in attempts.withIndex()) {
                    val (relay, port) = attempt
                    if (i == 2) {
                        // Dopo due tentativi falliti: la chiave potrebbe essere stata tolta dall'account.
                        runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
                        http.connectionPool.evictAll()
                        keyNote = refreshKeyRegistration()
                    }
                    try {
                        backend.setState(tunnel, Tunnel.State.UP, buildConfig(relay, port))
                        // Chiude le connessioni aperte prima del tunnel, così tutto il resto passa da Mullvad.
                        http.connectionPool.evictAll()
                        delay(1_000L)   // tempo per l'handshake WireGuard
                        verifyThroughMullvad()
                        prefs.relayHost = relay.hostname
                        _state.value = State.Up(if (port == 51820) relay.hostname else "${relay.hostname} :$port")
                        return@withContext
                    } catch (e: Exception) {
                        lastError = e.message ?: e.javaClass.simpleName
                        val rx = runCatching { backend.getStatistics(tunnel).totalRx() }.getOrDefault(0L)
                        if (rx > 0) noResponse = false
                    }
                }
                throw IOException(diagnosis(noResponse, keyNote, lastError))
            } catch (e: Exception) {
                runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
                _state.value = State.Error(e.message ?: e.javaClass.simpleName)
                throw e
            }
        }
    }

    private fun diagnosis(noResponse: Boolean, keyNote: String, lastError: String): String = buildString {
        append("Connessione a Mullvad non riuscita. ")
        if (noResponse) {
            append(
                "Nessuna risposta dai server: la rete probabilmente blocca WireGuard (UDP) " +
                    "oppure la chiave non è più valida sull'account. Prova un'altra rete (es. Wi-Fi) " +
                    "e controlla i dispositivi sul sito Mullvad (max 5). "
            )
        } else {
            append("Il server risponde ma il traffico non passa: prova \"Cambia server VPN\" nelle impostazioni. ")
        }
        if (keyNote.isNotEmpty()) append(keyNote).append(' ')
        append("(Dettaglio: ").append(lastError.take(120)).append(')')
    }

    /**
     * Registra di nuovo la chiave pubblica attuale sull'account (tunnel spento, connessione diretta a Mullvad).
     * Se la chiave era stata rimossa, torna valida e gli indirizzi del tunnel vengono aggiornati.
     */
    private fun refreshKeyRegistration(): String = try {
        val publicKey = KeyPair(Key.fromBase64(prefs.wgPrivateKey)).publicKey.toBase64()
        prefs.wgAddresses = api.registerKey(prefs.mullvadAccount, publicKey)
        ""
    } catch (e: Exception) {
        "Rinnovo della chiave non riuscito: ${e.message?.take(100)}."
    }

    suspend fun disconnect() {
        mutex.withLock {
            withContext<Unit>(Dispatchers.IO) {
                _state.value = State.Down
                runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
                http.connectionPool.evictAll()
            }
        }
    }

    /** Elimina la chiave locale: alla prossima connessione ne viene registrata una nuova. */
    fun resetKey() {
        prefs.wgPrivateKey = ""
        prefs.wgAddresses = ""
    }

    private fun ensureKey() {
        if (prefs.wgPrivateKey.isNotEmpty() && prefs.wgAddresses.isNotEmpty()) return
        val keyPair = KeyPair()
        val addresses = api.registerKey(prefs.mullvadAccount, keyPair.publicKey.toBase64())
        prefs.wgPrivateKey = keyPair.privateKey.toBase64()
        prefs.wgAddresses = addresses
    }

    /** Server candidati: il preferito (ultimo usato) per primo, poi altri dello stesso paese in ordine casuale. */
    private fun pickRelays(): List<Relay> {
        val all = api.relays()
        if (all.isEmpty()) throw IOException("Nessun server Mullvad disponibile")
        val sameCountry = all.filter { it.country.equals(prefs.country, ignoreCase = true) }
        val candidates = sameCountry.ifEmpty { all }
        val avoid = prefs.avoidRelay
        val pool = candidates.filter { it.hostname != avoid }.ifEmpty { candidates }.shuffled()
        prefs.avoidRelay = ""
        val preferred = pool.firstOrNull { it.hostname == prefs.relayHost }
        return if (preferred != null) listOf(preferred) + (pool - preferred) else pool
    }

    private fun buildConfig(relay: Relay, port: Int): Config {
        val iface = Interface.Builder()
            .parsePrivateKey(prefs.wgPrivateKey)
            .parseAddresses(prefs.wgAddresses)
            .parseDnsServers("10.64.0.1")            // DNS Mullvad interno al tunnel
            .includeApplication(ctx.packageName)     // solo il traffico di questa app
            .build()
        val peer = Peer.Builder()
            .parsePublicKey(relay.publicKey)
            .parseEndpoint("${relay.ipv4}:$port")
            .parseAllowedIPs(ALLOWED_IPS)
            .parsePersistentKeepalive("25")
            .build()
        return Config.Builder().setInterface(iface).addPeer(peer).build()
    }

    /** Verifica reale: chiede a Mullvad se la richiesta arriva dal tunnel. */
    private suspend fun verifyThroughMullvad() {
        val client = http.newBuilder().callTimeout(5, TimeUnit.SECONDS).build()
        val request = Request.Builder().url("https://am.i.mullvad.net/connected").build()
        var last = ""
        repeat(3) {
            try {
                last = client.newCall(request).execute().use { it.body?.string()?.trim().orEmpty() }
                if (last.startsWith("You are connected", ignoreCase = true)) return
            } catch (e: IOException) {
                last = e.message ?: "timeout"
            }
            delay(1_000L)
        }
        throw IOException(last)
    }
}
