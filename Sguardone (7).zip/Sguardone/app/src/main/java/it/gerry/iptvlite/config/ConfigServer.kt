package it.gerry.iptvlite.config

import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import kotlin.concurrent.thread

/**
 * Mini server HTTP in rete locale, attivo solo mentre le impostazioni sono aperte.
 * Dal telefono si apre http://IP-FIRESTICK:PORTA, si inserisce il PIN mostrato in TV
 * e si inviano account Mullvad, link M3U/EPG oppure un file M3U.
 */
class ConfigServer(
    private val pin: String,
    private val uploadDir: File,
    /** Riceve il file caricato (temporaneo). Restituisce un errore o null. Chiamato sul thread del server. */
    private val onUpload: (File) -> String?,
    /** Riceve i campi del form. Restituisce un errore o null. Chiamato sul thread del server. */
    private val onConfig: (Map<String, String>) -> String?,
    /** Configurazione attuale in JSON (senza password), per precompilare la pagina. */
    private val onCurrent: () -> String = { "{}" },
) {
    private var server: ServerSocket? = null
    @Volatile private var running = false

    var port: Int = 0
        private set

    fun start(): Int {
        for (p in 8080..8090) {
            try {
                server = ServerSocket(p)
                port = p
                break
            } catch (e: IOException) {
            }
        }
        val s = server ?: throw IOException("Nessuna porta libera per il server di configurazione")
        running = true
        thread(name = "config-server", isDaemon = true) {
            while (running) {
                val client = try {
                    s.accept()
                } catch (e: IOException) {
                    break
                }
                thread(isDaemon = true) { runCatching { handle(client) } }
            }
        }
        return port
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        server = null
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 60_000
            val input = BufferedInputStream(s.getInputStream(), 64 * 1024)
            val out = s.getOutputStream()

            val requestLine = readLine(input) ?: return
            val headers = HashMap<String, String>()
            while (true) {
                val line = readLine(input) ?: return
                if (line.isEmpty()) break
                val i = line.indexOf(':')
                if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
            }

            val parts = requestLine.split(' ')
            val method = parts.getOrElse(0) { "" }
            val target = parts.getOrElse(1) { "/" }
            val path = target.substringBefore('?')
            val query = parseForm(target.substringAfter('?', ""))
            val length = headers["content-length"]?.toLongOrNull() ?: 0L

            when {
                method == "GET" && (path == "/" || path == "/index.html") ->
                    respond(out, 200, "text/html; charset=utf-8", PAGE)

                method == "GET" && path == "/current" -> {
                    if (query["pin"] != pin) return respond(out, 403, TEXT, "PIN errato")
                    respond(out, 200, "application/json; charset=utf-8", onCurrent())
                }

                method == "POST" && path == "/upload" -> {
                    if (query["pin"] != pin) return respond(out, 403, TEXT, "PIN errato")
                    if (length <= 0 || length > MAX_UPLOAD) return respond(out, 400, TEXT, "File vuoto o troppo grande (max 200 MB)")
                    val tmp = File(uploadDir, "upload.tmp")
                    tmp.outputStream().use { copyExactly(input, it, length) }
                    val error = onUpload(tmp)
                    if (error == null) respond(out, 200, TEXT, "File ricevuto") else respond(out, 400, TEXT, error)
                }

                method == "POST" && path == "/config" -> {
                    if (length <= 0 || length > 64 * 1024) return respond(out, 400, TEXT, "Richiesta non valida")
                    val body = ByteArray(length.toInt())
                    readFully(input, body)
                    val form = parseForm(String(body, Charsets.UTF_8))
                    if (form["pin"] != pin) return respond(out, 403, TEXT, "PIN errato")
                    val error = onConfig(form)
                    if (error == null) respond(out, 200, TEXT, "Configurazione salvata. Puoi tornare alla TV.")
                    else respond(out, 400, TEXT, error)
                }

                else -> respond(out, 404, TEXT, "Non trovato")
            }
        }
    }

    private fun respond(out: OutputStream, code: Int, type: String, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val status = when (code) {
            200 -> "OK"; 400 -> "Bad Request"; 403 -> "Forbidden"; else -> "Not Found"
        }
        val head = "HTTP/1.1 $code $status\r\n" +
            "Content-Type: $type\r\n" +
            "Content-Length: ${bytes.size}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        out.write(bytes)
        out.flush()
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = input.read()
            if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
        return null
    }

    private fun copyExactly(input: InputStream, out: OutputStream, length: Long) {
        val buffer = ByteArray(64 * 1024)
        var remaining = length
        while (remaining > 0) {
            val n = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            if (n == -1) throw IOException("Caricamento interrotto")
            out.write(buffer, 0, n)
            remaining -= n
        }
    }

    private fun readFully(input: InputStream, buffer: ByteArray) {
        var off = 0
        while (off < buffer.size) {
            val n = input.read(buffer, off, buffer.size - off)
            if (n == -1) throw IOException("Richiesta incompleta")
            off += n
        }
    }

    private fun parseForm(s: String): Map<String, String> =
        s.split('&').filter { it.isNotEmpty() }.associate { pair ->
            val k = pair.substringBefore('=')
            val v = pair.substringAfter('=', "")
            URLDecoder.decode(k, "UTF-8") to URLDecoder.decode(v, "UTF-8")
        }

    companion object {
        private const val TEXT = "text/plain; charset=utf-8"
        private const val MAX_UPLOAD = 200L * 1024 * 1024

        /** IP del Fire Stick in rete locale (Wi-Fi o Ethernet), escluso il tunnel VPN. */
        /** Stringa JSON con escape. */
        fun json(s: String): String {
            val sb = StringBuilder("\"")
            for (c in s) when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c < ' ' -> sb.append(String.format(java.util.Locale.ROOT, "\\u%04x", c.code))
                else -> sb.append(c)
            }
            return sb.append('"').toString()
        }

        fun localIp(): String? = runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
                .filter { it.isUp && !it.isLoopback && !it.name.startsWith("tun") }
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }
                ?.hostAddress
        }.getOrNull()

        private val PAGE = """
<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sguardone - Configurazione</title>
<style>
 body{font-family:system-ui,sans-serif;background:#0f1318;color:#fff;margin:0;padding:20px;max-width:560px}
 h1{font-size:22px;margin:0 0 4px} h2{font-size:16px;margin:24px 0 8px;color:#7fa7ff}
 label{display:block;margin:10px 0 4px;color:#9aa4ae;font-size:14px}
 textarea{width:100%;box-sizing:border-box;padding:12px;border-radius:8px;border:1px solid #2a3440;background:#18202a;color:#fff;font-size:15px}
 input{width:100%;box-sizing:border-box;padding:12px;border-radius:8px;border:1px solid #2a3440;background:#18202a;color:#fff;font-size:16px}
 button{margin-top:24px;width:100%;padding:14px;border:0;border-radius:8px;background:#2f6feb;color:#fff;font-size:17px;font-weight:600}
 .hint{color:#9aa4ae;font-size:13px} #msg{margin-top:16px;font-size:15px}
</style>
</head>
<body>
<h1>Sguardone</h1>
<p class="hint" id="top">Inserisci il PIN: i dati già salvati sul Fire Stick compaiono qui sotto. Le password non vengono mai mostrate.</p>

<label for="pin">PIN mostrato sulla TV</label>
<input id="pin" inputmode="numeric" maxlength="4" autocomplete="off">
<div id="state" class="hint"></div>

<h2>Mullvad</h2>
<label for="account">Numero account (16 cifre)</label>
<input id="account" inputmode="numeric" autocomplete="off">
<div class="hint">Vuoto = mantieni quello salvato<span id="accInfo"></span></div>
<label for="country">Paese dei server (it, ch, de, nl…)</label>
<input id="country" maxlength="2" autocapitalize="none">

<h2>Lista canali</h2>
<label for="m3u">Link M3U (uno per riga, max 10)</label>
<textarea id="m3u" rows="4" placeholder="https://…/lista1.m3u&#10;https://…/lista2.m3u" autocapitalize="none"></textarea>
<label id="localBox" style="display:none"><input id="keepLocal" type="checkbox" checked style="width:auto"> Usa il file M3U già caricato sul Fire Stick <span id="localInfo"></span></label>
<label for="file">…e/o un file M3U dal telefono (si aggiunge alle liste)</label>
<input id="file" type="file">

<h2>Account Xtream</h2>
<div id="xlist"></div>
<label for="xserver">Aggiungi: server (https://…)</label>
<input id="xserver" type="url" placeholder="https://provider.tv:443" autocapitalize="none">
<label for="xuser">Utente</label>
<input id="xuser" autocapitalize="none" autocomplete="off">
<label for="xpass">Password</label>
<input id="xpass" type="password" autocomplete="off">
<label><input id="xhls" type="checkbox" checked style="width:auto"> Stream HLS (m3u8)</label>

<h2>Guida EPG (facoltativa)</h2>
<label for="epg">Link XMLTV (separati da virgola)</label>
<input id="epg" type="url" placeholder="https://…/guida.xml.gz" autocapitalize="none">

<h2>Qualità</h2>
<label for="quality">Qualità predefinita quando un canale ne ha più di una</label>
<select id="quality" style="width:100%;padding:12px;border-radius:8px;background:#18202a;color:#fff;border:1px solid #2a3440;font-size:16px">
 <option value="1">SD / LQ (più leggera)</option>
 <option value="2">HD</option>
 <option value="3">Full HD</option>
 <option value="4">4K</option>
</select>

<h2>Voti film e serie (TMDB)</h2>
<label for="tmdb">Chiave API TMDB (themoviedb.org → Impostazioni → API)</label>
<input id="tmdb" autocapitalize="none" autocomplete="off" spellcheck="false">
<div class="hint">Vuoto = mantieni quella salvata<span id="tmdbInfo"></span></div>

<button id="send">Invia alla TV</button>
<div id="msg"></div>

<script>
var g = function (id) { return document.getElementById(id); };
var loaded = false;
async function loadCurrent() {
  var pin = g('pin').value.trim();
  if (pin.length !== 4) return;
  g('state').textContent = 'Leggo i dati dal Fire Stick…';
  try {
    var r = await fetch('/current?pin=' + encodeURIComponent(pin));
    if (!r.ok) { g('state').textContent = 'PIN errato'; return; }
    var c = await r.json();
    g('m3u').value = (c.m3u || []).join('\n');
    g('epg').value = c.epg || '';
    g('country').value = c.country || '';
    g('accInfo').textContent = c.account ? ' (' + c.account + ')' : ' (nessuno)';
    if (c.localFile) { g('localBox').style.display = 'block'; g('keepLocal').checked = !!c.localUsed; g('localInfo').textContent = '(' + c.localFile + ')'; }
    if (c.quality) g('quality').value = String(c.quality);
    g('tmdbInfo').textContent = c.tmdb ? ' (' + c.tmdb + ')' : ' (nessuna)';
    var xl = g('xlist'); xl.innerHTML = '';
    (c.xtream || []).forEach(function (x, i) {
      var l = document.createElement('label');
      l.innerHTML = '<input type="checkbox" class="xdel" value="' + i + '" style="width:auto"> Rimuovi ';
      l.appendChild(document.createTextNode(x));
      xl.appendChild(l);
    });
    if (!(c.xtream || []).length) xl.innerHTML = '<div class="hint">Nessun account Xtream salvato</div>';
    loaded = true;
    g('state').textContent = '✓ Dati del Fire Stick caricati';
  } catch (e) { g('state').textContent = 'Impossibile leggere i dati: ' + e.message; }
}
g('pin').oninput = loadCurrent;
g('send').onclick = async function () {
  var msg = g('msg');
  var pin = g('pin').value.trim();
  if (pin.length !== 4) { msg.textContent = 'Inserisci il PIN di 4 cifre mostrato sulla TV'; return; }
  try {
    var local = loaded ? (g('keepLocal').checked && g('localBox').style.display !== 'none' ? '1' : '0') : '';
    var f = g('file').files[0];
    if (f) {
      msg.textContent = 'Carico il file (' + Math.round(f.size / 1024) + ' KB)…';
      var up = await fetch('/upload?pin=' + encodeURIComponent(pin), { method: 'POST', body: f });
      if (!up.ok) throw new Error(await up.text());
      local = '1';
    }
    var del = [];
    document.querySelectorAll('.xdel').forEach(function (b) { if (b.checked) del.push(b.value); });
    msg.textContent = 'Invio la configurazione…';
    var body = new URLSearchParams({
      pin: pin, account: g('account').value, country: g('country').value,
      m3u: g('m3u').value, epg: g('epg').value, local: local, prefilled: loaded ? '1' : '0',
      xserver: g('xserver').value, xuser: g('xuser').value, xpass: g('xpass').value,
      xhls: g('xhls').checked ? '1' : '0', xremove: del.join(','), quality: g('quality').value, tmdb: g('tmdb').value
    });
    var r = await fetch('/config', { method: 'POST', body: body });
    var t = await r.text();
    if (!r.ok) throw new Error(t);
    msg.textContent = '✓ ' + t;
  } catch (e) {
    msg.textContent = 'Errore: ' + e.message;
  }
};
</script>
</body>
</html>
""".trimIndent()
    }
}
