package it.gerry.iptvlite.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import it.gerry.iptvlite.App
import it.gerry.iptvlite.update.Updater
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Pulsante "Aggiorna": controlla GitHub, scarica, verifica e apre l'installazione di sistema. */
object UpdateUi {

    private const val SILENT_EVERY_MS = 6 * 3_600_000L

    /**
     * Controllo silenzioso (all'avvio, al massimo ogni 6 ore): se c'è una versione più nuova
     * chiama [onAvailable] con il nome della versione.
     */
    fun checkSilently(activity: ComponentActivity, onAvailable: (String) -> Unit) {
        val app = activity.application as App
        val now = System.currentTimeMillis()
        val cached = app.prefs.updateAvailableName
        val updater = Updater(activity, app.http)
        if (cached.isNotEmpty() && app.prefs.updateAvailableCode > updater.installedCode) onAvailable(cached)
        if (now - app.prefs.lastUpdateCheck < SILENT_EVERY_MS) return
        activity.lifecycleScope.launch {
            val info = withContext(Dispatchers.IO) { runCatching { updater.latest() }.getOrNull() } ?: return@launch
            app.prefs.lastUpdateCheck = now
            if (updater.isNewer(info)) {
                app.prefs.updateAvailableName = info.versionName
                app.prefs.updateAvailableCode = info.versionCode
                onAvailable(info.versionName)
            } else {
                app.prefs.updateAvailableName = ""
            }
        }
    }

    /** Controllo manuale con messaggi: se c'è una versione nuova chiede conferma, scarica e installa. */
    fun checkAndInstall(activity: ComponentActivity) {
        val app = activity.application as App
        val updater = Updater(activity, app.http)
        val dialog = AlertDialog.Builder(activity)
            .setTitle("Aggiornamento")
            .setMessage("Controllo l'ultima versione su GitHub…")
            .setCancelable(true)
            .show()
        activity.lifecycleScope.launch {
            val info = try {
                withContext(Dispatchers.IO) { updater.latest() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                dialog.setMessage("Controllo non riuscito: ${e.message}")
                return@launch
            }
            app.prefs.lastUpdateCheck = System.currentTimeMillis()
            if (!updater.isNewer(info)) {
                app.prefs.updateAvailableName = ""
                dialog.setMessage("Hai già l'ultima versione (${app.versionName}).")
                return@launch
            }
            dialog.dismiss()
            AlertDialog.Builder(activity)
                .setTitle("Nuova versione ${info.versionName}")
                .setMessage("Installata: ${app.versionName}\nScarico e installo l'aggiornamento? Le impostazioni e i preferiti restano.")
                .setPositiveButton("Aggiorna") { _, _ -> download(activity, updater, info) }
                .setNegativeButton("Più tardi", null)
                .show()
        }
    }

    private fun download(activity: ComponentActivity, updater: Updater, info: Updater.Info) {
        val progress = AlertDialog.Builder(activity)
            .setTitle("Aggiornamento ${info.versionName}")
            .setMessage("Scarico…")
            .setCancelable(false)
            .show()
        activity.lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    updater.download(info) { pct ->
                        activity.runOnUiThread {
                            progress.setMessage(if (pct >= 0) "Scarico… $pct%" else "Scarico…")
                        }
                    }
                }
                progress.dismiss()
                install(activity, file)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                progress.dismiss()
                AlertDialog.Builder(activity)
                    .setTitle("Aggiornamento non riuscito")
                    .setMessage(e.message ?: "errore sconosciuto")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    /** Apre l'installer di sistema. Se manca il permesso "installa app sconosciute" lo chiede prima. */
    private fun install(activity: Activity, file: File) {
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(activity)
                .setTitle("Serve un permesso")
                .setMessage(
                    "Per installare l'aggiornamento consenti a Sguardone di installare app.\n\n" +
                        "Si apre l'impostazione: attiva Sguardone, torna indietro e premi di nuovo Aggiorna " +
                        "(il file è già scaricato).\n\n" +
                        "Su Fire TV, se non si apre: Impostazioni → La mia Fire TV → Opzioni sviluppatore → " +
                        "Installa app sconosciute → Sguardone."
                )
                .setPositiveButton("Apri impostazione") { _, _ ->
                    try {
                        activity.startActivity(
                            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
                        )
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(activity, "Apri a mano: Impostazioni → La mia Fire TV → Opzioni sviluppatore → Installa app sconosciute", Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton("Annulla", null)
                .show()
            return
        }
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.updates", file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            activity.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(activity, "Installer di sistema non disponibile", Toast.LENGTH_LONG).show()
        }
    }
}
