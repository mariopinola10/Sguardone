package it.gerry.iptvlite.data

/**
 * Nomi dei canali: normalizzazione per gli abbinamenti e numerazione "come in TV".
 * Numeri del digitale terrestre: LCN nazionale (aggiornamento di agosto 2026).
 */
object ChannelNames {

    private val brackets = Regex("""\([^)]*\)|\[[^\]]*\]""")
    private val separators = Regex("""[|:_./\\-]+""")
    private val diacritics = Regex("\\p{Mn}+")
    private val digits = Regex("\\d+")

    private val COUNTRY_PREFIX = setOf("it", "ita", "itl")
    private val QUALITY = setOf(
        "hd", "fhd", "uhd", "sd", "4k", "8k", "hevc", "h265", "h264", "1080", "1080p", "720", "720p",
        "50fps", "60fps", "backup", "bk", "raw", "vip", "multi", "multiaudio",
        "lq", "hq", "fullhd", "2160", "2160p", "1080i", "576", "576p", "480", "480p",
    )
    private val NUMBERS = mapOf(
        "uno" to "1", "due" to "2", "tre" to "3", "quattro" to "4", "cinque" to "5",
        "sei" to "6", "sette" to "7", "otto" to "8", "nove" to "9", "dieci" to "10",
    )

    /**
     * "IT: Sky Sport Uno FHD (backup)" -> "skysport1", "Rai 1 HD" -> "rai1", "ZONA DAZN 2 HEVC" -> "zonadazn2".
     * Toglie prefissi paese, parentesi, accenti, separatori e parole di qualità; "uno/due…" diventano numeri.
     */
    fun norm(s: String): String {
        val plain = java.text.Normalizer.normalize(s.lowercase().replace("full hd", "fhd"), java.text.Normalizer.Form.NFD)
            .replace(diacritics, "")
            .replace(brackets, " ")
            .replace(separators, " ")
        var tokens = plain.split(' ').map { it.trim() }.filter { it.isNotEmpty() }
        if (tokens.size > 1 && tokens.first() in COUNTRY_PREFIX) tokens = tokens.drop(1)
        return tokens
            .filter { it !in QUALITY }
            .map { NUMBERS[it] ?: it }
            .joinToString("")
            .filter { it.isLetterOrDigit() || it == '+' }
    }

    private val wordSplit = Regex("[^a-z0-9]+")

    /** Qualità dichiarata nel nome: 4 = 4K/UHD, 3 = Full HD, 2 = HD, 1 = SD/LQ o non indicata. */
    fun quality(name: String): Int {
        val t = name.lowercase().split(wordSplit).toSet()
        return when {
            t.any { it in Q4 } -> 4
            t.any { it in Q3 } || ("full" in t && "hd" in t) -> 3
            t.any { it in Q2 } -> 2
            else -> 1
        }
    }

    fun qualityLabel(q: Int): String = when (q) {
        4 -> "4K"; 3 -> "Full HD"; 2 -> "HD"; else -> "SD"
    }

    private val Q4 = setOf("4k", "uhd", "2160", "2160p", "8k")
    private val Q3 = setOf("fhd", "fullhd", "1080", "1080p", "1080i")
    private val Q2 = setOf("hd", "hq", "720", "720p")

    /** Numeri ufficiali del digitale terrestre (chiave = nome normalizzato). */
    private val LCN: Map<String, Int> = mapOf(
        "rai1" to 1, "rai2" to 2, "rai3" to 3, "rai3tgr" to 3, "rete4" to 4, "canale5" to 5,
        "italia1" to 6, "la7" to 7, "tv8" to 8, "9" to 9,
        "20mediaset" to 20, "mediaset20" to 20, "20" to 20, "rai4" to 21, "iris" to 22, "rai5" to 23,
        "raimovie" to 24, "raipremium" to 25, "cielo" to 26, "27twentyseven" to 27, "twentyseven" to 27,
        "tv2000" to 28, "la7cinema" to 29, "la7d" to 29, "la5" to 30, "realtime" to 31, "qvc" to 32,
        "foodnetwork" to 33, "cine34" to 34, "focus" to 35, "rtl1025" to 36, "rtl102.5" to 36,
        "discovery" to 37, "giallo" to 38, "topcrime" to 39, "boing" to 40, "k2" to 41,
        "raigulp" to 42, "raiyoyo" to 43, "frisbee" to 44, "boingplus" to 45, "cartoonito" to 46,
        "super" to 47, "super!" to 47, "rainews24" to 48, "mediasetitalia2" to 49, "italia2" to 49,
        "skytg24" to 50, "tgcom24" to 51, "dmax" to 52, "italia53" to 53, "raistoria" to 54,
        "mediasetextra" to 55, "hgtv" to 56, "hgtvhomegarden" to 56, "raiscuola" to 57,
        "raisport" to 58, "discoveryturbo" to 59, "motortrend" to 59, "sportitalia" to 60, "il61" to 61,
        "ilsole24oretv" to 63, "supertennis" to 64, "radio105" to 66, "r101tv" to 67,
        "deejaytv" to 69, "radioitaliatv" to 70,
    )

    /** Ordine dei canali Sky nel blocco 101+: intrattenimento, sport, cinema. */
    private val SKY_ORDER = listOf(
        "skyuno", "skyatlantic", "skyserie", "skyinvestigation", "skycollection", "skycrime",
        "skydocumentaries", "skynature", "skyadventure", "skyarte", "skykids", "skytg24",
        "skysport24", "skysport1", "skysportcalcio", "skysporttennis", "skysportarena", "skysportbasket",
        "skysportmax", "skysportf1", "skysportmotogp", "skysportgolf", "skysportlegend", "skysportmix",
        "skysport", "skycinema1", "skycinema2", "skycinemacollection", "skycinemafamily", "skycinemaaction",
        "skycinemasuspense", "skycinemaromance", "skycinemadrama", "skycinemacomedy", "skycinema",
    )

    fun lcn(key: String): Int? = LCN[key]

    fun isSky(key: String) = key.startsWith("sky")

    fun isDazn(key: String) = key.contains("dazn")

    /** Chiave per l'ordinamento "naturale": "DAZN 2" prima di "DAZN 10". */
    fun naturalKey(name: String): String = digits.replace(norm(name)) { it.value.padStart(5, '0') }

    fun skyRank(key: String): Int = SKY_ORDER.indexOfFirst { key.startsWith(it) }.let { if (it < 0) SKY_ORDER.size else it }
}
