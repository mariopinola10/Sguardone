package it.gerry.iptvlite.cast

import it.gerry.iptvlite.App
import it.gerry.iptvlite.config.ConfigServer
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Repository
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Ponte tra la VPN e la TV: un piccolo server HTTP in rete locale.
 * La TV chiede lo stream al telefono/Fire Stick, che lo scarica dal fornitore DENTRO il tunnel
 * e lo inoltra. Gli stream HLS vengono convertiti in un flusso MPEG-TS continuo
 * (concatenando i segmenti), il formato che quasi tutte le TV DLNA leggono.
 */
class StreamRelay(private val app: App) {

    private var server: ServerSocket? = null
    @Volatile private var running = false
    @Volatile private var current: Pair<String, Channel>? = null

    /** Client senza timeout di lettura totale: gli stream in diretta non finiscono mai. */
    private val client: OkHttpClient = app.http.newBuilder()
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    var port = 0
        private set

    fun start() {
        for (p in 8091..8099) {
            try {
                server = ServerSocket(p)
                port = p
                break
            } catch (e: IOException) {
            }
        }
        val s = server ?: throw IOException("nessuna porta libera per la trasmissione")
        running = true
        thread(name = "cast-relay", isDaemon = true) {
            while (running) {
                val incoming = try {
                    s.accept()
                } catch (e: IOException) {
                    break
                }
                thread(isDaemon = true) { runCatching { handle(incoming) } }
            }
        }
    }

    fun stop() {
        running = false
        current = null
        runCatching { server?.close() }
        server = null
    }

    /** Pubblica il canale e restituisce l'indirizzo da dare alla TV. */
    fun publish(ch: Channel): String {
        val ip = ConfigServer.localIp() ?: throw IOException("il dispositivo non è collegato alla rete di casa")
        val token = UUID.randomUUID().toString().replace("-", "").take(16)
        current = token to ch
        return "http://$ip:$port/live/$token.ts"
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 30_000
            val input = BufferedInputStream(s.getInputStream())
            val requestLine = readLine(input) ?: return
            while (true) {
                val line = readLine(input) ?: return
                if (line.isEmpty()) break
            }
            val parts = requestLine.split(' ')
            val method = parts.getOrElse(0) { "" }
            val path = parts.getOrElse(1) { "/" }
            val out = s.getOutputStream()

            val token = path.substringAfter("/live/", "").substringBefore('.')
            val entry = current
            if (entry == null || entry.first != token) return respondError(out, 404, "Not Found")
            if (!app.vpn.isUp) return respondError(out, 503, "VPN non attiva")

            out.write(
                ("HTTP/1.1 200 OK\r\n" +
                    "Content-Type: video/mp2t\r\n" +
                    "Connection: close\r\n" +
                    "Cache-Control: no-cache\r\n" +
                    "transferMode.dlna.org: Streaming\r\n" +
                    "contentFeatures.dlna.org: DLNA.ORG_OP=00;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000\r\n" +
                    "\r\n").toByteArray(Charsets.ISO_8859_1)
            )
            out.flush()
            if (method == "HEAD") return

            val ch = entry.second
            if (ch.url.contains(".m3u8", ignoreCase = true)) {
                pipeHls(ch, out) { current?.first == token }
            } else {
                pipeDirect(ch, out)
            }
        }
    }

    private fun request(url: String, ch: Channel): Request = Request.Builder()
        .url(url)
        .header("User-Agent", ch.userAgent ?: Repository.DEFAULT_UA)
        .apply { ch.referer?.let { header("Referer", it) } }
        .build()

    /** Stream continuo (es. .ts): copia byte per byte finché la TV resta collegata. */
    private fun pipeDirect(ch: Channel, out: OutputStream) {
        client.newCall(request(ch.url, ch)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body ?: throw IOException("risposta vuota")
            copy(body.byteStream(), out)
        }
    }

    /**
     * HLS -> MPEG-TS: legge la playlist (sceglie la qualità migliore), scarica i segmenti nuovi
     * in ordine e li scrive uno dopo l'altro. Supporta segmenti TS non cifrati.
     */
    private fun pipeHls(ch: Channel, out: OutputStream, stillWanted: () -> Boolean) {
        var mediaUrl = ch.url
        var lastSequence = -1L
        var first = true
        while (running && stillWanted()) {
            if (!app.vpn.isUp) throw IOException("VPN non attiva")
            val text = fetchText(mediaUrl, ch)
            if (text.contains("#EXT-X-STREAM-INF")) {
                mediaUrl = bestVariant(mediaUrl, text) ?: throw IOException("playlist HLS senza varianti")
                continue
            }
            if (text.contains("#EXT-X-MAP")) throw IOException("stream HLS in formato fMP4: non trasmissibile via DLNA")
            if (Regex("#EXT-X-KEY:METHOD=(?!NONE)").containsMatchIn(text)) throw IOException("stream HLS cifrato: non trasmissibile")

            val sequenceStart = Regex("#EXT-X-MEDIA-SEQUENCE:(\\d+)").find(text)?.groupValues?.get(1)?.toLong() ?: 0L
            val target = Regex("#EXT-X-TARGETDURATION:(\\d+)").find(text)?.groupValues?.get(1)?.toLong() ?: 6L
            val segments = text.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
            // Alla prima lettura parte dagli ultimi 3 segmenti: vicino alla diretta, con un po' di margine.
            val startIndex = if (first) (segments.size - 3).coerceAtLeast(0) else 0
            first = false

            for ((i, segment) in segments.withIndex()) {
                val sequence = sequenceStart + i
                if (i < startIndex || sequence <= lastSequence) continue
                if (!stillWanted()) return
                val segmentUrl = URL(URL(mediaUrl), segment).toString()
                client.newCall(request(segmentUrl, ch)).execute().use { r ->
                    if (!r.isSuccessful) throw IOException("segmento HLS: HTTP ${r.code}")
                    r.body?.byteStream()?.let { copy(it, out) }
                }
                lastSequence = sequence
            }
            if (text.contains("#EXT-X-ENDLIST")) return
            Thread.sleep((target * 1000L / 2).coerceAtLeast(1_000L))
        }
    }

    private fun fetchText(url: String, ch: Channel): String =
        client.newCall(request(url, ch)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("playlist HLS: HTTP ${r.code}")
            r.body?.string() ?: ""
        }

    /** Variante con banda più alta di una master playlist. */
    private fun bestVariant(baseUrl: String, text: String): String? {
        val lines = text.lines().map { it.trim() }
        var best: String? = null
        var bestBandwidth = -1L
        for ((i, line) in lines.withIndex()) {
            if (!line.startsWith("#EXT-X-STREAM-INF")) continue
            val bandwidth = Regex("BANDWIDTH=(\\d+)").find(line)?.groupValues?.get(1)?.toLong() ?: 0L
            val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: continue
            if (bandwidth > bestBandwidth) {
                bestBandwidth = bandwidth
                best = URL(URL(baseUrl), uri).toString()
            }
        }
        return best
    }

    private fun copy(input: InputStream, out: OutputStream) {
        val buffer = ByteArray(64 * 1024)
        while (running) {
            if (!app.vpn.isUp) throw IOException("VPN non attiva")
            val n = input.read(buffer)
            if (n < 0) break
            out.write(buffer, 0, n)
        }
        out.flush()
    }

    private fun respondError(out: OutputStream, code: Int, text: String) {
        out.write("HTTP/1.1 $code $text\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
        out.flush()
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = input.read()
            if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
        return null
    }
}
