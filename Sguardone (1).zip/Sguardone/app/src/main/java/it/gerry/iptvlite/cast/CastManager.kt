package it.gerry.iptvlite.cast

import it.gerry.iptvlite.App
import it.gerry.iptvlite.data.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.IOException

/** Trasmissione DLNA: ricerca dispositivi, avvio, cambio canale e stop. */
class CastManager(private val app: App) {

    sealed interface State {
        data object Idle : State
        data class Casting(val device: String, val channel: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()
    val isCasting: Boolean get() = _state.value is State.Casting

    private var relay: StreamRelay? = null
    private var renderer: Renderer? = null

    suspend fun discover(): List<Renderer> = withContext(Dispatchers.IO) { Dlna.discover(app) }

    /** Trasmette il canale sul dispositivo scelto (o su quello attuale se [target] è null). */
    suspend fun cast(ch: Channel, target: Renderer? = null) = withContext<Unit>(Dispatchers.IO) {
        val r = target ?: renderer ?: throw IOException("nessun dispositivo scelto")
        if (!app.vpn.isUp) throw IOException("VPN non attiva: la trasmissione passa sempre da Mullvad")
        val activeRelay = relay ?: StreamRelay(app).also { created ->
            created.start()
            relay = created
        }
        val url = activeRelay.publish(ch)
        runCatching { Dlna.stop(r) }   // alcune TV accettano un nuovo indirizzo solo da ferme
        Dlna.setUri(r, url, ch.name)
        Dlna.play(r)
        renderer = r
        _state.value = State.Casting(r.name, ch.name)
    }

    suspend fun stop() = withContext<Unit>(Dispatchers.IO) {
        renderer?.let { runCatching { Dlna.stop(it) } }
        renderer = null
        relay?.stop()
        relay = null
        _state.value = State.Idle
    }
}
