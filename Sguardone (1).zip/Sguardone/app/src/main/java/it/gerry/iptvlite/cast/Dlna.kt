package it.gerry.iptvlite.cast

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.net.URL

/** Un dispositivo DLNA/UPnP capace di riprodurre (MediaRenderer con AVTransport). */
data class Renderer(val name: String, val controlUrl: String)

/**
 * DLNA minimale, senza librerie: ricerca SSDP in rete locale e comandi UPnP AVTransport
 * (SetAVTransportURI, Play, Stop). Usato solo verso indirizzi della rete di casa.
 */
object Dlna {

    private const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"

    /** Cerca i dispositivi per [timeoutMs] millisecondi. Va chiamato fuori dal thread principale. */
    fun discover(context: Context, timeoutMs: Long = 3_500L): List<Renderer> {
        val wifi = context.applicationContext.getSystemService(WifiManager::class.java)
        val lock = wifi?.createMulticastLock("sguardone-dlna")?.apply {
            setReferenceCounted(false)
            acquire()
        }
        try {
            val locations = LinkedHashSet<String>()
            DatagramSocket(null).use { socket ->
                socket.reuseAddress = true
                socket.soTimeout = 400
                socket.bind(InetSocketAddress(0))
                val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                    "HOST: 239.255.255.250:1900\r\n" +
                    "MAN: \"ssdp:discover\"\r\n" +
                    "MX: 2\r\n" +
                    "ST: $AVT\r\n\r\n").toByteArray()
                val group = InetAddress.getByName("239.255.255.250")
                repeat(2) { socket.send(DatagramPacket(msg, msg.size, group, 1900)) }

                val locationRegex = Regex("(?im)^location:\\s*(\\S+)")
                val buffer = ByteArray(4096)
                val end = System.currentTimeMillis() + timeoutMs
                while (System.currentTimeMillis() < end) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        socket.receive(packet)
                        val text = String(packet.data, 0, packet.length)
                        locationRegex.find(text)?.let { locations.add(it.groupValues[1]) }
                    } catch (e: SocketTimeoutException) {
                        // continua ad ascoltare fino allo scadere
                    }
                }
            }
            return locations.mapNotNull { runCatching { describe(it) }.getOrNull() }.distinctBy { it.controlUrl }
        } finally {
            lock?.release()
        }
    }

    /** Legge la descrizione del dispositivo: nome e indirizzo di controllo AVTransport. */
    private fun describe(location: String): Renderer? {
        val url = URL(location)
        requireLan(url)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 3_000
            readTimeout = 3_000
        }
        try {
            if (conn.responseCode != 200) return null
            val parser = Xml.newPullParser()
            parser.setInput(conn.inputStream, null)
            var name: String? = null
            var urlBase: String? = null
            var serviceType: String? = null
            var control: String? = null
            var avtControl: String? = null
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    when (parser.name) {
                        "friendlyName" -> if (name == null) name = parser.nextText().trim()
                        "URLBase" -> urlBase = parser.nextText().trim()
                        "serviceType" -> serviceType = parser.nextText().trim()
                        "controlURL" -> control = parser.nextText().trim()
                    }
                } else if (event == XmlPullParser.END_TAG && parser.name == "service") {
                    if (serviceType?.startsWith("urn:schemas-upnp-org:service:AVTransport") == true && control != null) {
                        avtControl = control
                    }
                    serviceType = null
                    control = null
                }
                event = parser.next()
            }
            val ctrl = avtControl ?: return null
            val base = URL(urlBase?.takeIf { it.isNotEmpty() } ?: location)
            return Renderer(name ?: url.host, URL(base, ctrl).toString())
        } finally {
            conn.disconnect()
        }
    }

    fun setUri(r: Renderer, mediaUrl: String, title: String) {
        val didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
            "<item id=\"0\" parentID=\"-1\" restricted=\"1\"><dc:title>${esc(title)}</dc:title>" +
            "<upnp:class>object.item.videoItem.videoBroadcast</upnp:class>" +
            "<res protocolInfo=\"http-get:*:video/mp2t:*\">${esc(mediaUrl)}</res></item></DIDL-Lite>"
        soap(
            r, "SetAVTransportURI",
            "<InstanceID>0</InstanceID><CurrentURI>${esc(mediaUrl)}</CurrentURI>" +
                "<CurrentURIMetaData>${esc(didl)}</CurrentURIMetaData>",
        )
    }

    fun play(r: Renderer) = soap(r, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>")

    fun stop(r: Renderer) = soap(r, "Stop", "<InstanceID>0</InstanceID>")

    private fun soap(r: Renderer, action: String, args: String) {
        val url = URL(r.controlUrl)
        requireLan(url)
        val envelope = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
            "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>" +
            "<u:$action xmlns:u=\"$AVT\">$args</u:$action></s:Body></s:Envelope>"
        val body = envelope.toByteArray(Charsets.UTF_8)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 4_000
            readTimeout = 8_000
            setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
            setRequestProperty("SOAPAction", "\"$AVT#$action\"")
            setFixedLengthStreamingMode(body.size)
        }
        try {
            conn.outputStream.use { it.write(body) }
            val code = conn.responseCode
            if (code != 200) throw IOException("il dispositivo ha rifiutato il comando $action (HTTP $code)")
        } finally {
            conn.disconnect()
        }
    }

    /** I comandi DLNA vanno solo verso la rete di casa, mai verso Internet. */
    private fun requireLan(url: URL) {
        val address = InetAddress.getByName(url.host)
        if (!(address.isSiteLocalAddress || address.isLinkLocalAddress)) {
            throw IOException("indirizzo DLNA fuori dalla rete locale: ${url.host}")
        }
    }

    private fun esc(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")
}
