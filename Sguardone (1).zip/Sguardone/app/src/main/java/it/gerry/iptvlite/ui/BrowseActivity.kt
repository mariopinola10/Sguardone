package it.gerry.iptvlite.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import it.gerry.iptvlite.App
import it.gerry.iptvlite.R
import it.gerry.iptvlite.data.Channel
import it.gerry.iptvlite.data.Group
import it.gerry.iptvlite.data.Programme
import it.gerry.iptvlite.data.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Gestione canali e preferiti: gruppi | canali | guida del canale.
 * Sul canale: OK = guarda, OK tenuto premuto o Menu = aggiungi/togli dai preferiti.
 * Sulla cartella: OK tenuto premuto o Menu = aggiungi/togli la cartella dai preferiti (scheda nella guida).
 */
class BrowseActivity : ComponentActivity() {

    private val app by lazy { application as App }
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var groupsList: RecyclerView
    private lateinit var channelsList: RecyclerView
    private lateinit var nowTitle: TextView
    private lateinit var nowTime: TextView
    private lateinit var nowDesc: TextView
    private lateinit var info: TextView

    private lateinit var groupAdapter: RowAdapter<Group>
    private lateinit var channelAdapter: RowAdapter<Channel>
    private lateinit var epgAdapter: RowAdapter<Programme>

    private var currentGroup = ""
    private var currentChannel: Channel? = null
    private var focusedGroup: String? = null
    private var pendingGroup: Runnable? = null
    private var pendingChannel: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)

        groupsList = findViewById(R.id.groupsList)
        channelsList = findViewById(R.id.channelsList)
        nowTitle = findViewById(R.id.nowTitle)
        nowTime = findViewById(R.id.nowTime)
        nowDesc = findViewById(R.id.nowDesc)
        info = findViewById(R.id.info)

        groupAdapter = RowAdapter(
            title = { (if (app.repo.isFavoriteGroup(it.name)) "★ " else "") + "${it.name}  (${it.count})" },
            isActive = { it.name == currentGroup },
            onFocus = { g, _ ->
                focusedGroup = g.name
                debounceGroup(g.name)
            },
            onClick = { g, _ -> selectGroup(g.name, focusChannels = true) },
            onLongClick = { g, _ -> toggleFavoriteGroup(g.name) },
        )
        channelAdapter = RowAdapter(
            title = { (if (app.repo.isFavorite(it.name)) "★ " else "") + it.name },
            subtitle = { app.repo.nowPlaying(it.epgKey)?.title },
            onFocus = { ch, _ -> debounceChannel(ch) },
            onClick = { _, pos -> PlayerActivity.start(this, currentGroup, pos) },
            onLongClick = { ch, _ -> channelMenu(ch) },
        )
        epgAdapter = RowAdapter(
            title = { "${Format.time(it.start)}   ${it.title}" },
            focusable = false,
        )

        groupsList.layoutManager = LinearLayoutManager(this)
        groupsList.adapter = groupAdapter
        groupsList.itemAnimator = null
        channelsList.layoutManager = LinearLayoutManager(this)
        channelsList.adapter = channelAdapter
        findViewById<RecyclerView>(R.id.epgList).apply {
            layoutManager = LinearLayoutManager(this@BrowseActivity)
            adapter = epgAdapter
            isFocusable = false
            descendantFocusability = RecyclerView.FOCUS_BLOCK_DESCENDANTS
        }

        lifecycleScope.launch {
            groupAdapter.items = withContext(Dispatchers.IO) { app.repo.groups() }
            val (withEpg, total) = withContext(Dispatchers.IO) { app.repo.epgCoverage() }
            info.text = "$total canali · $withEpg con guida EPG · " +
                "${app.repo.favoriteNames().size} preferiti"
            selectGroup(Repository.ALL, focusChannels = true)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    /** Menu (≡) sul canale: aggiunge/toglie dai preferiti. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            val ch = currentChannel
            val group = focusedGroup
            when {
                channelsList.hasFocus() && ch != null -> channelMenu(ch)
                groupsList.hasFocus() && group != null -> toggleFavoriteGroup(group)
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun selectGroup(name: String, focusChannels: Boolean, force: Boolean = false) {
        if (name == currentGroup && !force) {
            if (focusChannels) focusFirst(channelsList)
            return
        }
        currentGroup = name
        groupAdapter.refreshRows()
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { app.repo.channels(name) }
            if (currentGroup != name) return@launch
            channelAdapter.items = list
            channelsList.scrollToPosition(0)
            if (focusChannels) focusFirst(channelsList)
            list.firstOrNull()?.let { showEpg(it) }
        }
    }

    private fun debounceGroup(name: String) {
        pendingGroup?.let { handler.removeCallbacks(it) }
        pendingGroup = Runnable { selectGroup(name, focusChannels = false) }.also { handler.postDelayed(it, 300) }
    }

    private fun debounceChannel(ch: Channel) {
        currentChannel = ch
        pendingChannel?.let { handler.removeCallbacks(it) }
        pendingChannel = Runnable { showEpg(ch) }.also { handler.postDelayed(it, 150) }
    }

    private fun showEpg(ch: Channel) {
        currentChannel = ch
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { app.repo.programmes(ch.epgKey) }
            if (currentChannel != ch) return@launch
            val now = System.currentTimeMillis()
            val current = list.firstOrNull()?.takeIf { it.start <= now }
            if (current != null) {
                nowTitle.text = current.title
                nowTime.text = "${ch.name}  ·  ${Format.range(current)}"
                nowDesc.text = current.description.orEmpty()
                epgAdapter.items = list.drop(1)
            } else {
                nowTitle.text = ch.name
                nowTime.text = ""
                nowDesc.text = if (ch.epgKey == null) "Nessuna guida per questo canale" else ""
                epgAdapter.items = list
            }
        }
    }

    private fun toggleFavorite(ch: Channel) {
        lifecycleScope.launch {
            val added = withContext(Dispatchers.IO) { app.repo.toggleFavorite(ch.name) }
            Toast.makeText(
                this@BrowseActivity,
                if (added) "★ ${ch.name} aggiunto ai preferiti" else "${ch.name} tolto dai preferiti",
                Toast.LENGTH_SHORT,
            ).show()
            groupAdapter.items = withContext(Dispatchers.IO) { app.repo.groups() }
            if (currentGroup == Repository.FAVORITES) {
                selectGroup(Repository.FAVORITES, focusChannels = true, force = true)
            } else {
                channelAdapter.refreshRows()
            }
        }
    }

    /** Menu del canale: preferiti e numero. */
    private fun channelMenu(ch: Channel) {
        ChannelActions.show(this, app, ch) {
            lifecycleScope.launch {
                groupAdapter.items = withContext(Dispatchers.IO) { app.repo.groups() }
                if (currentGroup == Repository.FAVORITES) {
                    selectGroup(Repository.FAVORITES, focusChannels = true, force = true)
                } else {
                    channelAdapter.refreshRows()
                }
            }
        }
    }

    /** Cartella preferita: compare come scheda nella guida principale. */
    private fun toggleFavoriteGroup(name: String) {
        if (name == Repository.ALL || name == Repository.FAVORITES) {
            Toast.makeText(this, "Questa voce non si può aggiungere come cartella", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            val added = withContext(Dispatchers.IO) { app.repo.toggleFavoriteGroup(name) }
            Toast.makeText(
                this@BrowseActivity,
                if (added) "★ Cartella \"$name\" aggiunta: la trovi come scheda nella guida"
                else "Cartella \"$name\" tolta dai preferiti",
                Toast.LENGTH_SHORT,
            ).show()
            groupAdapter.refreshRows()
        }
    }

    private fun focusFirst(list: RecyclerView) {
        list.post {
            list.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() ?: list.requestFocus()
        }
    }
}
