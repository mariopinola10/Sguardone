package it.gerry.iptvlite.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteStatement

class Db(context: Context) : SQLiteOpenHelper(context, "iptv.db", null, 3) {

    override fun onConfigure(db: SQLiteDatabase) {
        // WAL: la UI può leggere mentre l'import EPG scrive in background.
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE channels(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                tvg_id TEXT,
                tvg_name TEXT,
                logo TEXT,
                grp TEXT NOT NULL,
                url TEXT NOT NULL,
                ua TEXT,
                referer TEXT,
                epg_key TEXT
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_channels_grp ON channels(grp)")
        db.execSQL(
            """
            CREATE TABLE programmes(
                epg_key TEXT NOT NULL,
                start INTEGER NOT NULL,
                stop INTEGER NOT NULL,
                title TEXT NOT NULL,
                descr TEXT
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_programmes_key_start ON programmes(epg_key, start)")
        createFavorites(db)
        createV3(db)
    }

    private fun createFavorites(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS favorites(name TEXT PRIMARY KEY, added INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // v2: tabella preferiti. Canali ed EPG restano intatti.
        if (oldVersion < 2) createFavorites(db)
        if (oldVersion < 3) createV3(db)
    }

    /** v3: indice per la ricerca EPG e tabella dei promemoria. */
    private fun createV3(db: SQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_channels_epg ON channels(epg_key)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS reminders(channel TEXT NOT NULL, title TEXT NOT NULL, " +
                "start INTEGER NOT NULL, stop INTEGER NOT NULL, notified INTEGER NOT NULL DEFAULT 0, " +
                "PRIMARY KEY(channel, start))"
        )
    }
}

internal fun SQLiteStatement.bindOrNull(index: Int, value: String?) {
    if (value == null) bindNull(index) else bindString(index, value)
}
