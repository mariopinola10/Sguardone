package it.gerry.iptvlite.cast

import androidx.mediarouter.media.MediaRouter
import it.gerry.iptvlite.App
import it.gerry.iptvlite.data.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Trasmissione alla TV: Google Cast (Chromecast, Google TV) e DLNA.
 * In entrambi i casi la TV riceve lo stream dal ponte locale, che lo scarica dentro la VPN.
 */
class CastManager(private val app: App) {

    /** Un dispositivo a cui trasmettere. */
    sealed interface Target {
        val name: String

        data class Dlna(val renderer: Renderer) : Target {
            override val name: String get() = "${renderer.name}  (DLNA)"
        }

        data class Cast(val route: MediaRouter.RouteInfo) : Target {
            override val name: String get() = "${route.name}  (Google Cast)"
        }
    }

    sealed interface State {
        data object Idle : State
        data class Casting(val device: String, val channel: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()
    val isCasting: Boolean get() = _state.value is State.Casting

    private val googleCast by lazy { GoogleCast(app) }
    private var relay: StreamRelay? = null
    private var target: Target? = null

    /** Cerca insieme dispositivi Google Cast e DLNA (circa 3,5 s). Da chiamare dal thread principale. */
    suspend fun discover(): List<Target> = coroutineScope {
        val dlna = async(Dispatchers.IO) { runCatching { Dlna.discover(app) }.getOrDefault(emptyList()) }
        val cast = withContext(Dispatchers.Main) {
            runCatching { googleCast.scan(3_500L) }.getOrDefault(emptyList())
        }
        cast.map { Target.Cast(it) } + dlna.await().map { Target.Dlna(it) }
    }

    /** Trasmette il canale sul dispositivo scelto (o su quello attuale se [newTarget] è null). */
    suspend fun cast(ch: Channel, newTarget: Target? = null) {
        val t = newTarget ?: target ?: throw IOException("nessun dispositivo scelto")
        if (!app.vpn.isUp) throw IOException("VPN non attiva: la trasmissione passa sempre da Mullvad")

        // Cambio di dispositivo: chiudo quello precedente.
        val previous = target
        if (previous != null && previous != t) stopTarget(previous)

        val activeRelay = withContext(Dispatchers.IO) {
            relay ?: StreamRelay(app).also { created ->
                created.start()
                relay = created
            }
        }
        when (t) {
            is Target.Dlna -> withContext(Dispatchers.IO) {
                val url = activeRelay.publish(ch)
                runCatching { Dlna.stop(t.renderer) }   // alcune TV accettano un nuovo indirizzo solo da ferme
                Dlna.setUri(t.renderer, url, ch.name)
                Dlna.play(t.renderer)
            }
            is Target.Cast -> {
                val url = withContext(Dispatchers.IO) { activeRelay.publishHls(ch) }
                    ?: throw IOException("questo canale non ha una versione HLS: con Google Cast non si può trasmettere, prova un dispositivo DLNA")
                withContext(Dispatchers.Main) { googleCast.load(t.route, ch.name, url) }
            }
        }
        target = t
        _state.value = State.Casting(t.name, ch.name)
    }

    suspend fun stop() {
        target?.let { stopTarget(it) }
        target = null
        withContext(Dispatchers.IO) {
            relay?.stop()
            relay = null
        }
        _state.value = State.Idle
    }

    private suspend fun stopTarget(t: Target) {
        when (t) {
            is Target.Dlna -> withContext(Dispatchers.IO) { runCatching { Dlna.stop(t.renderer) } }
            is Target.Cast -> withContext(Dispatchers.Main) { runCatching { googleCast.end() } }
        }
    }
}
