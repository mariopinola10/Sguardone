package it.gerry.iptvlite.data

import android.content.ContentValues
import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.util.LruCache
import it.gerry.iptvlite.Prefs
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.zip.GZIPInputStream

/**
 * Tutte le funzioni di download/import sono bloccanti: chiamarle da Dispatchers.IO.
 * I download vanno fatti solo con la VPN attiva (lo garantisce la MainActivity).
 */
class Repository(
    private val db: Db,
    private val http: OkHttpClient,
    private val prefs: Prefs,
    private val localM3u: File,
) {
    companion object {
        private const val CHANNEL_COLS = "c.id, c.name, c.grp, c.url, c.ua, c.referer, c.epg_key, c.logo"

        const val ALL = "Tutti i canali"
        const val FAVORITES = "★ Preferiti"
        const val DEFAULT_UA = "VLC/3.0.20 LibVLC/3.0.20"

        /** Guida pubblica italiana usata se né la lista né le impostazioni indicano un EPG. */
        const val DEFAULT_EPG = "https://epgshare01.online/epgshare01/epg_ripper_IT1.xml.gz"

        private const val TTL = 12 * 60 * 60 * 1000L
    }

    private fun now() = System.currentTimeMillis()

    fun hasChannels(): Boolean = DatabaseUtils.queryNumEntries(db.readableDatabase, "channels") > 0

    // ---------- Lista M3U ----------

    fun refreshPlaylist(force: Boolean, progress: (String) -> Unit) {
        val sources = prefs.m3uSources()
        if (sources.isEmpty()) throw IOException("Nessuna lista M3U configurata")
        // I file locali si reimportano solo quando cambiano (lastM3u azzerato al caricamento).
        val allLocal = sources.all { it == Prefs.LOCAL_M3U }
        val fresh = if (allLocal) prefs.lastM3u > 0 else now() - prefs.lastM3u < TTL
        if (!force && hasChannels() && fresh) return

        val stats = importAll(sources, progress)
        prefs.lastM3u = now()
        prefs.lastEpg = 0L   // i canali sono cambiati: l'abbinamento EPG va rifatto
        nowNextCache.evictAll()

        val lists = if (sources.size > 1) " da ${sources.size - stats.failed} liste su ${sources.size}" else ""
        progress(
            when {
                stats.insecure == 0 -> "${stats.count} canali caricati$lists, tutti HTTPS"
                prefs.httpsOnlyStreams -> "${stats.count} canali caricati$lists: ${stats.insecure} non HTTPS saranno bloccati"
                else -> "${stats.count} canali caricati$lists (${stats.insecure} non HTTPS consentiti)"
            }
        )
    }

    private class ImportStats {
        var count = 0
        var insecure = 0
        var failed = 0
        val epg = LinkedHashSet<String>()
    }

    /**
     * Importa tutte le liste in un'unica transazione. Con più liste i gruppi diventano
     * "Lista N · Gruppo" per distinguerli. Una lista che non risponde non blocca le altre.
     */
    private fun importAll(sources: List<String>, progress: (String) -> Unit): ImportStats {
        val w = db.writableDatabase
        val stats = ImportStats()
        w.beginTransaction()
        try {
            w.delete("channels", null, null)
            w.delete("programmes", null, null)
            val st = w.compileStatement(
                "INSERT INTO channels(name, tvg_id, tvg_name, logo, grp, url, ua, referer) VALUES(?,?,?,?,?,?,?,?)"
            )
            sources.forEachIndexed { i, src ->
                val local = src == Prefs.LOCAL_M3U
                val prefix = if (sources.size > 1) "Lista ${i + 1} · " else ""
                val label = if (local) "file caricato" else shorten(src)
                progress(
                    if (sources.size > 1) "Carico la lista ${i + 1}/${sources.size} ($label)…"
                    else if (local) "Carico la lista dal file…" else "Scarico la lista M3U…"
                )
                val parse: (InputStream) -> String? = { input ->
                    M3uParser.parse(input) { e ->
                        st.bindString(1, e.name)
                        st.bindOrNull(2, e.tvgId)
                        st.bindOrNull(3, e.tvgName)
                        st.bindOrNull(4, e.logo)
                        st.bindString(5, prefix + e.group)
                        st.bindString(6, e.url)
                        st.bindOrNull(7, e.userAgent)
                        st.bindOrNull(8, e.referer)
                        st.executeInsert()
                        stats.count++
                        if (!e.url.startsWith("https://", ignoreCase = true)) stats.insecure++
                    }
                }
                try {
                    val epg = if (local) {
                        if (!localM3u.exists()) throw IOException("file non trovato, ricaricalo dalle impostazioni")
                        localM3u.inputStream().use { parse(maybeGunzip(it)) }
                    } else {
                        requireHttps(src, "lista M3U")
                        download(src, parse)
                    }
                    epg?.split(',')?.map { it.trim() }?.filter { it.isNotEmpty() }?.let { stats.epg.addAll(it) }
                } catch (e: Exception) {
                    stats.failed++
                    progress("Lista ${i + 1} non disponibile: ${e.message}")
                }
            }
            if (stats.count == 0) {
                throw IOException(if (stats.failed > 0) "Nessuna lista M3U caricata" else "Le liste M3U non contengono canali")
            }
            prefs.detectedEpgUrl = stats.epg.joinToString(",")
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }
        return stats
    }

    // ---------- Guida EPG ----------

    /**
     * Link EPG in ordine di priorità (per ogni canale vince la prima guida che lo copre):
     * - se impostati a mano: solo quelli;
     * - altrimenti: guida pubblica italiana, poi quella dichiarata nella lista M3U per i canali mancanti.
     */
    fun epgSources(): List<String> {
        val manual = splitLinks(prefs.epgUrl)
        if (manual.isNotEmpty()) return manual
        return (listOf(DEFAULT_EPG) + splitLinks(prefs.detectedEpgUrl)).distinct()
    }

    private fun splitLinks(raw: String): List<String> =
        raw.split(',').map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    /** Restituisce true se la guida è stata aggiornata. */
    fun refreshEpg(force: Boolean, progress: (String) -> Unit): Boolean {
        if (!force && now() - prefs.lastEpg < TTL) return false
        val all = epgSources()
        val sources = all.filter { it.startsWith("https://", ignoreCase = true) }
        if (sources.size < all.size) progress("Ignorati ${all.size - sources.size} link EPG non HTTPS")
        if (sources.isEmpty()) {
            progress("Nessuna guida EPG HTTPS disponibile")
            return false
        }

        val w = db.writableDatabase
        var ok = 0
        w.beginTransaction()
        try {
            val importer = EpgImporter(w, now())
            sources.forEachIndexed { i, url ->
                progress("Scarico la guida EPG ${i + 1}/${sources.size}…")
                try {
                    download(url) { importer.importSource(it) }
                    ok++
                } catch (e: Exception) {
                    progress("Guida ${i + 1} non disponibile: ${e.message}")
                }
            }
            if (ok == 0) throw IOException("Nessuna guida EPG scaricata")
            w.setTransactionSuccessful()
        } finally {
            w.endTransaction()
        }

        nowNextCache.evictAll()
        prefs.lastEpg = now()
        val (withEpg, total) = epgCoverage()
        progress("Guida aggiornata: $withEpg canali su $total con EPG")
        return true
    }

    /** (canali con guida, canali totali). */
    fun epgCoverage(): Pair<Int, Int> =
        db.readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(epg_key IS NOT NULL), 0), COUNT(*) FROM channels", null
        ).use { c -> if (c.moveToFirst()) c.getInt(0) to c.getInt(1) else 0 to 0 }

    // ---------- Download ----------

    private fun requireHttps(url: String, what: String) {
        if (!url.startsWith("https://", ignoreCase = true)) {
            throw IOException("Link $what non HTTPS: per sicurezza non mi collego")
        }
    }

    /** Client per M3U ed EPG: HTTPS obbligatorio su ogni passaggio, redirect compresi. */
    private val httpsClient: OkHttpClient by lazy {
        http.newBuilder()
            .addNetworkInterceptor { chain ->
                val u = chain.request().url
                if (!u.isHttps) throw IOException("Redirect verso connessione non HTTPS bloccato (${u.host})")
                chain.proceed(chain.request())
            }
            .build()
    }

    /** Scarica in streaming; decomprime da solo i file .gz (rileva i magic byte). */
    private fun <T> download(url: String, block: (InputStream) -> T): T {
        requireHttps(url, "da scaricare")
        val request = Request.Builder().url(url).header("User-Agent", DEFAULT_UA).build()
        httpsClient.newCall(request).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code} scaricando ${shorten(url)}")
            val body = r.body ?: throw IOException("Risposta vuota da ${shorten(url)}")
            return block(maybeGunzip(body.byteStream()))
        }
    }

    private fun maybeGunzip(stream: InputStream): InputStream {
        val raw = BufferedInputStream(stream, 64 * 1024)
        raw.mark(2)
        val b1 = raw.read()
        val b2 = raw.read()
        raw.reset()
        return if (b1 == 0x1f && b2 == 0x8b) GZIPInputStream(raw, 64 * 1024) else raw
    }

    private fun shorten(url: String) = url.substringBefore('?').take(60)

    // ---------- Gruppi e canali ----------

    fun groups(): List<Group> {
        val out = ArrayList<Group>()
        var total = 0
        db.readableDatabase.rawQuery(
            "SELECT grp, COUNT(*) FROM channels GROUP BY grp ORDER BY MIN(id)", null
        ).use { c ->
            while (c.moveToNext()) {
                val n = c.getInt(1)
                total += n
                out.add(Group(c.getString(0), n))
            }
        }
        if (out.isEmpty()) return out
        return listOf(Group(FAVORITES, favoritesCount()), Group(ALL, total)) + out
    }

    fun channels(group: String): List<Channel> {
        val cols = CHANNEL_COLS
        val cursor = when (group) {
            // Un solo canale per nome, nell'ordine in cui sono stati aggiunti ai preferiti.
            FAVORITES -> db.readableDatabase.rawQuery(
                "SELECT $cols FROM channels c JOIN favorites f ON f.name = c.name " +
                    "WHERE c.id IN (SELECT MIN(id) FROM channels GROUP BY name) ORDER BY f.added",
                null,
            )
            ALL -> db.readableDatabase.rawQuery("SELECT $cols FROM channels c ORDER BY c.id", null)
            else -> db.readableDatabase.rawQuery(
                "SELECT $cols FROM channels c WHERE c.grp = ? ORDER BY c.id", arrayOf(group)
            )
        }
        return cursor.use { readChannels(it) }
    }

    private fun readChannels(c: Cursor): List<Channel> {
        val out = ArrayList<Channel>(c.count.coerceAtLeast(0))
        while (c.moveToNext()) out.add(channelAt(c))
        return out
    }

    /** Legge il canale dalla riga corrente (colonne nell'ordine di CHANNEL_COLS). */
    private fun channelAt(c: Cursor) = Channel(
        id = c.getLong(0),
        name = c.getString(1),
        group = c.getString(2),
        url = c.getString(3),
        userAgent = if (c.isNull(4)) null else c.getString(4),
        referer = if (c.isNull(5)) null else c.getString(5),
        epgKey = if (c.isNull(6)) null else c.getString(6),
        logo = if (c.isNull(7)) null else c.getString(7),
    )

    fun channelByName(name: String): Channel? =
        db.readableDatabase.rawQuery(
            "SELECT $CHANNEL_COLS FROM channels c WHERE c.name = ? ORDER BY c.id LIMIT 1", arrayOf(name)
        ).use { if (it.moveToFirst()) channelAt(it) else null }

    // ---------- Ricerca ----------

    /** Testo per LIKE '%...%' con i caratteri jolly protetti. */
    private fun likeArg(q: String): String =
        "%" + q.trim().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"

    /** Canali il cui nome contiene il testo (uno per nome). */
    fun searchChannels(query: String, limit: Int = 30): List<Channel> =
        db.readableDatabase.rawQuery(
            "SELECT $CHANNEL_COLS FROM channels c WHERE c.id IN " +
                "(SELECT MIN(id) FROM channels WHERE name LIKE ? ESCAPE '\\' GROUP BY name) " +
                "ORDER BY c.name LIMIT $limit",
            arrayOf(likeArg(query)),
        ).use { readChannels(it) }

    /**
     * Programmi in onda o futuri (finestra della guida: fino a 48 ore) con il testo nel titolo
     * o nella descrizione, in ordine di orario: quelli in onda per primi.
     */
    fun searchProgrammes(query: String, limit: Int = 80): List<ProgrammeHit> {
        val arg = likeArg(query)
        val out = ArrayList<ProgrammeHit>()
        db.readableDatabase.rawQuery(
            "SELECT $CHANNEL_COLS, p.start, p.stop, p.title, p.descr FROM programmes p " +
                "JOIN channels c ON c.id = (SELECT MIN(id) FROM channels WHERE epg_key = p.epg_key) " +
                "WHERE p.stop > ? AND (p.title LIKE ? ESCAPE '\\' OR p.descr LIKE ? ESCAPE '\\') " +
                "ORDER BY p.start LIMIT $limit",
            arrayOf(now().toString(), arg, arg),
        ).use { c ->
            while (c.moveToNext()) {
                val programme = Programme(c.getLong(8), c.getLong(9), c.getString(10), if (c.isNull(11)) null else c.getString(11))
                out.add(ProgrammeHit(channelAt(c), programme))
            }
        }
        return out
    }

    /** Il prossimo evento (o quello in onda) tra le ricerche salvate: (termine, risultato). */
    fun nextHighlight(terms: List<String>): Pair<String, ProgrammeHit>? {
        var best: Pair<String, ProgrammeHit>? = null
        for (term in terms) {
            val hit = searchProgrammes(term, 1).firstOrNull() ?: continue
            val current = best
            if (current == null || hit.programme.start < current.second.programme.start) best = term to hit
        }
        return best
    }

    // ---------- Promemoria ----------

    fun addReminder(channel: String, p: Programme) {
        val values = ContentValues().apply {
            put("channel", channel)
            put("title", p.title)
            put("start", p.start)
            put("stop", p.stop)
            put("notified", 0)
        }
        db.writableDatabase.insertWithOnConflict("reminders", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun removeReminder(channel: String, start: Long) {
        db.writableDatabase.delete("reminders", "channel = ? AND start = ?", arrayOf(channel, start.toString()))
    }

    fun hasReminder(channel: String, start: Long): Boolean =
        DatabaseUtils.queryNumEntries(
            db.readableDatabase, "reminders", "channel = ? AND start = ?", arrayOf(channel, start.toString())
        ) > 0

    /** Promemoria da mostrare ora (da 1 minuto prima dell'inizio fino alla fine) e li segna come mostrati. */
    @Synchronized
    fun takeDueReminders(): List<Reminder> {
        val t = now()
        val w = db.writableDatabase
        w.delete("reminders", "stop < ?", arrayOf(t.toString()))
        val out = ArrayList<Reminder>()
        w.rawQuery(
            "SELECT channel, title, start, stop FROM reminders WHERE notified = 0 AND start <= ? AND stop > ?",
            arrayOf((t + 60_000L).toString(), t.toString()),
        ).use { c ->
            while (c.moveToNext()) out.add(Reminder(c.getString(0), c.getString(1), c.getLong(2), c.getLong(3)))
        }
        for (r in out) {
            w.execSQL("UPDATE reminders SET notified = 1 WHERE channel = ? AND start = ?", arrayOf<Any>(r.channel, r.start))
        }
        return out
    }

    // ---------- Preferiti (per nome canale: restano validi anche se la lista viene ricaricata) ----------

    @Volatile
    private var favoritesCache: Set<String>? = null

    fun favoriteNames(): Set<String> = favoritesCache ?: loadFavorites().also { favoritesCache = it }

    fun isFavorite(name: String): Boolean = name in favoriteNames()

    /** Aggiunge o toglie dai preferiti. Restituisce true se ora è tra i preferiti. */
    @Synchronized
    fun toggleFavorite(name: String): Boolean {
        val w = db.writableDatabase
        val wasFavorite = isFavorite(name)
        if (wasFavorite) {
            w.delete("favorites", "name = ?", arrayOf(name))
        } else {
            val values = ContentValues().apply {
                put("name", name)
                put("added", now())
            }
            w.insertWithOnConflict("favorites", null, values, SQLiteDatabase.CONFLICT_IGNORE)
        }
        favoritesCache = null
        return !wasFavorite
    }

    private fun loadFavorites(): Set<String> {
        val out = HashSet<String>()
        db.readableDatabase.rawQuery("SELECT name FROM favorites", null).use { c ->
            while (c.moveToNext()) out.add(c.getString(0))
        }
        return out
    }

    private fun favoritesCount(): Int =
        db.readableDatabase.rawQuery(
            "SELECT COUNT(DISTINCT c.name) FROM channels c JOIN favorites f ON f.name = c.name", null
        ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    // ---------- Programmi ----------

    /** Programma in onda e successivi. */
    fun programmes(epgKey: String?, limit: Int = 30): List<Programme> {
        if (epgKey == null) return emptyList()
        val out = ArrayList<Programme>()
        db.readableDatabase.rawQuery(
            "SELECT start, stop, title, descr FROM programmes WHERE epg_key = ? AND stop > ? ORDER BY start LIMIT $limit",
            arrayOf(epgKey, now().toString()),
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Programme(c.getLong(0), c.getLong(1), c.getString(2), if (c.isNull(3)) null else c.getString(3)))
            }
        }
        return out
    }

    private class NowNext(val now: Programme?, val next: Programme?, val validUntil: Long)

    private val nowNextCache = LruCache<String, NowNext>(512)

    /**
     * Programma in onda e successivo, con cache valida fino al cambio programma.
     * Leggero: usato nelle righe della guida, anche sul thread principale.
     */
    fun nowNext(epgKey: String?): Pair<Programme?, Programme?> {
        if (epgKey == null) return null to null
        val t = now()
        nowNextCache.get(epgKey)?.let { if (t < it.validUntil) return it.now to it.next }
        val list = programmes(epgKey, 2)
        val first = list.getOrNull(0)
        val pair: Pair<Programme?, Programme?> =
            if (first != null && first.start <= t) Pair(first, list.getOrNull(1)) else Pair(null, first)
        val (current, next) = pair
        val until = minOf(current?.stop ?: next?.start ?: (t + 300_000L), t + 600_000L)
        nowNextCache.put(epgKey, NowNext(current, next, until))
        return current to next
    }

    fun nowPlaying(epgKey: String?): Programme? = nowNext(epgKey).first
}
