package it.gerry.iptvlite.data

data class Channel(
    val id: Long,
    val name: String,
    val group: String,
    val url: String,
    val userAgent: String?,
    val referer: String?,
    val epgKey: String?,
    val logo: String? = null,
    /** Numero mostrato nella guida (ordine "come in TV" o manuale); 0 = non assegnato. */
    val number: Int = 0,
    /** Quante versioni (qualità/fonti) dello stesso canale sono state unite in questa voce. */
    val variants: Int = 1,
)

data class Programme(
    val start: Long,
    val stop: Long,
    val title: String,
    val description: String?,
)

data class Group(val name: String, val count: Int)

/** Risultato di ricerca EPG: programma e canale su cui va in onda. */
data class ProgrammeHit(val channel: Channel, val programme: Programme)

data class Reminder(val channel: String, val title: String, val start: Long, val stop: Long)

/** Account Xtream Codes: server https, utente, password, formato degli stream (ts o m3u8). */
data class XtreamAccount(val server: String, val user: String, val pass: String, val ext: String) {

    val base: String get() = server.trim().trimEnd('/')

    /** Etichetta senza password, es. "provider.tv · mario". */
    val label: String
        get() = "${runCatching { java.net.URI(base).host }.getOrNull() ?: base} · $user"

    fun encode(): String = listOf(base, user, pass, ext).joinToString(SEP)

    companion object {
        private const val SEP = "\u001F"

        fun decode(raw: String): XtreamAccount? {
            val p = raw.split(SEP)
            if (p.size != 4 || p.any { it.isEmpty() }) return null
            return XtreamAccount(p[0], p[1], p[2], p[3])
        }
    }
}
