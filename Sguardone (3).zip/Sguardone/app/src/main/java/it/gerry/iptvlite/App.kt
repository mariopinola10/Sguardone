package it.gerry.iptvlite

import android.app.Activity
import android.app.AlertDialog
import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import it.gerry.iptvlite.cast.CastManager
import it.gerry.iptvlite.cast.LinkReceiver
import it.gerry.iptvlite.data.Db
import it.gerry.iptvlite.data.Repository
import it.gerry.iptvlite.ui.Format
import it.gerry.iptvlite.ui.LogoLoader
import it.gerry.iptvlite.ui.PlayerActivity
import it.gerry.iptvlite.vpn.VpnManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.io.File
import java.io.IOException
import java.lang.ref.WeakReference
import java.util.concurrent.TimeUnit

class App : Application() {

    lateinit var prefs: Prefs
        private set
    lateinit var http: OkHttpClient
        private set
    lateinit var repo: Repository
        private set
    lateinit var vpn: VpnManager
        private set

    /** Lista M3U caricata da file (telefono o selettore file). */
    val localM3uFile: File by lazy { File(filesDir, "playlist.m3u") }

    /** Versione dell'app (es. "0.12.4"), mostrata accanto al nome. */
    val versionName: String by lazy {
        runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: "?"
    }

    /** Trasmissione DLNA alla TV (lo stream passa sempre dalla VPN del dispositivo). */
    val cast: CastManager by lazy { CastManager(this) }

    /** Ricevitore "Trasmetti a Sguardone" (attivo con l'app in primo piano). */
    private val linkReceiver by lazy { LinkReceiver(this) }

    /** Loghi dei canali: scaricati solo con VPN attiva. */
    val logos: LogoLoader by lazy { LogoLoader(http, cacheDir) { vpn.isUp } }

    /** Scope che sopravvive alle Activity (usato per chiudere il tunnel all'uscita). */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Impostato dalle impostazioni: la MainActivity riparte da capo al resume. */
    @Volatile
    var configDirty = false

    private companion object {
        const val EPG_RULES = 3
        const val BACKGROUND_TIMEOUT_MS = 5 * 60 * 1000L
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        // Regole EPG aggiornate (guida pubblica prima di quella della lista): forza il riscaricamento.
        if (prefs.epgRules < EPG_RULES) {
            prefs.lastEpg = 0L
            prefs.epgRules = EPG_RULES
        }
        http = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            // Controlla ogni richiesta reale, inclusi i redirect e i segmenti HLS.
            .addNetworkInterceptor { chain ->
                val url = chain.request().url
                if (!url.isHttps && prefs.httpsOnlyStreams) {
                    throw IOException("Connessione non HTTPS bloccata (${url.host})")
                }
                chain.proceed(chain.request())
            }
            .build()
        repo = Repository(Db(this), http, prefs, localM3uFile)
        vpn = VpnManager(this, prefs, http)
        watchBackground()
        trackCurrentActivity()
    }

    // ---------- Promemoria ----------

    private var currentActivity: WeakReference<Activity>? = null

    fun foregroundActivity(): Activity? = currentActivity?.get()

    private fun trackCurrentActivity() {
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) {
                currentActivity = WeakReference(activity)
            }

            override fun onActivityPaused(activity: Activity) {
                if (currentActivity?.get() === activity) currentActivity = null
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityStarted(activity: Activity) = Unit
            override fun onActivityStopped(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
    }

    /** Ogni 20 s (solo con l'app aperta): mostra i promemoria dei programmi che stanno per iniziare. */
    private val reminderTick = object : Runnable {
        override fun run() {
            checkReminders()
            main.postDelayed(this, 20_000L)
        }
    }

    private fun checkReminders() {
        val activity = currentActivity?.get() ?: return
        appScope.launch {
            val due = runCatching { repo.takeDueReminders() }.getOrDefault(emptyList())
            if (due.isEmpty()) return@launch
            main.post {
                if (activity.isFinishing || activity.isDestroyed) return@post
                for (r in due) {
                    val started = r.start <= System.currentTimeMillis()
                    AlertDialog.Builder(activity)
                        .setTitle(if (started) "⏰ È iniziato" else "⏰ Sta per iniziare")
                        .setMessage("${r.title}\n${r.channel}  ·  ${Format.time(r.start)}")
                        .setPositiveButton("Guarda") { _, _ -> PlayerActivity.startByName(activity, r.channel) }
                        .setNegativeButton("Chiudi", null)
                        .show()
                }
            }
        }
    }

    // ---------- Chiusura automatica della VPN ----------

    private val main = Handler(Looper.getMainLooper())
    private val backgroundDisconnect = Runnable {
        // Durante una trasmissione DLNA la VPN serve anche a schermo spento: rimando il controllo.
        if (cast.needsVpn) {
            rescheduleBackgroundDisconnect()
        } else {
            appScope.launch { vpn.disconnect() }
        }
    }

    private fun rescheduleBackgroundDisconnect() {
        main.removeCallbacks(backgroundDisconnect)
        main.postDelayed(backgroundDisconnect, BACKGROUND_TIMEOUT_MS)
    }

    /**
     * App in background (Home, app recenti, schermo spento) per [BACKGROUND_TIMEOUT_MS]:
     * la VPN viene chiusa. Tornando nell'app si ricollega da sola.
     */
    private fun watchBackground() {
        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                main.removeCallbacks(backgroundDisconnect)
                main.removeCallbacks(reminderTick)
                main.post(reminderTick)
                runCatching { linkReceiver.start() }
            }

            override fun onStop(owner: LifecycleOwner) {
                runCatching { linkReceiver.stop() }
                main.removeCallbacks(reminderTick)
                main.removeCallbacks(backgroundDisconnect)
                main.postDelayed(backgroundDisconnect, BACKGROUND_TIMEOUT_MS)
            }
        })
    }

    /** Chiude subito tunnel e connessioni (pulsante Esci / uscita confermata). */
    suspend fun shutdown() {
        main.removeCallbacks(backgroundDisconnect)
        cast.stop(keepRemote = true)
        vpn.disconnect()
        http.dispatcher.cancelAll()
        http.connectionPool.evictAll()
    }
}
